﻿"""T13: prone -> hip-first (1.4 s) -> 3 s leg extension -> hold 3 s (200/4) -> switch to 55/2
and hold 10 s.  Records 200 Hz and renders H.264 MP4 960x540@30fps with overlay.

Prone raw hip q (from official OG ai_damping log): FR -0.562, FL +0.574, RR -0.556, RL +0.573
thigh/calf prone: +1.019 / -2.762 (official measured); official t2: hip +-0.15, thigh +0.60, calf -1.20.
MuJoCo only, 26 kg / mu=0.35, no robot/publisher.
"""
import csv
import hashlib
import json
import math
import os
import subprocess
import time

import numpy as np
import mujoco
from PIL import Image, ImageDraw, ImageFont

W = "/root/as2w/mujoco-sim2sim-20261121"
os.chdir(W)
OUT = os.path.join(W, "results", "prone_hipfirst_video")
VID = os.path.join(W, "videos", "prone_hipfirst")
os.makedirs(OUT, exist_ok=True)
os.makedirs(VID, exist_ok=True)
XML = os.path.join(W, "as2w_stand200.xml")

# official prone raw hip q (firmware order FR,FL,RR,RL) and official t2
PRONE_HIP = {"FR": -0.562, "FL": 0.574, "RR": -0.556, "RL": 0.573}
PRONE_THIGH, PRONE_CALF = 1.019, -2.762
T2_HIP = {"FR": 0.15, "FL": -0.15, "RR": 0.15, "RL": -0.15}
T2_THIGH, T2_CALF = 0.60, -1.20
MJ_LEGS = [f"{l}_{p}" for l in ("FL", "FR", "RL", "RR") for p in ("hip", "thigh", "calf")]
WH = ("FL_foot", "FR_foot", "RL_foot", "RR_foot")
LIM = np.array([{"hip": 60.0, "thigh": 60.0, "calf": 90.0}[n.split("_")[1]] for n in MJ_LEGS])

# timeline
T_HIP = 1.4
T_EXT_END = 4.4
T_HOLD_END = 7.4
T_END = 17.4
FPS = 30
RES = (960, 540)


def q_targets(t):
    """returns (q_tgt(12) in MJ order, phase, kp, kv)"""
    if t < T_HIP:
        a = t / T_HIP
        hip = {l: PRONE_HIP[l] + a * (T2_HIP[l] - PRONE_HIP[l]) for l in ("FR", "FL", "RR", "RL")}
        thigh, calf = PRONE_THIGH, PRONE_CALF
        phase, kp, kv = "H_hip_first", 200.0, 4.0
    elif t < T_EXT_END:
        a = (t - T_HIP) / (T_EXT_END - T_HIP)
        hip = dict(T2_HIP)
        thigh = PRONE_THIGH + a * (T2_THIGH - PRONE_THIGH)
        calf = PRONE_CALF + a * (T2_CALF - PRONE_CALF)
        phase, kp, kv = "K_extend3s", 200.0, 4.0
    elif t < T_HOLD_END:
        hip, thigh, calf = dict(T2_HIP), T2_THIGH, T2_CALF
        phase, kp, kv = "hold_200_4", 200.0, 4.0
    else:
        hip, thigh, calf = dict(T2_HIP), T2_THIGH, T2_CALF
        phase, kp, kv = "hold_55_2", 55.0, 2.0
    q = np.zeros(12)
    for k, l in enumerate(("FL", "FR", "RL", "RR")):
        q[3 * k] = hip[l]
        q[3 * k + 1] = thigh
        q[3 * k + 2] = calf
    return q, phase, kp, kv


m = mujoco.MjModel.from_xml_path(XML)
m.vis.global_.offwidth = RES[0]
m.vis.global_.offheight = RES[1]
d = mujoco.MjData(m)
LEG_AID = [m.actuator(f"a_{n}").id for n in MJ_LEGS]
WH_AID = [m.actuator(f"a_{n}").id for n in WH]
LEG_QADR = [m.jnt_qposadr[m.joint(n).id] for n in MJ_LEGS]
WH_QADR = [m.jnt_qposadr[m.joint(n).id] for n in WH]
LEG_DADR = [m.jnt_dofadr[m.joint(n).id] for n in MJ_LEGS]
WHEEL_GEOMS = []
for n in WH:
    b = m.body(n).id
    WHEEL_GEOMS.append([g for g in range(m.ngeom) if m.geom_bodyid[g] == b and m.geom_contype[g] != 0][0])
FLOOR = int(m.geom("floor").id)
Q_PRONE = np.zeros(12)
for k, l in enumerate(("FL", "FR", "RL", "RR")):
    Q_PRONE[3 * k] = PRONE_HIP[l]
    Q_PRONE[3 * k + 1] = PRONE_THIGH
    Q_PRONE[3 * k + 2] = PRONE_CALF


def set_gains(kp, kv, wheel_kv=0.5):
    for aid in LEG_AID:
        m.actuator_gainprm[aid, 0] = kp
        m.actuator_biasprm[aid, 1] = -kp
        m.actuator_biasprm[aid, 2] = -kv
    for aid in WH_AID:
        m.actuator_gainprm[aid, 0] = wheel_kv
        m.actuator_biasprm[aid, 0] = 0.0
        m.actuator_biasprm[aid, 1] = 0.0
        m.actuator_biasprm[aid, 2] = -wheel_kv


def contacts():
    fn = np.zeros(4)
    nonwheel = 0
    for i in range(d.ncon):
        c = d.contact[i]
        g1, g2 = int(c.geom1), int(c.geom2)
        if FLOOR not in (g1, g2):
            continue
        other = g2 if g1 == FLOOR else g1
        res = np.zeros(6)
        mujoco.mj_contactForce(m, d, i, res)
        if other in WHEEL_GEOMS:
            fn[WHEEL_GEOMS.index(other)] += abs(res[0])
        else:
            nonwheel += 1
    return fn, nonwheel


mujoco.mj_resetData(m, d)
for k, a in enumerate(LEG_QADR):
    d.qpos[a] = Q_PRONE[k]
for a in WH_QADR:
    d.qpos[a] = 0.0
d.qpos[0:2] = 0.0
d.qpos[3:7] = [1.0, 0.0, 0.0, 0.0]


def hit():
    for i in range(d.ncon):
        c = d.contact[i]
        g1, g2 = int(c.geom1), int(c.geom2)
        if FLOOR in (g1, g2) and ((g2 if g1 == FLOOR else g1) in WHEEL_GEOMS):
            return True
    return False


lo, hi = 0.02, 0.60
for _ in range(40):
    mid = 0.5 * (lo + hi)
    d.qpos[2] = mid
    d.qvel[:] = 0
    mujoco.mj_forward(m, d)
    if hit():
        lo = mid
    else:
        hi = mid
d.qpos[2] = hi + 1e-4
mujoco.mj_forward(m, d)
for _ in range(100):                          # settle prone at 200/4
    set_gains(200, 4)
    for k, aid in enumerate(LEG_AID):
        d.ctrl[aid] = Q_PRONE[k]
    for aid in WH_AID:
        d.ctrl[aid] = 0.0
    mujoco.mj_step(m, d)

cam = mujoco.MjvCamera()
cam.type = mujoco.mjtCamera.mjCAMERA_TRACKING
cam.trackbodyid = m.body("base_link").id
cam.distance = 2.0
cam.elevation = -20
cam.azimuth = 135
font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 20)
small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 15)

vid_path = os.path.join(VID, "prone_hipfirst_3s_then_55_2.mp4")
ff = subprocess.Popen(["ffmpeg", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24",
                       "-s", f"{RES[0]}x{RES[1]}", "-r", str(FPS), "-i", "-", "-an",
                       "-vcodec", "libx264", "-pix_fmt", "yuv420p", "-crf", "20",
                       "-preset", "medium", "-movflags", "+faststart",
                       "-loglevel", "error", vid_path],
                      stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

dt = m.opt.timestep
nsteps = int(round(T_END / dt))
frames_expected = int(round(T_END * FPS))
next_frame_t = 0.0
n_frames = 0
rows = []
fall = False
t_fall = None
t0 = time.time()
for i in range(nsteps):
    t = i * dt
    q_t, phase, kp, kv = q_targets(t)
    set_gains(kp, kv)
    for k, aid in enumerate(LEG_AID):
        d.ctrl[aid] = q_t[k]
    for aid in WH_AID:
        d.ctrl[aid] = 0.0
    mujoco.mj_step(m, d)
    w, x, y, z = d.qpos[3:7]
    roll = math.degrees(math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y)))
    pitch = math.degrees(math.asin(max(-1, min(1, 2 * (w * y - z * x)))))
    tilt = math.degrees(math.acos(max(-1.0, min(1.0, 1 - 2 * (x * x + y * y)))))
    q = np.array([d.qpos[a] for a in LEG_QADR])
    tau = np.array([d.qfrc_actuator[a] for a in LEG_AID])
    fn, nonwheel = contacts()
    pose_err = float(np.mean(np.abs(q - q_t)))
    if not fall and t > 1.0 and (tilt > 70 or d.qpos[2] < 0.12):
        fall, t_fall = True, t
    rows.append(dict(t=round(t, 3), phase=phase, kp=kp, kv=kv,
                     **{f"q_tgt_{n}": float(q_t[k]) for k, n in enumerate(MJ_LEGS)},
                     **{f"q_act_{n}": float(q[k]) for k, n in enumerate(MJ_LEGS)},
                     **{f"tau_{n}": float(tau[k]) for k, n in enumerate(MJ_LEGS)},
                     z=float(d.qpos[2]), roll=roll, pitch=pitch, tilt=tilt,
                     pose_err=round(pose_err, 5),
                     **{f"fn_{n}": float(fn[k]) for k, n in enumerate(WH)},
                     support4=float((fn >= 3.0).all()), nonwheel=int(nonwheel), fall=int(fall)))
    if t >= next_frame_t - 0.5 * dt and not fall:
        # fresh Renderer per frame (this X server corrupts shared-context readback)
        img = None
        arr = None
        for attempt in range(5):
            r = mujoco.Renderer(m, RES[1], RES[0])
            r.update_scene(d, camera=cam)
            arr = r.render()
            del r
            a = arr.astype(np.float32)
            sat = float((a.max(axis=2) - a.min(axis=2)).mean())
            if sat < 20.0:
                img = Image.fromarray(arr)
                break
        if img is None:
            img = Image.fromarray(arr)
        dr = ImageDraw.Draw(img)
        dr.rectangle([0, 0, RES[0], 96], fill=(0, 0, 0))
        dr.text((10, 4), f"prone -> hip-first -> 3s extend -> hold -> 55/2   phase={phase}",
                fill=(255, 255, 0), font=font)
        dr.text((10, 32), f"t={t:5.2f}s   leg gains kp={kp:.0f} kv={kv:.0f}   z={d.qpos[2]:.3f} m   tilt={tilt:4.1f} deg",
                fill=(220, 220, 220), font=small)
        dr.text((10, 54), f"hip FL/FR/RL/RR = {q[0]:+.3f}/{q[3]:+.3f}/{q[6]:+.3f}/{q[9]:+.3f}  "
                          f"thigh(FL)={q[1]:+.3f} calf(FL)={q[2]:+.3f}", fill=(220, 220, 220), font=small)
        dr.text((10, 75), f"pose_err={pose_err:.4f} rad   support4={int((fn>=3).all())}   "
                          f"nonwheel={nonwheel}", fill=(200, 200, 200), font=small)
        ff.stdin.write(np.asarray(img).tobytes())
        n_frames += 1
        next_frame_t += 1.0 / FPS
ff.stdin.close()
err = ff.stderr.read().decode("utf-8", "replace")
ff.wait()

state = np.asarray([[r[k] for k in r] for r in rows], dtype=object)
cols = list(rows[0].keys())
with open(os.path.join(OUT, "prone_hipfirst_200hz.csv"), "w", newline="", encoding="utf-8") as f:
    wr = csv.DictWriter(f, fieldnames=cols)
    wr.writeheader()
    wr.writerows(rows)


def mean_pre(rows, t0_, t1_):
    sel = [r for r in rows if t0_ <= r["t"] < t1_]
    return sel


def stats(sel):
    A = {k: np.array([r[k] for r in sel], dtype=float) for k in sel[0] if k not in ("phase",)}
    return dict(
        z=round(float(A["z"].mean()), 4), tilt_p95=round(float(np.quantile(A["tilt"], .95)), 2),
        support4=round(float(A["support4"].mean()), 3), nonwheel=int(A["nonwheel"].max()),
        pose_err=round(float(A["pose_err"].mean()), 4),
        hip={l: round(float(A[f"q_act_{l}_hip"].mean()), 4) for l in ("FL", "FR", "RL", "RR")},
        calf={l: round(float(A[f"q_act_{l}_calf"].mean()), 4) for l in ("FL", "FR", "RL", "RR")},
        thigh={l: round(float(A[f"q_act_{l}_thigh"].mean()), 4) for l in ("FL", "FR", "RL", "RR")},
        tau_rms=round(float(np.sqrt((np.array([[A[f"tau_{n}"] for n in MJ_LEGS]]) ** 2).mean())), 2),
        tau_peak=round(float(np.abs([[A[f"tau_{n}"] for n in MJ_LEGS]]).max()), 2),
        fn={n: round(float(A[f"fn_{n}"].mean()), 1) for n in WH})


summary = dict(
    run_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    script_sha256=hashlib.sha256(open(__file__, "rb").read()).hexdigest(),
    xml=XML, xml_sha256=hashlib.sha256(open(XML, "rb").read()).hexdigest(),
    timeline=dict(hip_first=[0.0, T_HIP], extend_3s=[T_HIP, T_EXT_END], hold_200_4=[T_EXT_END, T_HOLD_END],
                  hold_55_2=[T_HOLD_END, T_END]),
    video=dict(path=vid_path, fps=FPS, resolution=list(RES), frames=n_frames, frames_expected=frames_expected,
               duration_s=T_END, ffmpeg_err=err.strip()[:200],
               sha256=(hashlib.sha256(open(vid_path, "rb").read()).hexdigest() if os.path.isfile(vid_path) else None)),
    phases=dict(
        hip_first=stats(mean_pre(rows, 0.2, T_HIP)),
        extend=stats(mean_pre(rows, T_HIP + 0.2, T_EXT_END)),
        hold_200_4=stats(mean_pre(rows, T_EXT_END + 0.5, T_HOLD_END - 0.2)),
        hold_55_2=stats(mean_pre(rows, T_END - 2.0, T_END))),
    fall=bool(fall), t_fall=t_fall,
    wall_s=round(time.time() - t0, 1))
json.dump(summary, open(os.path.join(OUT, "summary.json"), "w"), indent=2, ensure_ascii=False)
print("VIDEO", vid_path, os.path.getsize(vid_path), "frames", n_frames, "/", frames_expected)
print("sha", summary["video"]["sha256"])
for ph, s in summary["phases"].items():
    print(ph, "z", s["z"], "hip", s["hip"], "calf", s["calf"], "pose", s["pose_err"],
          "tilt95", s["tilt_p95"], "sup4", s["support4"], "nonwheel", s["nonwheel"],
          "tauRMS", s["tau_rms"], "peak", s["tau_peak"], "fn", s["fn"])
print("fall", fall, "wall", summary["wall_s"], "s")
