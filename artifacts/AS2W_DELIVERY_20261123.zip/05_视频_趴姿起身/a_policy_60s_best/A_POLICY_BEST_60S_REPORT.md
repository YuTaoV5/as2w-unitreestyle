# A_POLICY_BEST_60S_REPORT — 最佳姿态权重 C1_s42_200 的 60 s 全场景视频（格子地面 + 轮距/轴距叠加）

> 任务：用户反馈 T15（A 权重）转向前后/左右轮明显过近；对比 13 个权重后选"姿态最好"的重做 60 s 视频。
> 范围：仅 MuJoCo；未接实机/publisher/未改包。Run UTC **2026-11-23T10:28–10:41Z（18:28–18:41+08）**，wall 781 s。
> 模型：`as2w_stand200_grid.xml`（26.000 kg，μ=0.35，effort 60/60/90 & 15 Nm，checker 地面），200 Hz 物理 / 30 fps 渲染。

## 0. 视频（ffprobe 已验证 60 s / 1800 帧）

- **路径**：`/root/as2w/mujoco-sim2sim-20261121/videos/a_policy_60s_best/a_policy_60s_best_grid.mp4`
- **SHA256**：`17bce4e05d4cf155309b55ebdb6440d4982b314d2df853d32b59a47604ba409e`
- **ffprobe**：`h264`，`960×540`，`30/1 fps`，**1800 帧 / 60.000000 s**，size **8,288,487 B**，yuv420p、faststart（可直接播放）。
- 抽帧（t=2/20/37/42/52/58 s）全部为机器人+格子画面（sat 4.9–6.3）；t=37 s 帧叠加显示 **wheelbase=0.379 m、trackF=0.255 m、trackR=0.413 m、minPair=0.258 m**（绿色），可直观看到轮距/轴距。

## 1. 选中的权重

| 项 | 值 |
|---|---|
| 名称 | **C1_s42_200**（DR3C 修正版 C1 采样器，seed42，200 步） |
| ckpt | `/root/gpufree-data/as2w-runs/retrain-dr3c-20261122/c1_s42/train/model_199.pt` |
| SHA256 | `572898f0e9897f5d03d32febb1bed60952a727662a074269bcc36f370550b3fb` |
| 合同 | 58 obs / 12 act，tanh(raw)×0.25 + 5 Hz LPF，腿 55/2，轮合同；与 A 完全同一套 obs/act 映射 |

**为什么是它**（详见 `WEIGHT_ATTITUDE_COMPARISON.md`，13 候选对比）：20 s 姿态筛选中 **前轮距最小保持 0.588、轮间最小距 0.224 m（两者全候选最高）**、hip 误差 **0.123（最低）**、tilt95 **6.3°/max 7.0°**（低）、z 0.409–0.469、support4 0.750、无 fall。相对 A：前轮距最小 **+87%**、轮间最小距 **+37%**、hip 误差 **−23%**、tilt95 **−3.6°**、tiltmax **−6.4°**。严格按 support4 优先排序第一的 DR3a_s42_400 是"低趴换支撑"（tilt95 23.7°、z min 0.330），姿态更差，不作演示。

## 2. 视频内容（与 T15 同场景）

0–10 s：OG ai_damping 趴姿 → 1.4 s 只收髋（200/4）→ 3 s 伸腿 → hold（200/4）→ 7.4 s 切 **55/2**；10–60 s C1_s42_200 按 T15 全命令范围（vx±0.8、vy±0.45、wz±0.8，8 段×6.25 s，slew 1.0 s；**exact mixed (0.4,0.25,−0.3) 在 MuJoCo 不稳定 → 沿用 mixed_safe=(0.4,0.10,−0.3)**，与 T15 一致并已标注）。
叠加：phase/时间/segment、腿增益、**cmd vs ACTUAL vx,vy,wz**、odom x,y,yaw、z/tilt、support4/nonwheel/fall/cmd_viol、12 关节 q/tau 数值与 bar（>0.8×effort 或 q 超软限位标红）、**wheelbase/trackF/trackR/minPair 数值（过近变红）**、左下固定 world-map PiP、右下 top-down 轨迹。

## 3. 结果

| 验收项 | 结果 |
|---|---|
| 60 s fall | **0 fall**（0 帧；tilt95 段最大 8.8°，z 0.429–0.470） |
| 实际位移 | **净位移 (x,y) = (2.67, +2.73) m**；yaw 净 +0.6°（正反打平） |
| vx 跟踪 | fwd +0.8 → **+0.711**（+3.13 m/5 s）；rev −0.8 → **−0.697**（−3.07 m/5 s） |
| vy 跟踪 | left +0.45 → **+0.413**（+1.81 m）；right −0.45 → **−0.311**（−1.35 m） |
| wz 跟踪 | wz +0.8 → **+0.747**（yaw +188.6°）；wz −0.8 → **−0.773**（yaw −195.0°） |
| 弧线/混合 | arc(+0.5,+0.4) → act (+0.43,+0.33)，位移 (+1.58,+0.73)；mixed_safe → (+0.40,−0.27) |
| 轮距/轴距（名义 stance：wb 0.4241 m / trackF 0.3807 / trackR 0.3751 / minPair 0.3751） | 60 s 内最小：**wb 0.3162（74.6%）**、**trackF 0.1502（39.5%）**、**trackR 0.2084（55.6%）**、**minPair 0.1518（40.5%）**；t=37 s yaw 帧 wb 0.379（89%）、trackF 0.255（67%）、trackR 0.413（110%）、minPair 0.258 |
| 越限 | τ>0.8×effort **0 帧**（τ 峰 28.03 Nm < 48）；q 软限位无越界；非轮触地 0；命令越界 0 |
| 支撑 | support4 6804/10000 帧（68%）；高速横移/原地转时瞬时轮载下降（打滑），无 fall |
| 55/2 handoff | 掉高 **1.34 cm**（0.4436→0.4302）、calf 软 0.087/0.105 rad、hip Δ≤0.0037 rad |

**结论**：C1_s42_200 在同样全命令范围内 60 s 稳定无跌倒、跟踪好，且转向时轮距/轴距保持明显优于 A（20 s 筛选中前轮距最小 0.224 vs A 0.120 m；轮间最小距离 0.224 vs A 0.163 m）。注意：**最激进段（vy 横移/wz 急转）几何仍会收缩**（trackF 最低到名义 39.5%），这是该模型 4 轮滑移转向的物理限制；C1 只是 13 个候选中保持最好的，不等于"绝不收缩"。

## 4. 限制

- MuJoCo 理想 PD/轮伺服、无电流环/齿隙/强 stiction/机体自碰撞；轮距判定基于 `geom_xpos` 轮心，support4 基于 Fn≥3 N。
- 60 s 中 10–60 s 为策略在 MuJoCo 内开环执行（obs 由仿真状态构造，无感知/通信延迟）。
- exact mixed 不稳定（A 与 C1 均如此），主视频用 mixed_safe 并已标注；真实部署应先把该组合加入 gate 或降幅。
- 渲染：X 共享 GL 读回污染 → 每帧新建 Renderer + 饱和度校验；world-map PiP 每 2 帧刷新。

## 5. 产物（/root/as2w/mujoco-sim2sim-20261121/）

| 文件 | 大小 (B) | SHA256 |
|---|---|---|
| `videos/a_policy_60s_best/a_policy_60s_best_grid.mp4` | 8,288,487 | `17bce4e05d4cf155309b55ebdb6440d4982b314d2df853d32b59a47604ba409e` |
| `results/a_policy_60s_best/a_policy_60s_best_200hz.csv` | 14,008,564 | `67076000e0463c359074819d3b71e8024cee5e1bc75184e9684a5c9435f3da86` |
| `results/a_policy_60s_best/summary.json` | 7,251 | `5f723e1c6f28cac87809dd9ca495879ce4cefa14fe5f6fb95c2c56e6edd48051` |
| `a_policy_best_60s.py` | 24,125 | `e67206fa991dfe41aec5e9ec48c008ac2e8fd3cfcbf73461b9343512c92e87d7` |
| `WEIGHT_ATTITUDE_COMPARISON.md` | 6,490 | `d2f8f97d53f8f98a1cc9a0717279fe989b5ffa209ec14ecf171e995bbcde2f15` |
| `results/t16_screen/screen.json` | 11,890 | `efb1f0cfdce56885b7169c010a26910e26e3160e425083247fa71f9b37acf1c4` |
| `results/t16_screen/screen.csv` | 5,360 | `5701930a10d03eb956eba65022fefd1724efe5fcb59fe597c7b2fce87885c496` |

CSV 列（200 Hz，12000 行）：`t, phase, seg, kp, kv, cmd_vx/vy/wz, q_12, q_tgt_12, tau_12, wdq_4, w_tgt_4, x, y, yaw, z, roll, pitch, tilt, pose_err, vx, vy, wz, vx_world, vy_world, wheelbase, track_front, track_rear, min_pair, fn_4, support4, nonwheel, cmd_viol, fall`。
复现：`OMP_NUM_THREADS=2 /root/as2w/preflight/isaac-python a_policy_best_60s.py --ckpt /root/gpufree-data/as2w-runs/retrain-dr3c-20261122/c1_s42/train/model_199.pt --tag C1_s42_200`（约 13 min）。
