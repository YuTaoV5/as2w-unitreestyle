﻿"""T15: 60 s full-range A-policy MuJoCo video (960x540@30fps, H.264, grid floor).

0-10 s: same stand-up as T13/T14 (prone -> hip-first -> 3 s extend -> hold -> 55/2 at 7.4 s)
10-60 s: A policy (deploy ONNX sha 63f1c5b6..., 58 obs / 12 act, 50 Hz, legs 55/2, wheel contract)
         full training command range, 10 segments x 5 s with 0.5 s slew:
         zero -> fwd +0.8 -> rev -0.8 -> left vy +0.45 -> right vy -0.45
         -> yaw wz +0.8 -> yaw wz -0.8 -> arc (vx 0.5, wz 0.4)
         -> mixed (vx 0.4, vy 0.25, wz -0.3) -> stop
Overlay: phase/time/segment, cmd vs ACTUAL vx,vy,wz, leg gains, z/tilt, support4/nonwheel/fall,
         base odometry x,y,yaw, mini top-down trajectory; per-joint q/tau bars with red flags.
--check skips rendering and prints per-segment displacement/velocity for a fast movement check.
"""
import argparse
import csv
import hashlib
import json
import math
import os
import subprocess
import time

import numpy as np
import torch
import mujoco
import onnxruntime as ort
from PIL import Image, ImageDraw, ImageFont

import harness as H

ap = argparse.ArgumentParser()
ap.add_argument("--check", action="store_true")
ap.add_argument("--no-video", action="store_true")
ap.add_argument("--ckpt", default="")
ap.add_argument("--onnx", default="")
ap.add_argument("--tag", default="best")
args = ap.parse_args()

W = "/root/as2w/mujoco-sim2sim-20261121"
os.chdir(W)
OUT = os.path.join(W, "results", "a_policy_60s_prelift_best")
VID = os.path.join(W, "videos", "a_policy_60s_prelift_best")
os.makedirs(OUT, exist_ok=True)
os.makedirs(VID, exist_ok=True)
ONNX = args.onnx or "/root/as2w/retrain-wheeldiff-v41-20261121/deploy_v4x/pkg/policy.onnx"
ONNX_SHA_EXPECT = "63f1c5b6a6bf5c7fd9fdcaa09cce93deb5aa5c81dc97c96e6c0dd72bf7ab64ee"
USE_PT = bool(args.ckpt)
if USE_PT:
    PT_NET, _ = H.load_policy(args.ckpt)
    PT_SHA = hashlib.sha256(open(args.ckpt, "rb").read()).hexdigest()
RES = (960, 540)
FPS = 30
T_END = 60.0
DT = 0.005
T_PRE, T_HIPEND, T_EXTEND, T_HOLD, T_POLICY = 0.60, 2.00, 5.00, 8.00, 10.0
PRE_DTH, PRE_DCA = 0.20, 0.20
PRONE_HIP = {"FR": -0.562, "FL": 0.574, "RR": -0.556, "RL": 0.573}
PRONE_THIGH, PRONE_CALF = 1.019, -2.762
T2_HIP = {"FR": 0.15, "FL": -0.15, "RR": 0.15, "RL": -0.15}
T2_THIGH, T2_CALF = 0.60, -1.20
MJ_LEGS = H.LEGS
WH = H.WHEELS
LEG_LIM = np.array([{"hip": 60.0, "thigh": 60.0, "calf": 90.0}[n.split("_")[1]] for n in MJ_LEGS])
XML_SRC = os.path.join(W, "as2w_stand200.xml")
XML_GRID = os.path.join(W, "as2w_stand200_grid.xml")


def build_grid_xml():
    if os.path.isfile(XML_GRID):
        return
    t = open(XML_SRC, encoding="utf-8").read()
    tex = ('<texture name="grid_tex" type="2d" builtin="checker" rgb1="0.18 0.20 0.24" '
           'rgb2="0.52 0.55 0.60" width="512" height="512"/>'
           '<material name="grid_mat" texture="grid_tex" texrepeat="12 12" specular="0.15" shininess="0.2"/>')
    t = t.replace("</asset>", tex + "</asset>", 1)
    old_floor = '<geom name="floor" type="plane" size="0 0 0.05" pos="0 0 0" friction="0.35 0.005 0.0001"'
    new_floor = ('<geom name="floor" type="plane" size="0 0 0.05" pos="0 0 0" material="grid_mat" '
                 'friction="0.35 0.005 0.0001"')
    assert old_floor in t
    t = t.replace(old_floor, new_floor, 1)
    open(XML_GRID, "w", encoding="utf-8").write(t)


build_grid_xml()
if USE_PT:
    ONNX_SHA = PT_SHA
    sess = None
else:
    ONNX_SHA = hashlib.sha256(open(ONNX, "rb").read()).hexdigest()
    assert ONNX_SHA == ONNX_SHA_EXPECT
    sess = ort.InferenceSession(ONNX, providers=["CPUExecutionProvider"])
    inp = sess.get_inputs()[0]
    inp_name = inp.name


def policy(obs):
    """returns tanh(raw) action (contract: offset = tanh(raw)*0.25)."""
    if USE_PT:
        raw = PT_NET(torch.from_numpy(obs.reshape(1, 58).astype(np.float32))).detach().numpy().reshape(-1)[:12]
        return np.tanh(raw)
    out = sess.run(None, {inp_name: obs.reshape(1, 58).astype(np.float32)})[0]
    return np.asarray(out, dtype=np.float64).reshape(-1)[:12]


sim = H.MyoSim(XML_GRID)
m, d = sim.m, sim.d
sim.target = np.zeros(16)
m.vis.global_.offwidth = RES[0]
m.vis.global_.offheight = RES[1]
LEG_AID = [sim.aid[n] for n in MJ_LEGS]
WH_AID = [sim.aid[n] for n in WH]
LEG_QADR = [sim.qadr[n] for n in MJ_LEGS]
WH_QADR = [sim.qadr[n] for n in WH]
LEG_DADR = [sim.dadr[n] for n in MJ_LEGS]
WHEEL_GEOMS = []
for n in WH:
    b = m.body(n).id
    WHEEL_GEOMS.append([g for g in range(m.ngeom) if m.geom_bodyid[g] == b and m.geom_contype[g] != 0][0])
FLOOR = int(m.geom("floor").id)
Q_PRONE = np.array([PRONE_HIP[l] if n.endswith("_hip") else (PRONE_THIGH if n.endswith("_thigh") else PRONE_CALF)
                    for l in ("FL", "FR", "RL", "RR") for n in [l + "_hip", l + "_thigh", l + "_calf"]])
Q_T2 = H.DEFAULT_JOINT[:12].copy()
Q_LO = np.zeros(12); Q_HI = np.zeros(12)
for k, n in enumerate(MJ_LEGS):
    r = m.jnt_range[m.joint(n).id]
    span = r[1] - r[0]
    Q_LO[k] = r[0] + 0.05 * span
    Q_HI[k] = r[1] - 0.05 * span


def set_gains(kp, kv, wheel_kv=0.5):
    for aid in LEG_AID:
        m.actuator_gainprm[aid, 0] = kp
        m.actuator_biasprm[aid, 1] = -kp
        m.actuator_biasprm[aid, 2] = -kv
    for aid in WH_AID:
        m.actuator_gainprm[aid, 0] = wheel_kv
        m.actuator_biasprm[aid, 0] = 0.0
        m.actuator_biasprm[aid, 1] = 0.0
        m.actuator_biasprm[aid, 2] = -wheel_kv


def contacts():
    fn = np.zeros(4)
    nonwheel = 0
    for i in range(d.ncon):
        c = d.contact[i]
        g1, g2 = int(c.geom1), int(c.geom2)
        if FLOOR not in (g1, g2):
            continue
        other = g2 if g1 == FLOOR else g1
        res = np.zeros(6)
        mujoco.mj_contactForce(m, d, i, res)
        if other in WHEEL_GEOMS:
            fn[WHEEL_GEOMS.index(other)] += abs(res[0])
        else:
            nonwheel += 1
    return fn, nonwheel


def apply_action_embedded(act_tanh, cmd, snap=True):
    a = np.asarray(act_tanh, dtype=np.float64) * 0.25
    sim.target[:12] = sim.target[:12] + H.ALPHA * (a - sim.target[:12])
    wt = H.wheel_targets(cmd)
    sim.target[12:] = sim.target[12:] + H.ALPHA * (wt - sim.target[12:])
    if snap and abs(cmd[0]) < 1e-9 and abs(cmd[2]) < 1e-9:
        sim.target[12:][np.abs(sim.target[12:]) < 0.02] = 0.0
    for k, n in enumerate(MJ_LEGS):
        d.ctrl[sim.aid[n]] = H.DEFAULT_JOINT[k] + sim.target[k]
    for k, n in enumerate(WH):
        d.ctrl[sim.aid[n]] = sim.target[12 + k]


# ---- init prone ----
mujoco.mj_resetData(m, d)
for k, a in enumerate(LEG_QADR):
    d.qpos[a] = Q_PRONE[k]
for a in WH_QADR:
    d.qpos[a] = 0.0
d.qpos[0:2] = 0.0
d.qpos[3:7] = [1.0, 0.0, 0.0, 0.0]


def hit():
    for i in range(d.ncon):
        c = d.contact[i]
        g1, g2 = int(c.geom1), int(c.geom2)
        if FLOOR in (g1, g2) and ((g2 if g1 == FLOOR else g1) in WHEEL_GEOMS):
            return True
    return False


lo, hi = 0.02, 0.60
for _ in range(40):
    mid = 0.5 * (lo + hi)
    d.qpos[2] = mid
    d.qvel[:] = 0
    mujoco.mj_forward(m, d)
    if hit():
        lo = mid
    else:
        hi = mid
d.qpos[2] = hi + 1e-4
mujoco.mj_forward(m, d)
for _ in range(100):
    set_gains(200, 4)
    for k, aid in enumerate(LEG_AID):
        d.ctrl[aid] = Q_PRONE[k]
    for aid in WH_AID:
        d.ctrl[aid] = 0.0
    mujoco.mj_step(m, d)

# ---- full-range command schedule ----
SEGS = [
    ("zero", 0.0, 0.0, 0.0),
    ("fwd_p08", 0.8, 0.0, 0.0),
    ("rev_n08", -0.8, 0.0, 0.0),
    ("left_vy045", 0.0, 0.45, 0.0),
    ("right_vy045", 0.0, -0.45, 0.0),
    ("yaw_p08", 0.0, 0.0, 0.8),
    ("yaw_n08", 0.0, 0.0, -0.8),
    ("arc_p05p04", 0.5, 0.0, 0.4),
    ("mixed_safe", 0.4, 0.10, -0.3),
    ("stop", 0.0, 0.0, 0.0),
]
SEG_LEN = (T_END - T_POLICY) / len(SEGS)      # 5.0 s
SLEW = 1.0


def policy_cmd(t):
    if t < T_POLICY:
        return np.zeros(3), None
    rel = t - T_POLICY
    k = min(len(SEGS) - 1, int(rel / SEG_LEN))
    name, vx, vy, wz = SEGS[k]
    cmd = np.array([vx, vy, wz])
    seg_t0 = k * SEG_LEN
    if k > 0 and rel < seg_t0 + SLEW:
        prev = np.array([SEGS[k - 1][1], SEGS[k - 1][2], SEGS[k - 1][3]])
        a = (rel - seg_t0) / SLEW
        cmd = prev + a * (cmd - prev)
    return cmd, name


# camera: tracking base so the robot stays in frame; the checker floor slides -> motion visible;
# additionally the overlay shows odometry x/y/yaw and a top-down trajectory inset.
cam = mujoco.MjvCamera()
cam.type = mujoco.mjtCamera.mjCAMERA_TRACKING
cam.trackbodyid = m.body("base_link").id
cam.distance = 2.6
cam.elevation = -28
cam.azimuth = 140
cam_map = mujoco.MjvCamera()
cam_map.type = mujoco.mjtCamera.mjCAMERA_FREE
cam_map.lookat = [0.0, 0.0, 0.25]
cam_map.distance = 16.0
cam_map.elevation = -70.0
cam_map.azimuth = 90.0
inset_img = None
font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 17)
mid_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14)
small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 12)

vid_path = os.path.join(VID, "a_policy_60s_prelift_best_grid.mp4")
ff = None
if not args.check and not args.no_video:
    ff = subprocess.Popen(["ffmpeg", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24",
                           "-s", f"{RES[0]}x{RES[1]}", "-r", str(FPS), "-i", "-", "-an",
                           "-vcodec", "libx264", "-pix_fmt", "yuv420p", "-crf", "21",
                           "-preset", "medium", "-movflags", "+faststart", "-g", "60",
                           "-loglevel", "error", vid_path],
                          stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

def knee_clearance():
    return min(float(d.xpos[m.body(f"{l}_calf").id][2]) for l in ("FL", "FR", "RL", "RR"))


def wheel_geometry():
    """body-frame wheelbase (front-rear) and front/rear track from wheel centres."""
    Rq = H.quat_to_mat(d.qpos[3:7])
    p0 = np.array([d.qpos[0], d.qpos[1], d.qpos[2]])
    pts = np.array([Rq.T @ (d.geom_xpos[g] - p0) for g in WHEEL_GEOMS])
    wb = float(0.5 * (pts[0, 0] + pts[1, 0]) - 0.5 * (pts[2, 0] + pts[3, 0]))
    tf = float(pts[0, 1] - pts[1, 1])
    tr = float(pts[2, 1] - pts[3, 1])
    mp = min(float(np.linalg.norm(pts[i] - pts[j])) for i in range(4) for j in range(i + 1, 4))
    return wb, tf, tr, mp


wb_nom = tf_nom = tr_nom = mp_nom = None
rows = []
nsteps = int(round(T_END / DT))
frame_idx = 0
n_frames = 0
fall = False
t_fall = None
t_start = time.time()
traj = []
for i in range(nsteps):
    t = i * DT
    if t < T_POLICY:
        if t < T_PRE:
            a = t / T_PRE
            hip = dict(PRONE_HIP)
            thigh = PRONE_THIGH + a * PRE_DTH
            calf = PRONE_CALF + a * PRE_DCA
            phase, kp, kv = "PRE_LIFT", 200.0, 4.0
        elif t < T_HIPEND:
            a = (t - T_PRE) / (T_HIPEND - T_PRE)
            hip = {l: PRONE_HIP[l] + a * (T2_HIP[l] - PRONE_HIP[l]) for l in ("FR", "FL", "RR", "RL")}
            thigh, calf = PRONE_THIGH + PRE_DTH, PRONE_CALF + PRE_DCA
            phase, kp, kv = "HIP", 200.0, 4.0
        elif t < T_EXTEND:
            a = (t - T_HIPEND) / (T_EXTEND - T_HIPEND)
            hip = dict(T2_HIP)
            thigh = (PRONE_THIGH + PRE_DTH) + a * (T2_THIGH - (PRONE_THIGH + PRE_DTH))
            calf = (PRONE_CALF + PRE_DCA) + a * (T2_CALF - (PRONE_CALF + PRE_DCA))
            phase, kp, kv = "EXTEND", 200.0, 4.0
        elif t < T_HOLD:
            hip, thigh, calf = dict(T2_HIP), T2_THIGH, T2_CALF
            phase, kp, kv = "HOLD_200_4", 200.0, 4.0
        else:
            hip, thigh, calf = dict(T2_HIP), T2_THIGH, T2_CALF
            phase, kp, kv = "HOLD_55_2", 55.0, 2.0
        q_tgt = np.array([hip[l] if n.endswith("_hip") else (thigh if n.endswith("_thigh") else calf)
                          for l in ("FL", "FR", "RL", "RR") for n in [l + "_hip", l + "_thigh", l + "_calf"]])
        set_gains(kp, kv)
        for k, aid in enumerate(LEG_AID):
            d.ctrl[aid] = q_tgt[k]
        for aid in WH_AID:
            d.ctrl[aid] = 0.0
        sim.target[:12] = q_tgt - H.DEFAULT_JOINT[:12]
        sim.target[12:] = 0.0
        cmd = np.zeros(3)
        seg_name = phase
    else:
        cmd, seg_name = policy_cmd(t)
        set_gains(55.0, 2.0)
        obs = sim.observe(cmd)
        act_tanh = policy(obs)
        apply_action_embedded(act_tanh, cmd)
        q_tgt = H.DEFAULT_JOINT[:12] + sim.target[:12]
        phase, kp, kv = "A_policy", 55.0, 2.0
    mujoco.mj_step(m, d)
    w, x, y, z = d.qpos[3:7]
    roll = math.degrees(math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y)))
    pitch = math.degrees(math.asin(max(-1, min(1, 2 * (w * y - z * x)))))
    tilt = math.degrees(math.acos(max(-1.0, min(1.0, 1 - 2 * (x * x + y * y)))))
    yaw = math.degrees(math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z)))
    if i == 0:
        yaw_u = yaw
        yaw_prev = yaw
    else:
        dyaw_w = ((yaw - yaw_prev + 180.0) % 360.0) - 180.0
        yaw_u = yaw_u + dyaw_w
        yaw_prev = yaw
    q = np.array([d.qpos[a] for a in LEG_QADR])
    tau = np.array([d.qfrc_actuator[a] for a in LEG_AID])
    wdq = np.array([d.qvel[sim.dadr[n]] for n in WH])
    fn, nonwheel = contacts()
    # body-frame velocities (contract terms) and world-frame displacement
    R = H.quat_to_mat(d.qpos[3:7])
    vb = R.T @ d.qvel[0:3]
    pose_err = float(np.mean(np.abs(q - q_tgt)))
    cmd_viol = bool((t >= T_POLICY) and (abs(cmd[0]) > 0.8 + 1e-9 or abs(cmd[1]) > 0.45 + 1e-9
                                         or abs(cmd[2]) > 0.8 + 1e-9))
    if not fall and (tilt > 70 or (t >= T_POLICY + 1.0 and d.qpos[2] < 0.12)):
        fall, t_fall = True, t
    px, py = float(d.qpos[0]), float(d.qpos[1])
    wb, tf, tr, mp = wheel_geometry()
    knee_z = knee_clearance()
    if wb_nom is None and t >= T_POLICY - 1e-9:
        wb_nom, tf_nom, tr_nom, mp_nom = wb, tf, tr, mp
    if i % 20 == 0:
        traj.append((px, py))
    rows.append(dict(t=round(t, 3), phase=phase, seg="" if seg_name is None else seg_name,
                     kp=kp, kv=kv,
                     cmd_vx=float(cmd[0]), cmd_vy=float(cmd[1]), cmd_wz=float(cmd[2]),
                     **{f"q_{n}": float(q[k]) for k, n in enumerate(MJ_LEGS)},
                     **{f"q_tgt_{n}": float(q_tgt[k]) for k, n in enumerate(MJ_LEGS)},
                     **{f"tau_{n}": float(tau[k]) for k, n in enumerate(MJ_LEGS)},
                     **{f"wdq_{n}": float(wdq[k]) for k, n in enumerate(WH)},
                     **{f"w_tgt_{n}": float(sim.target[12 + k]) for k, n in enumerate(WH)},
                     x=px, y=py, yaw=yaw_u, z=float(d.qpos[2]),
                     wheelbase=wb, track_front=tf, track_rear=tr, min_pair=mp, knee_z=knee_z,
                     roll=roll, pitch=pitch, tilt=tilt, pose_err=round(pose_err, 5),
                     vx=float(vb[0]), vy=float(vb[1]), wz=float(d.qvel[5]),
                     vx_world=float(d.qvel[0]), vy_world=float(d.qvel[1]),
                     **{f"fn_{n}": float(fn[k]) for k, n in enumerate(WH)},
                     support4=float((fn >= 3.0).all()), nonwheel=int(nonwheel),
                     cmd_viol=int(cmd_viol), fall=int(fall)))
    # ---------- render ----------
    if ff is not None and not fall and t + 0.5 * DT >= frame_idx / FPS:
        img = None
        arr = None
        for attempt in range(5):
            r = mujoco.Renderer(m, RES[1], RES[0])
            r.update_scene(d, camera=cam)
            arr = r.render()
            del r
            a = arr.astype(np.float32)
            sat = float((a.max(axis=2) - a.min(axis=2)).mean())
            if sat < 25.0:
                img = Image.fromarray(arr)
                break
        if img is None:
            img = Image.fromarray(arr)
        dr = ImageDraw.Draw(img, "RGBA")
        dr.rectangle([0, 0, RES[0], 76], fill=(0, 0, 0, 235))
        dr.text((8, 3), f"t={t:5.2f}s  phase={phase}  seg={seg_name if seg_name else '-'}  "
                        f"gains kp={kp:.0f}/kv={kv:.0f}", fill=(255, 255, 0), font=font)
        dr.text((8, 25), f"cmd vx={cmd[0]:+.2f} vy={cmd[1]:+.2f} wz={cmd[2]:+.2f}   "
                         f"ACT vx={vb[0]:+.2f} vy={vb[1]:+.2f} wz={d.qvel[5]:+.2f}",
                fill=(120, 255, 120), font=mid_font)
        dr.text((8, 43), f"odom x={px:+.2f} y={py:+.2f} yaw={yaw_u:+.1f}deg  z={d.qpos[2]:.3f}  tilt={tilt:4.1f}deg",
                fill=(220, 220, 220), font=mid_font)
        wb_line = f"wb={wb:.3f}m trackF={tf:.3f}m trackR={tr:.3f}m minPair={mp:.3f}m kneeZ={knee_z:.3f}m"
        fcol = (255, 120, 120) if (wb_nom is not None and (wb < 0.9 * wb_nom or tf < 0.6 * tf_nom or tr < 0.7 * tr_nom)) else (200, 255, 200)
        dr.text((8, 60), wb_line, fill=fcol, font=small)
        flags = f"support4={int((fn >= 3.0).all())} nonwheel={nonwheel} fall={int(fall)} cmd_viol={int(cmd_viol)}"
        dr.text((640, 43), flags, fill=(255, 80, 80) if (nonwheel or fall or cmd_viol) else (200, 200, 200), font=small)
        # picture-in-picture: fixed world camera (shows actual translation on the grid)
        if frame_idx % 2 == 0:
            try:
                r2 = mujoco.Renderer(m, 168, 300)
                r2.update_scene(d, camera=cam_map)
                inset_img = Image.fromarray(r2.render()).resize((300, 168))
                del r2
            except Exception:
                pass
        if inset_img is not None:
            img.paste(inset_img, (320, 372))
            dr.rectangle([318, 370, 622, 542], outline=(140, 140, 140))
            dr.text((322, 372), "world map camera (fixed grid)", fill=(180, 220, 255), font=small)
        # left joint panel
        px0, py0 = 8, 80
        dr.rectangle([px0 - 4, py0 - 3, px0 + 300, RES[1] - 4], fill=(0, 0, 0, 190))
        dr.text((px0, py0), "joint        q[rad]    tau[Nm]  (tau bar / limit)", fill=(180, 220, 255), font=small)
        py0 += 16
        for k, n in enumerate(MJ_LEGS):
            lim = LEG_LIM[k]
            tau_hi = abs(tau[k]) > 0.8 * lim
            q_bad = (q[k] < Q_LO[k]) or (q[k] > Q_HI[k])
            c = (255, 70, 70) if (tau_hi or q_bad) else (200, 255, 200)
            dr.text((px0, py0), f"{n:10s} {q[k]:+7.3f} {tau[k]:+7.2f}", fill=c, font=small)
            bx0, bx1 = px0 + 175, px0 + 292
            bcy = py0 + 6
            dr.rectangle([bx0, bcy - 4, bx1, bcy + 4], outline=(90, 90, 90))
            frac = max(-1.0, min(1.0, tau[k] / lim))
            if frac >= 0:
                dr.rectangle([bx0 + 58, bcy - 4, bx0 + 58 + frac * 56, bcy + 4],
                             fill=(255, 70, 70) if tau_hi else (90, 200, 90))
            else:
                dr.rectangle([bx0 + 58 + frac * 56, bcy - 4, bx0 + 58, bcy + 4],
                             fill=(255, 70, 70) if tau_hi else (90, 200, 90))
            dr.line([bx0 + 58, bcy - 5, bx0 + 58, bcy + 5], fill=(160, 160, 160))
            py0 += 36
        # mini top-down trajectory inset (bottom-right)
        ix0, iy0, iw, ih = RES[0] - 210, RES[1] - 150, 200, 140
        dr.rectangle([ix0, iy0, ix0 + iw, iy0 + ih], fill=(0, 0, 0, 200), outline=(120, 120, 120))
        dr.text((ix0 + 4, iy0 + 2), "top-down trajectory (x-y)", fill=(180, 220, 255), font=small)
        if traj:
            xs = [p[0] for p in traj] + [px]
            ys = [p[1] for p in traj] + [py]
            xmin, xmax = min(xs), max(xs); ymin, ymax = min(ys), max(ys)
            sx = max(1e-3, xmax - xmin); sy = max(1e-3, ymax - ymin)
            sc = min((iw - 20) / sx, (ih - 30) / sy)
            def mp(x_, y_):
                return (ix0 + 10 + (x_ - xmin) * sc, iy0 + ih - 10 - (y_ - ymin) * sc)
            pts = [mp(a_, b_) for a_, b_ in traj] + [mp(px, py)]
            if len(pts) > 1:
                dr.line(pts, fill=(120, 200, 255), width=2)
            dr.ellipse([mp(px, py)[0] - 3, mp(px, py)[1] - 3, mp(px, py)[0] + 3, mp(px, py)[1] + 3],
                       fill=(255, 120, 120))
        ff.stdin.write(np.asarray(img).tobytes())
        n_frames += 1
        frame_idx += 1
if ff is not None:
    ff.stdin.close()
    err = ff.stderr.read().decode("utf-8", "replace")
    ff.wait()

cols = list(rows[0].keys())
with open(os.path.join(OUT, "a_policy_60s_prelift_best_200hz.csv"), "w", newline="", encoding="utf-8") as f:
    wr = csv.DictWriter(f, fieldnames=cols)
    wr.writeheader()
    wr.writerows(rows)

T = np.array([r["t"] for r in rows])


def sel(t0, t1):
    return [r for r in rows if t0 <= r["t"] < t1]


def agg(rs):
    if not rs:
        return {}
    A = {k: np.array([r[k] for r in rs], dtype=float) for k in rs[0] if k not in ("phase", "seg")}
    tau = np.array([[A[f"tau_{n}"] for n in MJ_LEGS]])
    return dict(z=round(float(A["z"].mean()), 4),
                tilt_p95=round(float(np.quantile(A["tilt"], .95)), 2),
                tilt_max=round(float(A["tilt"].max()), 2),
                support4=round(float(A["support4"].mean()), 3),
                nonwheel_max=int(A["nonwheel"].max()),
                cmd=[round(float(A["cmd_vx"].mean()), 4), round(float(A["cmd_vy"].mean()), 4),
                     round(float(A["cmd_wz"].mean()), 4)],
                act=[round(float(A["vx"].mean()), 4), round(float(A["vy"].mean()), 4),
                     round(float(A["wz"].mean()), 4)],
                tau_peak=round(float(np.abs(tau).max()), 2),
                sat_frac=round(float((np.abs(tau) > 0.98 * LEG_LIM[:, None]).mean()), 5),
                red_frames=int(((np.abs(tau[0]) > 0.8 * LEG_LIM[:, None]).any(axis=0)).sum()),
                cmd_viol=int(A["cmd_viol"].sum()), fall=int(A["fall"].sum()))


segments = {}
for k, (name, vx, vy, wz) in enumerate(SEGS):
    t0 = T_POLICY + k * SEG_LEN
    rs = sel(t0 + 0.6, t0 + SEG_LEN)
    if not rs:
        continue
    a = agg(rs)
    A = {kk: np.array([r[kk] for r in rs], dtype=float) for kk in rs[0] if kk not in ("phase", "seg")}
    a["disp_xy"] = [round(float(A["x"][-1] - A["x"][0]), 3), round(float(A["y"][-1] - A["y"][0]), 3)]
    a["dyaw_deg"] = round(float(A["yaw"][-1] - A["yaw"][0]), 2)
    segments[name] = a

final_x = float(np.array([r["x"] for r in sel(T_POLICY, T_END)])[-1])
final_y = float(np.array([r["y"] for r in sel(T_POLICY, T_END)])[-1])
yy = np.array([r["yaw"] for r in sel(T_POLICY, T_END)])
summary = dict(
    run_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    script_sha256=hashlib.sha256(open(__file__, "rb").read()).hexdigest(),
    onnx=ONNX, onnx_sha256=ONNX_SHA, xml=XML_GRID,
    video=dict(path=(vid_path if ff is not None else None), fps=FPS, resolution=list(RES),
               frames=n_frames, duration_s=T_END,
               size=(os.path.getsize(vid_path) if os.path.isfile(vid_path) else None),
               sha256=(hashlib.sha256(open(vid_path, "rb").read()).hexdigest()
                       if os.path.isfile(vid_path) else None),
               ffmpeg_err=(err.strip()[:200] if ff is not None else "")),
    fall=bool(fall), t_fall=t_fall,
    weight=dict(ckpt=(args.ckpt or None), onnx=(None if USE_PT else ONNX), sha256=ONNX_SHA, tag=args.tag),
    geometry=dict(wheelbase_nominal=round(wb_nom, 4), track_front_nominal=round(tf_nom, 4),
                  track_rear_nominal=round(tr_nom, 4), min_pair_nominal=round(mp_nom, 4),
                  wheelbase_min=round(float(np.min([r["wheelbase"] for r in sel(T_POLICY, T_END)])), 4),
                  track_front_min=round(float(np.min([r["track_front"] for r in sel(T_POLICY, T_END)])), 4),
                  track_rear_min=round(float(np.min([r["track_rear"] for r in sel(T_POLICY, T_END)])), 4),
                  min_pair_min=round(float(np.min([r["min_pair"] for r in sel(T_POLICY, T_END)])), 4),
                  knee_min_standup=round(float(np.min([r["knee_z"] for r in rows if r["t"] < T_POLICY])), 4),
                  knee_min_policy=round(float(np.min([r["knee_z"] for r in sel(T_POLICY, T_END)])), 4)),
    policy_total_displacement_xy=[round(final_x, 3), round(final_y, 3)],
    policy_yaw_net_deg=round(float(yy[-1] - yy[0]), 2),
    policy_yaw_range_deg=[round(float(yy.min()), 2), round(float(yy.max()), 2)],
    segments=segments,
    standup=agg(sel(0.0, T_POLICY)),
    handoff=dict(pre=agg(sel(5.4, 7.4)), post=agg(sel(7.6, 9.9))),
    wall_s=round(time.time() - t_start, 1))
json.dump(summary, open(os.path.join(OUT, "summary.json"), "w"), indent=2, ensure_ascii=False)
print("fall", fall, "t_fall", t_fall, "displacement", summary["policy_total_displacement_xy"],
      "yaw_net", summary["policy_yaw_net_deg"], "frames", n_frames)
for name, s in segments.items():
    print(f"{name:12s} cmd {s['cmd']} act {s['act']} disp_xy {s['disp_xy']} dyaw {s['dyaw_deg']} "
          f"z {s['z']:.3f} tilt95 {s['tilt_p95']:.1f} sup4 {s['support4']:.2f} red {s['red_frames']} "
          f"taupeak {s['tau_peak']:.1f}")
print("handoff", summary["handoff"].get("pre"), "->", summary["handoff"].get("post"))
if ff is not None:
    print("VIDEO", vid_path, summary["video"]["size"], summary["video"]["sha256"])
print("wall", summary["wall_s"])
