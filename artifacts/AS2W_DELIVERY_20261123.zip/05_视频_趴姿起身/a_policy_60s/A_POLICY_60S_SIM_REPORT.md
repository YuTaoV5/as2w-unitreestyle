# A_POLICY_60S_SIM_REPORT — 60 s 连续仿真视频（起身切换 55/2 → A 策略多场景，格子地面）

> 任务：仅 MuJoCo，不接实机/不启动 publisher/不改包；60 s 连续视频 + 逐帧数据。
> Run UTC **2026-11-23T09:28–09:38Z（17:28–17:38+08）**；wall 542 s。脚本 `a_policy_60s_grid.py`（SHA256 见产物表）。
> A 策略：部署 ONNX `/root/as2w/retrain-wheeldiff-v41-20261121/deploy_v4x/pkg/policy.onnx`，**SHA256 `63f1c5b6a6bf5c7fd9fdcaa09cce93deb5aa5c81dc97c96e6c0dd72bf7ab64ee`**（已校验）；58 obs / 12 act，50 Hz；腿 55/2，轮合同（vx/0.086 ± wz*(B/2)/(0.086·0.415)，clamp ±12，5 Hz LPF+零速吸附）。
> 模型：`as2w_stand200_grid.xml` = `as2w_stand200.xml`（26.000 kg，μ=0.35，effort 60/60/90 & 15 Nm）+ checker 地面材质；200 Hz 物理、30 fps 渲染。

## 0. 视频（先验可播放）

- **路径**：`/root/as2w/mujoco-sim2sim-20261121/videos/a_policy_60s/a_policy_60s_grid.mp4`
- **SHA256**：`9b5cbc73561778a93dda01ee98b2a82316e8cb87c210995088de10d8aaa4ff0a`
- **ffprobe**：`h264`，`960×540`，`30/1 fps`，**1800 帧 / 60.000000 s**，size **5,052,180 B**，yuv420p、faststart（可播放；抽帧 6 点均为机器人+格子地面画面，sat 6.3–7.0）。
- 画面叠加：`phase / t / segment / 腿增益 kp,kv / cmd vx,vy,wz / body z / tilt / support4 / nonwheel / fall / cmd_viol`；左侧 **12 关节 q 数值 + tau 数值 + tau bar**，越限（|tau|>0.8×effort 或 q 超软限位）标红；fall/非轮触地/命令越界也红。

## 1. 时间线

| 时间 | 内容 | 腿增益 |
|---|---|---|
| 0–1.4 s | 趴姿（官方 OG ai_damping raw hip FR −0.562/FL +0.574/RR −0.556/RL +0.573）→ 官方 ±0.15，只收髋 | 200/4 |
| 1.4–4.4 s | 伸腿 3 s：thigh +1.019→+0.60、calf −2.762→−1.20，hip 保持 | 200/4 |
| 4.4–7.4 s | 保持官方 t2 | 200/4 |
| 7.4–10 s | 保持官方 t2 | **55/2** |
| 10–60 s | **A 策略** 8 段 ×6.25 s（命令 0.5 s slew）：zero → fwd +0.05 → fwd +0.10 → rev −0.05 → yaw +0.05 → yaw +0.10 → yaw −0.05 → zero | 55/2 |

> 注：A 部署 ONNX 已内嵌 `tanh`（实测 ONNX_out = tanh(pt_raw)），因此仿真里按合同直接取 `target_leg += LPF(tanh_out*0.25)`，不再二次 tanh（脚本 `apply_action_embedded`）；obs 58、wheel 合同与训练评测一致。

## 2. 验收结果

| 验收项 | 结果 |
|---|---|
| **60 s 是否 fall** | **无 fall**（0 帧；tilt 最大 3.3°，support4 全程 1.00） |
| 非轮触地 / 命令越界 | **0 / 0 帧** |
| 力矩越限 | τ>0.8×effort **0 帧**；τ>0.98×effort **0 帧**；峰值 13.66 Nm（起身段），策略段峰值 ≤10.7 Nm |
| 55/2 handoff 膝软/掉高 | **掉高 1.34 cm**（z 0.4436→0.4302）；calf 软塌 前 −0.087 / 后 −0.105 rad；thigh −0.027~−0.042；hip 保持（Δ≤0.0037 rad） |
| A 稳定性 | 8 段全部 support4=1.00、tilt≤3.3°、无 fall、无越限 |

## 3. 分段跟踪（稳态，去掉 0.6 s slew）

| 段 | cmd (vx,wz) | 实测 (vx,wz) | 跟踪比 |
|---|---|---|---|
| zero | (0, 0) | (−0.003, −0.001) | ~0 |
| fwd_005 | (+0.05, 0) | (+0.016, −0.003) | **32%** |
| fwd_010 | (+0.10, 0) | (+0.078, +0.012) | **78%** |
| rev_005 | (−0.05, 0) | (−0.038, −0.007) | **75%** |
| yaw_p005 | (0, +0.05) | (+0.003, **+0.005**) | **11%** |
| yaw_p010 | (0, +0.10) | (−0.001, **+0.014**) | **14%** |
| yaw_n005 | (0, −0.05) | (−0.002, **−0.014**) | **27%** |
| zero2 | (0, 0) | (0.000, 0.000) | ~0 |

**读法**：方向都正确；但 **低速段跟踪偏弱**——vx 0.05 仅 32%，yaw 0.05/0.10 仅 11–14%。这与本 MuJoCo 模型“轮 velocity 伺服 kv=2 + 轮 frictionloss 0.15 + 接触摩擦”造成的**低速死区**一致（需要约 0.9 rad/s 轮目标 ≈ vx 0.077 / wz 0.15 才越过静摩擦；T2/60s 遥控审计也复现过同一现象）。**这是仿真侧模型限制，不能直接判 A 策略实机差**；vx 0.10（78%）与 rev 0.05（75%）已接近正常。

## 4. 结论

1. **60 s 连续无 fall、无越限、无非轮触地、无命令越界**；姿态平稳（tilt≤3.3°），四轮支撑全程 1.0。
2. **55/2 handoff 有膝软/掉高但不失控**：掉高 1.34 cm、calf 软 0.087–0.105 rad，hip 内收保持（Δ≤0.0037 rad）；与 T11/T13 结论一致。
3. **响应方向正确，低速幅值偏弱**：vx 0.10 78%、rev 0.05 75%，vx 0.05 32%，yaw 11–27%（MuJoCo 轮伺服低速死区所致，需实机/Isaac 对照）。
4. 视频叠加的红色越限告警在整段视频中**未触发**（0 帧），可作“无越限”的直观证据。

## 5. 限制

- MuJoCo 理想 PD/轮伺服、无电流环/齿隙/强 stiction/机体自碰撞；低速 yaw/小 vx 的跟踪弱是模型侧现象，不能外推实机。
- 60 s 中 10–60 s 为 A 策略开环在 MuJoCo 中执行（obs 由 MuJoCo 状态构造，无感知/通信延迟）；真实部署的延迟/handoff 未建模。
- 渲染：本机 X server 共享 GL 上下文读回会被桌面污染，采用**每帧新建 Renderer + 饱和度校验**，1800 帧全部为机器人画面。

## 6. 产物（/root/as2w/mujoco-sim2sim-20261121/）

| 文件 | 大小 (B) | SHA256 |
|---|---|---|
| `videos/a_policy_60s/a_policy_60s_grid.mp4` | 5,052,180 | `9b5cbc73561778a93dda01ee98b2a82316e8cb87c210995088de10d8aaa4ff0a` |
| `results/a_policy_60s/a_policy_60s_200hz.csv` | 11,155,887 | `8b12e7d0ad183cbecbd0170338489b78007b83b757a69793a3850c75e2dd9231` |
| `results/a_policy_60s/summary.json` | 4,883 | `26dfccbaae5340d3ebbd9dc597c0dc291f187908430b218ba27cd04bf3e91fb1` |
| `a_policy_60s_grid.py` | 18,666 | 见交付消息 |
| `as2w_stand200_grid.xml` | — | 见交付消息 |

CSV 列：`t, phase, seg, kp, kv, cmd_vx/vy/wz, q_12, q_tgt_12, tau_12, wdq_4, z, roll, pitch, tilt, pose_err, fn_4, support4, nonwheel, cmd_viol, fall, vx, wz`（200 Hz，12000 行）。
复现：`OMP_NUM_THREADS=2 /root/as2w/preflight/isaac-python a_policy_60s_grid.py`（约 9 min，含 1800 帧渲染）。
