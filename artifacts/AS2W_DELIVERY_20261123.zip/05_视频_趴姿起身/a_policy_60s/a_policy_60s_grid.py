﻿"""T14: 60 s continuous MuJoCo video (960x540@30fps, H.264, grid floor):
  0-10 s  prone -> hip-first (1.4 s) -> 3 s leg extension -> hold (200/4) -> 55/2
  10-60 s A policy (ONNX sha 63f1c5b6..., 58 obs / 12 act, 50 Hz, legs 55/2, wheel contract)
          command schedule with slew: zero -> fwd .05 -> fwd .10 -> rev .05 -> yaw +.05
          -> yaw +.10 -> yaw -.05 -> zero  (8 x 6.25 s)
Overlay: phase/time, cmd, leg gains, z/tilt, 4-wheel support / non-wheel contact,
         per-joint q and tau bars with red flags (tau>0.8*effort or q outside soft range;
         fall / non-wheel contact / command violation also red).
MuJoCo only, 26 kg / mu=0.35, no robot / publisher.
"""
import csv
import hashlib
import json
import math
import os
import subprocess
import time

import numpy as np
import torch
import mujoco
import onnxruntime as ort
from PIL import Image, ImageDraw, ImageFont

import harness as H

W = "/root/as2w/mujoco-sim2sim-20261121"
os.chdir(W)
OUT = os.path.join(W, "results", "a_policy_60s")
VID = os.path.join(W, "videos", "a_policy_60s")
os.makedirs(OUT, exist_ok=True)
os.makedirs(VID, exist_ok=True)
ONNX = "/root/as2w/retrain-wheeldiff-v41-20261121/deploy_v4x/pkg/policy.onnx"
ONNX_SHA_EXPECT = "63f1c5b6a6bf5c7fd9fdcaa09cce93deb5aa5c81dc97c96e6c0dd72bf7ab64ee"
import argparse
_ap = argparse.ArgumentParser()
_ap.add_argument("--preview", type=float, default=0.0)
_args = _ap.parse_args()
RES = (960, 540)
FPS = 30
T_END = 60.0
if _args.preview > 0:
    T_END = min(T_END, _args.preview)
DT = 0.005
SUB = 4
# stand-up timeline
T_HIP, T_EXT, T_HOLD, T_POLICY = 1.4, 4.4, 7.4, 10.0
# official prone raw hip q and official t2
PRONE_HIP = {"FR": -0.562, "FL": 0.574, "RR": -0.556, "RL": 0.573}
PRONE_THIGH, PRONE_CALF = 1.019, -2.762
T2_HIP = {"FR": 0.15, "FL": -0.15, "RR": 0.15, "RL": -0.15}
T2_THIGH, T2_CALF = 0.60, -1.20
MJ_LEGS = H.LEGS
WH = H.WHEELS
LEG_LIM = np.array([{"hip": 60.0, "thigh": 60.0, "calf": 90.0}[n.split("_")[1]] for n in MJ_LEGS])
# soft q limits (from MJCF jnt_range with 5% margin)
XML_SRC = os.path.join(W, "as2w_stand200.xml")
XML_GRID = os.path.join(W, "as2w_stand200_grid.xml")


def build_grid_xml():
    if os.path.isfile(XML_GRID):
        os.remove(XML_GRID)          # always rebuild from the validated source XML
    t = open(XML_SRC, encoding="utf-8").read()
    tex = ('<texture name="grid_tex" type="2d" builtin="checker" rgb1="0.18 0.20 0.24" '
           'rgb2="0.52 0.55 0.60" width="512" height="512"/>'
           '<material name="grid_mat" texture="grid_tex" texrepeat="12 12" specular="0.15" shininess="0.2"/>')
    assert "</asset>" in t
    t = t.replace("</asset>", tex + "</asset>", 1)
    old_floor = '<geom name="floor" type="plane" size="0 0 0.05" pos="0 0 0" friction="0.35 0.005 0.0001"'
    new_floor = ('<geom name="floor" type="plane" size="0 0 0.05" pos="0 0 0" material="grid_mat" '
                 'friction="0.35 0.005 0.0001"')
    assert old_floor in t, "floor geom anchor missing"
    t = t.replace(old_floor, new_floor, 1)
    open(XML_GRID, "w", encoding="utf-8").write(t)


build_grid_xml()
ONNX_SHA = hashlib.sha256(open(ONNX, "rb").read()).hexdigest()
assert ONNX_SHA == ONNX_SHA_EXPECT, ONNX_SHA
sess = ort.InferenceSession(ONNX, providers=["CPUExecutionProvider"])
inp = sess.get_inputs()[0]
inp_name = inp.name
inp_shape = inp.shape
if len(inp_shape) == 2 and inp_shape[1] == 58:
    feed = lambda obs: {inp_name: obs.reshape(1, 58).astype(np.float32)}
else:
    feed = lambda obs: {inp_name: obs.reshape(58).astype(np.float32)}


def policy(obs):
    out = sess.run(None, feed(obs))[0]
    return np.asarray(out, dtype=np.float64).reshape(-1)[:12]


def apply_action_embedded(act_tanh, cmd, snap=True):
    """deploy ONNX already contains tanh(raw); contract target = tanh(raw)*0.25."""
    a = np.asarray(act_tanh, dtype=np.float64) * 0.25
    sim.target[:12] = sim.target[:12] + H.ALPHA * (a - sim.target[:12])
    wt = H.wheel_targets(cmd)
    sim.target[12:] = sim.target[12:] + H.ALPHA * (wt - sim.target[12:])
    if snap and abs(cmd[0]) < 1e-9 and abs(cmd[2]) < 1e-9:
        sim.target[12:][np.abs(sim.target[12:]) < 0.02] = 0.0
    for k, n in enumerate(MJ_LEGS):
        d.ctrl[sim.aid[n]] = H.DEFAULT_JOINT[k] + sim.target[k]
    for k, n in enumerate(WH):
        d.ctrl[sim.aid[n]] = sim.target[12 + k]


sim = H.MyoSim(XML_GRID)
m, d = sim.m, sim.d
sim.target = np.zeros(16)
m.vis.global_.offwidth = RES[0]
m.vis.global_.offheight = RES[1]
LEG_AID = [sim.aid[n] for n in MJ_LEGS]
WH_AID = [sim.aid[n] for n in WH]
LEG_QADR = [sim.qadr[n] for n in MJ_LEGS]
WH_QADR = [sim.qadr[n] for n in WH]
LEG_DADR = [sim.dadr[n] for n in MJ_LEGS]
WHEEL_GEOMS = []
for n in WH:
    b = m.body(n).id
    WHEEL_GEOMS.append([g for g in range(m.ngeom) if m.geom_bodyid[g] == b and m.geom_contype[g] != 0][0])
FLOOR = int(m.geom("floor").id)
Q_PRONE = np.array([PRONE_HIP[l] if n.endswith("_hip") else (PRONE_THIGH if n.endswith("_thigh") else PRONE_CALF)
                    for l in ("FL", "FR", "RL", "RR") for n in [l + "_hip", l + "_thigh", l + "_calf"]])
Q_T2 = H.DEFAULT_JOINT[:12].copy()          # official t2 == default stance
# soft limits: from model joint ranges, 5% margin inside
Q_LO = np.zeros(12); Q_HI = np.zeros(12)
for k, n in enumerate(MJ_LEGS):
    r = m.jnt_range[m.joint(n).id]
    span = r[1] - r[0]
    Q_LO[k] = r[0] + 0.05 * span
    Q_HI[k] = r[1] - 0.05 * span


def set_gains(kp, kv, wheel_kv=0.5):
    for aid in LEG_AID:
        m.actuator_gainprm[aid, 0] = kp
        m.actuator_biasprm[aid, 1] = -kp
        m.actuator_biasprm[aid, 2] = -kv
    for aid in WH_AID:
        m.actuator_gainprm[aid, 0] = wheel_kv
        m.actuator_biasprm[aid, 0] = 0.0
        m.actuator_biasprm[aid, 1] = 0.0
        m.actuator_biasprm[aid, 2] = -wheel_kv


def contacts():
    fn = np.zeros(4)
    nonwheel = 0
    for i in range(d.ncon):
        c = d.contact[i]
        g1, g2 = int(c.geom1), int(c.geom2)
        if FLOOR not in (g1, g2):
            continue
        other = g2 if g1 == FLOOR else g1
        res = np.zeros(6)
        mujoco.mj_contactForce(m, d, i, res)
        if other in WHEEL_GEOMS:
            fn[WHEEL_GEOMS.index(other)] += abs(res[0])
        else:
            nonwheel += 1
    return fn, nonwheel


# ---- init prone ----
mujoco.mj_resetData(m, d)
for k, a in enumerate(LEG_QADR):
    d.qpos[a] = Q_PRONE[k]
for a in WH_QADR:
    d.qpos[a] = 0.0
d.qpos[0:2] = 0.0
d.qpos[3:7] = [1.0, 0.0, 0.0, 0.0]


def hit():
    for i in range(d.ncon):
        c = d.contact[i]
        g1, g2 = int(c.geom1), int(c.geom2)
        if FLOOR in (g1, g2) and ((g2 if g1 == FLOOR else g1) in WHEEL_GEOMS):
            return True
    return False


lo, hi = 0.02, 0.60
for _ in range(40):
    mid = 0.5 * (lo + hi)
    d.qpos[2] = mid
    d.qvel[:] = 0
    mujoco.mj_forward(m, d)
    if hit():
        lo = mid
    else:
        hi = mid
d.qpos[2] = hi + 1e-4
mujoco.mj_forward(m, d)
for _ in range(100):
    set_gains(200, 4)
    for k, aid in enumerate(LEG_AID):
        d.ctrl[aid] = Q_PRONE[k]
    for aid in WH_AID:
        d.ctrl[aid] = 0.0
    mujoco.mj_step(m, d)

# ---- command schedule for the A policy phase ----
SEGS = [
    ("zero", 0.0, 0.0), ("fwd_005", 0.05, 0.0), ("fwd_010", 0.10, 0.0),
    ("rev_005", -0.05, 0.0), ("yaw_p005", 0.0, 0.05), ("yaw_p010", 0.0, 0.10),
    ("yaw_n005", 0.0, -0.05), ("zero2", 0.0, 0.0),
]
SEG_LEN = (T_END - T_POLICY) / len(SEGS)     # 6.25 s
SLEW = 0.5


def policy_cmd(t):
    if t < T_POLICY:
        return np.zeros(3), None
    rel = t - T_POLICY
    k = min(len(SEGS) - 1, int(rel / SEG_LEN))
    name, vx, wz = SEGS[k]
    cmd = np.array([vx, 0.0, wz])
    seg_t0 = k * SEG_LEN
    if k > 0 and rel < seg_t0 + SLEW:
        prev = np.array([SEGS[k - 1][1], 0.0, SEGS[k - 1][2]])
        a = (rel - seg_t0) / SLEW
        cmd = prev + a * (cmd - prev)
    return cmd, name


cam = mujoco.MjvCamera()
cam.type = mujoco.mjtCamera.mjCAMERA_TRACKING
cam.trackbodyid = m.body("base_link").id
cam.distance = 2.2
cam.elevation = -24
cam.azimuth = 135
font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 18)
mid_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14)
small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 12)

vid_path = os.path.join(VID, ("preview_" if _args.preview > 0 else "") + "a_policy_60s_grid.mp4")
ff = subprocess.Popen(["ffmpeg", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24",
                       "-s", f"{RES[0]}x{RES[1]}", "-r", str(FPS), "-i", "-", "-an",
                       "-vcodec", "libx264", "-pix_fmt", "yuv420p", "-crf", "21",
                       "-preset", "medium", "-movflags", "+faststart", "-g", "60",
                       "-loglevel", "error", vid_path],
                      stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

rows = []
nsteps = int(round(T_END / DT))
frame_idx = 0
n_frames = 0
fall = False
t_fall = None
t_start = time.time()
obs = None
q_tgt_hold = Q_T2.copy()
for i in range(nsteps):
    t = i * DT
    if t < T_POLICY:
        # ---------------- stand-up phase (direct targets) ----------------
        if t < T_HIP:
            a = t / T_HIP
            hip = {l: PRONE_HIP[l] + a * (T2_HIP[l] - PRONE_HIP[l]) for l in ("FR", "FL", "RR", "RL")}
            thigh, calf = PRONE_THIGH, PRONE_CALF
            phase, kp, kv = "H_hip_first", 200.0, 4.0
        elif t < T_EXT:
            a = (t - T_HIP) / (T_EXT - T_HIP)
            hip = dict(T2_HIP)
            thigh = PRONE_THIGH + a * (T2_THIGH - PRONE_THIGH)
            calf = PRONE_CALF + a * (T2_CALF - PRONE_CALF)
            phase, kp, kv = "K_extend3s", 200.0, 4.0
        elif t < T_HOLD:
            hip, thigh, calf = dict(T2_HIP), T2_THIGH, T2_CALF
            phase, kp, kv = "hold_200_4", 200.0, 4.0
        else:
            hip, thigh, calf = dict(T2_HIP), T2_THIGH, T2_CALF
            phase, kp, kv = "hold_55_2", 55.0, 2.0
        q_tgt = np.array([hip[l] if n.endswith("_hip") else (thigh if n.endswith("_thigh") else calf)
                          for l in ("FL", "FR", "RL", "RR") for n in [l + "_hip", l + "_thigh", l + "_calf"]])
        set_gains(kp, kv)
        for k, aid in enumerate(LEG_AID):
            d.ctrl[aid] = q_tgt[k]
        for aid in WH_AID:
            d.ctrl[aid] = 0.0
        sim.target[:12] = q_tgt - H.DEFAULT_JOINT[:12]
        sim.target[12:] = 0.0
        cmd = np.zeros(3)
        seg_name = phase
    else:
        # ---------------- A policy phase ----------------
        cmd, seg_name = policy_cmd(t)
        set_gains(55.0, 2.0)
        obs = sim.observe(cmd)
        act_tanh = policy(obs)
        apply_action_embedded(act_tanh, cmd)
        q_tgt = H.DEFAULT_JOINT[:12] + sim.target[:12]
        phase = "A_policy"
        kp, kv = 55.0, 2.0
    mujoco.mj_step(m, d)
    w, x, y, z = d.qpos[3:7]
    roll = math.degrees(math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y)))
    pitch = math.degrees(math.asin(max(-1, min(1, 2 * (w * y - z * x)))))
    tilt = math.degrees(math.acos(max(-1.0, min(1.0, 1 - 2 * (x * x + y * y)))))
    q = np.array([d.qpos[a] for a in LEG_QADR])
    dq = np.array([d.qvel[a] for a in LEG_DADR])
    tau = np.array([d.qfrc_actuator[a] for a in LEG_AID])
    wdq = np.array([d.qvel[sim.dadr[n]] for n in WH])
    fn, nonwheel = contacts()
    pose_err = float(np.mean(np.abs(q - q_tgt)))
    cmd_viol = bool((t >= T_POLICY) and (abs(cmd[0]) > 0.10 + 1e-9 or abs(cmd[2]) > 0.10 + 1e-9 or abs(cmd[1]) > 1e-9))
    if not fall and t > 1.0 and (tilt > 70 or d.qpos[2] < 0.12):
        fall, t_fall = True, t
    rows.append(dict(t=round(t, 3), phase=phase, seg="" if seg_name is None else seg_name,
                     kp=kp, kv=kv,
                     cmd_vx=float(cmd[0]), cmd_vy=float(cmd[1]), cmd_wz=float(cmd[2]),
                     **{f"q_{n}": float(q[k]) for k, n in enumerate(MJ_LEGS)},
                     **{f"q_tgt_{n}": float(q_tgt[k]) for k, n in enumerate(MJ_LEGS)},
                     **{f"tau_{n}": float(tau[k]) for k, n in enumerate(MJ_LEGS)},
                     **{f"wdq_{n}": float(wdq[k]) for k, n in enumerate(WH)},
                     z=float(d.qpos[2]), roll=roll, pitch=pitch, tilt=tilt, pose_err=round(pose_err, 5),
                     **{f"fn_{n}": float(fn[k]) for k, n in enumerate(WH)},
                     support4=float((fn >= 3.0).all()), nonwheel=int(nonwheel),
                     cmd_viol=int(cmd_viol), fall=int(fall),
                     vx=float(d.qvel[0]), wz=float(d.qvel[5])))
    # ---------- render one frame ----------
    next_t = frame_idx / FPS
    if t + 0.5 * DT >= next_t and not fall:
        img = None
        arr = None
        for attempt in range(5):
            r = mujoco.Renderer(m, RES[1], RES[0])
            r.update_scene(d, camera=cam)
            arr = r.render()
            del r
            a = arr.astype(np.float32)
            sat = float((a.max(axis=2) - a.min(axis=2)).mean())
            if sat < 25.0:
                img = Image.fromarray(arr)
                break
        if img is None:
            img = Image.fromarray(arr)
        dr = ImageDraw.Draw(img, "RGBA")
        # top bar
        dr.rectangle([0, 0, RES[0], 58], fill=(0, 0, 0, 230))
        dr.text((8, 3), f"t={t:5.2f}s  phase={phase}  seg={seg_name if seg_name else '-'}  "
                        f"gains kp={kp:.0f}/kv={kv:.0f}", fill=(255, 255, 0), font=font)
        cmd_txt = f"cmd vx={cmd[0]:+.2f} vy={cmd[1]:+.2f} wz={cmd[2]:+.2f}"
        dr.text((8, 26), cmd_txt + f"   z={d.qpos[2]:.3f}m  tilt={tilt:4.1f}deg", fill=(230, 230, 230), font=mid_font)
        flags = f"support4={int((fn >= 3.0).all())}  nonwheel={nonwheel}  fall={int(fall)}  cmd_viol={int(cmd_viol)}"
        colour = (255, 80, 80) if (nonwheel or fall or cmd_viol) else (200, 200, 200)
        dr.text((520, 26), flags, fill=colour, font=mid_font)
        # left panel: 12 joints q/tau with bars + red flags
        px, py = 8, 64
        dr.rectangle([px - 4, py - 3, px + 300, RES[1] - 4], fill=(0, 0, 0, 190))
        dr.text((px, py), "joint        q[rad]    tau[Nm]  (tau bar / limit)", fill=(180, 220, 255), font=small)
        py += 16
        for k, n in enumerate(MJ_LEGS):
            lim = LEG_LIM[k]
            tau_hi = abs(tau[k]) > 0.8 * lim
            q_bad = (q[k] < Q_LO[k]) or (q[k] > Q_HI[k])
            c = (255, 70, 70) if (tau_hi or q_bad) else (200, 255, 200)
            dr.text((px, py), f"{n:10s} {q[k]:+7.3f} {tau[k]:+7.2f}", fill=c, font=small)
            bx0, bx1 = px + 175, px + 292
            bcy = py + 6
            dr.rectangle([bx0, bcy - 4, bx1, bcy + 4], outline=(90, 90, 90))
            frac = max(-1.0, min(1.0, tau[k] / lim))
            if frac >= 0:
                dr.rectangle([bx0 + 58, bcy - 4, bx0 + 58 + frac * 56, bcy + 4],
                             fill=(255, 70, 70) if tau_hi else (90, 200, 90))
            else:
                dr.rectangle([bx0 + 58 + frac * 56, bcy - 4, bx0 + 58, bcy + 4],
                             fill=(255, 70, 70) if tau_hi else (90, 200, 90))
            dr.line([bx0 + 58, bcy - 5, bx0 + 58, bcy + 5], fill=(160, 160, 160))
            py += 36
        # wheel row
        wy = py + 2
        dr.text((px, wy), "wheel dq: " + "  ".join(f"{n[:2]} {wdq[k]:+.2f}" for k, n in enumerate(WH)),
                fill=(200, 220, 255), font=small)
        ff.stdin.write(np.asarray(img).tobytes())
        n_frames += 1
        frame_idx += 1
ff.stdin.close()
err = ff.stderr.read().decode("utf-8", "replace")
ff.wait()

cols = list(rows[0].keys())
with open(os.path.join(OUT, "a_policy_60s_200hz.csv"), "w", newline="", encoding="utf-8") as f:
    wr = csv.DictWriter(f, fieldnames=cols)
    wr.writeheader()
    wr.writerows(rows)

# ---------- summary ----------
T = np.array([r["t"] for r in rows])


def sel(t0, t1):
    return [r for r in rows if t0 <= r["t"] < t1]


def agg(rs):
    if not rs:
        return {}
    A = {k: np.array([r[k] for r in rs], dtype=float) for k in rs[0] if k not in ("phase", "seg")}
    tau = np.array([[A[f"tau_{n}"] for n in MJ_LEGS]]).reshape(12, -1)
    return dict(z=numeric(A["z"]), tilt_p95=round(float(np.quantile(A["tilt"], .95)), 2),
                tilt_max=round(float(A["tilt"].max()), 2),
                support4=round(float(A["support4"].mean()), 3),
                nonwheel_max=int(A["nonwheel"].max()),
                vx=round(float(A["vx"].mean()), 4), wz=round(float(A["wz"].mean()), 4),
                cmd_vx=round(float(A["cmd_vx"].mean()), 4), cmd_wz=round(float(A["cmd_wz"].mean()), 4),
                tau_peak=round(float(np.abs(tau).max()), 2),
                tau_rms=round(float(np.sqrt((tau ** 2).mean())), 2),
                sat_frac=round(float((np.abs(tau) > 0.98 * LEG_LIM[:, None]).mean()), 5),
                cmd_viol=int(A["cmd_viol"].sum()), fall=int(A["fall"].sum()))


def numeric(x):
    return round(float(np.mean(x)), 4)


summary = dict(
    run_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    script_sha256=hashlib.sha256(open(__file__, "rb").read()).hexdigest(),
    onnx=ONNX, onnx_sha256=ONNX_SHA,
    xml=XML_GRID, xml_sha256=hashlib.sha256(open(XML_GRID, "rb").read()).hexdigest(),
    video=dict(path=vid_path, fps=FPS, resolution=list(RES), frames=n_frames,
               duration_s=T_END, size=os.path.getsize(vid_path) if os.path.isfile(vid_path) else None,
               sha256=hashlib.sha256(open(vid_path, "rb").read()).hexdigest() if os.path.isfile(vid_path) else None,
               ffmpeg_err=err.strip()[:200]),
    fall=bool(fall), t_fall=t_fall,
    phase_groups=dict(standup_0_10=agg(sel(0.0, T_POLICY)),
                      policy_10_60=agg(sel(T_POLICY, T_END))),
    segments={name: agg(sel(T_POLICY + k * SEG_LEN, T_POLICY + (k + 1) * SEG_LEN))
              for k, (name, _, _) in enumerate(SEGS)},
    handoff_55_2=dict(pre=agg(sel(5.4, 7.4)), post=agg(sel(7.6, 9.9))),
    wall_s=round(time.time() - t_start, 1))
json.dump(summary, open(os.path.join(OUT, "summary.json"), "w"), indent=2, ensure_ascii=False)
print("VIDEO", vid_path, os.path.getsize(vid_path), "frames", n_frames, "/", int(T_END * FPS))
print("sha", summary["video"]["sha256"])
print("fall", fall, "t_fall", t_fall)
for name, s in summary["segments"].items():
    print(f"{name:10s} vx {s['cmd_vx']:+.3f}->{s['vx']:+.3f} wz {s['cmd_wz']:+.3f}->{s['wz']:+.3f} "
          f"z {s['z']:.3f} tilt95 {s['tilt_p95']:.1f} sup4 {s['support4']:.2f} nonwheel {s['nonwheel_max']} "
          f"taupeak {s['tau_peak']:.1f}")
print("handoff", summary["handoff_55_2"]["pre"], "\n     ->", summary["handoff_55_2"]["post"])
print("wall", summary["wall_s"])
