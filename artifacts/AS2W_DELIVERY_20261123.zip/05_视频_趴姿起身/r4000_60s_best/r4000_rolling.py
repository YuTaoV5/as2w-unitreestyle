"""r4000 (16-act / 65-obs rolling) MuJoCo sim after the unified pre-lift stand-up.

Contract implemented EXACTLY as the r4000 training source snapshot
(runs/rolling/filtered-4000-env4096-stage020.ovvRL3/source):
  JOINTS order  = part-major: 4x hip, 4x thigh, 4x calf, 4x foot
                  FL,FR,RL,RR within each part
  default pose  = hip 0.0, thigh +0.80, calf -1.60, wheel 0
  obs 65 = [ cmd-(0.4,0,0) (3), root_ang_vel_b (3), projected_gravity_b (3), 0.4 (1),
             q16 (12 leg offsets + 4 wheel angles wrapped +-2pi),
             dq16 (raw rad/s), policy_action16 (previous raw actor output),
             sin(clock) (1), cos(clock) (1),
             zero-wheel-memory (4 dr*?, 1 flag) ]
  clock = 2*pi*step*0.02/0.62
  action chain: 5 Hz leg LPF -> rolling_fixed_exit(gyro_z, wheel_dq) -> wheel_hold
                -> precalibrated stand (continuous, straight_only) -> 0.9 rad/s slew
  ctrl: legs = clip(default + 0.35*legs, contract 90% ranges); wheels = clip(16*w,-98.47,98.47)
  gains kp 55 / kd 2 ; effort caps hip/thigh 54, calf 81, wheel 13.5 Nm
"""
import argparse
import csv
import hashlib
import json
import math
import os
import subprocess
import time

import numpy as np
import mujoco
from PIL import Image, ImageDraw, ImageFont

ap = argparse.ArgumentParser()
ap.add_argument("--ckpt", default="")
ap.add_argument("--onnx", default="")
ap.add_argument("--tag", default="cand")
ap.add_argument("--mode", default="screen", choices=("screen", "video", "check"))
ap.add_argument("--policy-seconds", type=float, default=20.0)
ap.add_argument("--segs", default="")
ap.add_argument("--res", default="960x540")
ap.add_argument("--out-suffix", default="")
args = ap.parse_args()

W = "/root/as2w/mujoco-sim2sim-20261121"
os.chdir(W)
SUF = args.out_suffix or args.tag
OUT = os.path.join(W, "results", f"r4000_{args.mode}_{SUF}")
VID = os.path.join(W, "videos", f"r4000_{args.mode}_{SUF}")
os.makedirs(OUT, exist_ok=True)
os.makedirs(VID, exist_ok=True)
XML = os.path.join(W, "as2w_stand200_grid.xml")
RES = tuple(int(v) for v in args.res.lower().split("x"))
FPS = 30
DT = 0.005
SUB = 4
PDT = DT * SUB                      # 0.02

# ---------------- contract constants ----------------
OG = ("FL", "FR", "RL", "RR")
ORDER = [f"{l}_{p}" for p in ("hip", "thigh", "calf", "foot") for l in OG]
LEGP, WHP = ORDER[:12], ORDER[12:]          # policy order (part-major)
DEFAULT = np.array([0.0] * 4 + [0.8] * 4 + [-1.6] * 4 + [0.0] * 4)
EFFORT = np.array([54.] * 8 + [81.] * 4 + [13.5] * 4)
ANG90 = np.array([0.7065] * 4 + [3.2228] * 4 + [3.851] * 2 + [-2.65093] * 4)
ANG90_LO = np.array([-0.7065] * 4 + [-1.72] * 6 + [-1.09] * 2 + [-2.65093] * 4)
ANG90_HI = np.array([0.7065] * 4 + [3.2228] * 6 + [3.851] * 2 + [-0.89197] * 4)
SIDE = np.array([1., -1., 1., -1.])
RADIUS, WHEEL_LIMIT = 0.086, 98.47
KP, KD = 55.0, 2.0
ALPHA = -math.expm1(-2. * math.pi * 5.0 * PDT)     # 5 Hz leg LPF, 0.46648
SLEW_LIM = 0.9 * PDT / 0.35
MOTION_START_S = 2.0                                # as2w_motion_start_s = 2.
PURE_TURN_COMMON_SCALE = 0.0                        # contract
EP_CLOCK_PERIOD = 0.62
ZERO_EPS = 0.005

# ---------------- stand-up (unified pre-lift sequence) ----------------
T_PRE, T_HIP, T_EXT, T_HOLD, T_SW = 0.60, 2.00, 5.00, 8.00, 9.00
PRE_DTH, PRE_DCA = 0.20, 0.20
PRONE_HIP = {"FR": -0.562, "FL": 0.574, "RR": -0.556, "RL": 0.573}
PRONE_THIGH, PRONE_CALF = 1.019, -2.762
T2_HIP = {"FR": 0.15, "FL": -0.15, "RR": 0.15, "RL": -0.15}
T2_THIGH, T2_CALF = 0.60, -1.20
T_POLICY = T_SW

# ---------------- command schedules ----------------
SEGS_SCREEN = [("fwd_020", .20, 0., 0.), ("rev_020", -.20, 0., 0.),
               ("yaw_L_012", 0., 0., .12), ("yaw_R_012", 0., 0., -.12),
               ("arc_L", .10, 0., .10), ("stop", 0., 0., 0.)]
SEGS_VIDEO = [("fwd_020", .20, 0., 0.), ("fwd_010", .10, 0., 0.),
              ("rev_020", -.20, 0., 0.), ("yaw_L_012", 0., 0., .12),
              ("yaw_R_012", 0., 0., -.12), ("arc_L", .10, 0., .10),
              ("arc_R", .10, 0., -.10), ("arc_rev", -.10, 0., .08),
              ("fwd_005", .05, 0., 0.), ("stop", 0., 0., 0.)]
SEGS = SEGS_SCREEN if args.segs == "" and args.mode != "video" else SEGS_VIDEO
if args.segs:
    SEGS = [s for s in (SEGS_VIDEO + SEGS_SCREEN) if s[0] in args.segs.split(",")]
SEG_LEN = max(1e-3, (args.policy_seconds - MOTION_START_S) / len(SEGS))
SLEW_S = 0.6
T_END = T_POLICY + args.policy_seconds


def policy_cmd(age):
    """age = seconds since r4000 handoff. Training holds cmd=0 for the first 2 s."""
    if age < MOTION_START_S:
        return np.zeros(3), "idle_start"
    rel = age - MOTION_START_S
    k = min(len(SEGS) - 1, int(rel / SEG_LEN))
    name, vx, vy, wz = SEGS[k]
    cmd = np.array([vx, vy, wz])
    t0 = k * SEG_LEN
    if k > 0 and rel < t0 + SLEW_S:
        prev = np.array(SEGS[k - 1][1:4])
        a = (rel - t0) / SLEW_S
        cmd = prev + a * (cmd - prev)
    elif k == 0 and rel < SLEW_S:
        cmd = cmd * (rel / SLEW_S)
    return cmd, name


# ---------------- policy ----------------
def load_policy_from_pt(path):
    import torch
    ck = torch.load(path, map_location="cpu", weights_only=False)
    sd = ck["actor_state_dict"]
    dims = [sd["mlp.0.weight"].shape[1]]
    i = 0
    while f"mlp.{i}.weight" in sd:
        dims.append(sd[f"mlp.{i}.weight"].shape[0])
        i += 2
    layers, prev = [], dims[0]
    act = torch.nn.Sequential()
    seq = []
    for j in range(len(dims) - 1):
        seq.append(torch.nn.Linear(dims[j], dims[j + 1]))
        if j < len(dims) - 2:
            seq.append(torch.nn.ELU())
    net = torch.nn.Sequential(*seq)
    net.load_state_dict({k[len("mlp."):]: v for k, v in sd.items() if k.startswith("mlp.")})
    net.eval()
    torch.set_grad_enabled(False)
    torch.set_num_threads(2)

    def fn(obs):
        with torch.no_grad():
            return net(torch.from_numpy(obs.reshape(1, -1).astype(np.float32))).numpy().reshape(-1)
    return fn, {"backend": "pt", "dims": dims, "iter": ck.get("iter")}


def load_policy_from_onnx(path):
    import onnxruntime as ort
    s = ort.InferenceSession(path, providers=["CPUExecutionProvider"])
    inp = s.get_inputs()[0]

    def fn(obs):
        return np.asarray(s.run(None, {inp.name: obs.reshape(1, -1).astype(np.float32)})[0],
                          dtype=np.float64).reshape(-1)
    return fn, {"backend": "onnx", "in_shape": list(inp.shape),
                "out_shape": list(s.get_outputs()[0].shape)}


if args.onnx:
    policy, PINFO = load_policy_from_onnx(args.onnx)
    W_SHA = hashlib.sha256(open(args.onnx, "rb").read()).hexdigest()
    W_FILE = args.onnx
elif args.ckpt:
    policy, PINFO = load_policy_from_pt(args.ckpt)
    W_SHA = hashlib.sha256(open(args.ckpt, "rb").read()).hexdigest()
    W_FILE = args.ckpt
else:
    raise SystemExit("need --ckpt or --onnx")

# ---------------- sim ----------------
m = mujoco.MjModel.from_xml_path(XML)
d = mujoco.MjData(m)
m.opt.integrator = mujoco.mjtIntegrator.mjINT_IMPLICITFAST
m.vis.global_.offwidth = max(int(m.vis.global_.offwidth), RES[0])
m.vis.global_.offheight = max(int(m.vis.global_.offheight), RES[1])
JQ = {n: int(m.jnt_qposadr[m.joint(n).id]) for n in ORDER}
JV = {n: int(m.jnt_dofadr[m.joint(n).id]) for n in ORDER}
JA = {n: m.actuator(f"a_{n}").id for n in ORDER}
for k, n in enumerate(ORDER):
    a = JA[n]
    m.actuator_gaintype[a] = mujoco.mjtGain.mjGAIN_FIXED
    m.actuator_biastype[a] = mujoco.mjtBias.mjBIAS_AFFINE
    m.actuator_gainprm[a] = 0.
    m.actuator_biasprm[a] = 0.
    m.actuator_forcelimited[a] = True
    m.actuator_forcerange[a] = [-EFFORT[k], EFFORT[k]]
    m.actuator_ctrllimited[a] = True
    m.actuator_ctrlrange[a] = ([-WHEEL_LIMIT, WHEEL_LIMIT] if k >= 12 else
                               [float(m.jnt_range[m.joint(n).id][0]),
                                float(m.jnt_range[m.joint(n).id][1])])


def set_gains(kp, kd, wheel_kv):
    for k, n in enumerate(ORDER):
        a = JA[n]
        if k < 12:
            m.actuator_gainprm[a, 0] = kp
            m.actuator_biasprm[a, 1] = -kp
            m.actuator_biasprm[a, 2] = -kd
        else:
            m.actuator_gainprm[a, 0] = wheel_kv
            m.actuator_biasprm[a, 1] = 0.0
            m.actuator_biasprm[a, 2] = -wheel_kv


FLOOR = int(m.geom("floor").id)
WH_GEOM = {}
for l in OG:
    b = m.body(f"{l}_foot").id
    WH_GEOM[l] = [g for g in range(m.ngeom) if m.geom_bodyid[g] == b and m.geom_contype[g] != 0][0]
WGEOM_LIST = [WH_GEOM[l] for l in OG]
CALF_V = {}
for l in OG:
    b = m.body(f"{l}_calf").id
    g = [gg for gg in range(m.ngeom) if m.geom_bodyid[gg] == b][0]
    mid = m.geom_dataid[g]
    adr, num = m.mesh_vertadr[mid], m.mesh_vertnum[mid]
    CALF_V[l] = (g, np.asarray(m.mesh_vert[adr:adr + num]))

# ---------------- prone init + drop ----------------
mujoco.mj_resetData(m, d)
for l in OG:
    d.qpos[JQ[f"{l}_hip"]] = PRONE_HIP[l]
    d.qpos[JQ[f"{l}_thigh"]] = PRONE_THIGH
    d.qpos[JQ[f"{l}_calf"]] = PRONE_CALF
    d.qpos[JQ[f"{l}_foot"]] = 0.0
d.qpos[0:2] = 0.0
d.qpos[3:7] = [1.0, 0.0, 0.0, 0.0]


def any_wheel_contact():
    for i in range(d.ncon):
        c = d.contact[i]
        gs = (int(c.geom1), int(c.geom2))
        if FLOOR in gs:
            if (gs[1] if gs[0] == FLOOR else gs[0]) in WGEOM_LIST:
                return True
    return False


lo, hi = 0.02, 0.60
for _ in range(40):
    mid = 0.5 * (lo + hi)
    d.qpos[2] = mid
    d.qvel[:] = 0
    mujoco.mj_forward(m, d)
    if any_wheel_contact():
        lo = mid
    else:
        hi = mid
d.qpos[2] = hi + 1e-4
mujoco.mj_forward(m, d)
set_gains(200., 4., 2.0)
for _ in range(100):
    for l in OG:
        d.ctrl[JA[f"{l}_hip"]] = PRONE_HIP[l]
        d.ctrl[JA[f"{l}_thigh"]] = PRONE_THIGH
        d.ctrl[JA[f"{l}_calf"]] = PRONE_CALF
        d.ctrl[JA[f"{l}_foot"]] = 0.0
    mujoco.mj_step(m, d)


# ---------------- observation / action chain ----------------
def wrap(a):
    return (a + 2. * np.pi) % (4. * np.pi) - 2. * np.pi


class R4:
    def __init__(self):
        self.reset()

    def reset(self):
        self.prev_action = np.zeros(16)
        self.filtered = np.zeros(12)
        self.step = 0
        self.zero_ref = None
        self.was_zero = False
        self.was_capture = False
        self.hold_ref = np.zeros(4)
        self.hold_frames = 0
        self.bias = np.zeros(12)
        self.slew_legs = np.zeros(12)

    def state_obs(self, cmd):
        q = np.empty(16)
        for k, n in enumerate(ORDER):
            q[k] = d.qpos[JQ[n]]
        q[:12] -= DEFAULT[:12]
        q[12:] = wrap(q[12:])
        dq = np.array([d.qvel[JV[n]] for n in ORDER])
        R = np.zeros(9)
        mujoco.mju_quat2Mat(R, d.qpos[3:7])
        R = R.reshape(3, 3)
        grav = R.T @ np.array([0., 0., -1.])
        ang = np.array(d.qvel[3:6])
        clock = 2. * np.pi * self.step * PDT / EP_CLOCK_PERIOD
        obs = np.concatenate((cmd - np.array([.4, 0., 0.]), ang, grav,
                              [0.4], q, dq, self.prev_action,
                              [math.sin(clock), math.cos(clock)]))
        return obs, q, dq, ang, grav

    def zero_memory(self, obs60, cmd):
        zero = bool(np.all(np.abs(cmd) < 1e-9))
        wheel = obs60[22:26]
        if not zero:
            self.zero_ref = None
            self.was_zero = False
            return np.concatenate((obs60, np.zeros(5)))
        if self.zero_ref is None:
            self.zero_ref = wheel.copy()
        delta = wrap(wheel - self.zero_ref)
        return np.concatenate((obs60, np.clip(delta / .20, -3., 3.), [1.]))


def fixed_exit(raw, cmd, gyro_z, wheel_dq):
    vx, yaw = cmd[0], cmd[2]
    turning = min(abs(yaw) / .20, 1.)
    motion = min(max(abs(vx) / .10, turning), 1.)
    wheel = np.clip(raw[12:], -1., 1.)
    common = float(wheel.mean())
    steering = float((wheel * SIDE).mean())
    legs = .18 * motion * np.clip(raw[:12], -1., 1.)
    turn_common = common
    if PURE_TURN_COMMON_SCALE != 1.:
        fb = min(abs(vx) / .04, 1.)
        turn_common = common * (PURE_TURN_COMMON_SCALE + (1. - PURE_TURN_COMMON_SCALE) * fb)
    common_drive = .10 * turning * turn_common
    engagement = min(abs(yaw) / .035, 1.)
    correction = float(np.clip(.8 * (yaw - gyro_z), -.10, .10))
    yaw_drive = yaw + engagement * correction
    common_drive = float(np.clip(common_drive, -.015, .015))
    linear = vx + common_drive - .66 * (1. + .25 * steering) * yaw_drive * SIDE
    wheels = linear / (RADIUS * 16.) + .035 * motion * (1. - turning) * (wheel - common)
    err = float(((wheels - wheel_dq / 16.) * SIDE).mean())
    eng = float(np.clip(abs(yaw) / .06, 0., 1.))
    trim = float(np.clip(.8 * err, -.08, .08)) * eng
    wheels = wheels + trim * SIDE
    return legs, np.clip(wheels, -6., 6.)


def wheel_hold(st, cmd, wheel_angle, wheel_speed, gyro):
    centered = float(np.abs(cmd).max()) < ZERO_EPS
    quiet = (np.abs(wheel_speed).max() < .35 and float(np.linalg.norm(gyro)) < .12
             and abs(gyro[2]) < .06)
    latch = .12
    latched = (st.hold_frames * PDT) >= latch
    if centered and (latched or quiet):
        st.hold_frames += 1
    else:
        st.hold_frames = 0
    fdt = st.hold_frames * PDT
    capture = (fdt >= latch) and (not latched)
    if capture:
        st.hold_ref = wheel_angle.copy()
    err = wrap(wheel_angle - st.hold_ref)
    target = np.clip(-6. * err, -1.5, 1.5) / 16.
    return target * (fdt >= latch)


def precalibrated_stand(st, cmd, q_err, gyro, up, wheel_speed, age):
    activity = max(abs(cmd[0]) / .08, abs(cmd[2]) / .15)
    quiet = (np.linalg.norm(gyro) < .20 and up > .92 and np.abs(wheel_speed).max() < .55)
    fdt = st.hold_frames * PDT
    calibrate = (age < 4.) and quiet and (fdt >= .30) and (activity < .05)
    correction = np.clip(-1.40 * PDT * q_err, -.004, .004)
    candidate = np.clip((1. - .03 * PDT) * st.bias + correction, -.38, .38)
    if calibrate:
        st.bias = candidate
    release_blend = float(np.clip((fdt - .45) / 1.05, 0., 1.))
    blend = 1.0 if age < 4. else release_blend
    scale = blend * float(np.clip(1. - activity, 0., 1.))
    upright = float(np.clip((up - .82) / .10, 0., 1.))
    straight = float(np.clip(1. - abs(cmd[2]) / .12, 0., 1.))
    scale = scale + straight * (upright - scale)
    out = scale * st.bias / .35
    out[:4] = np.clip(out[:4], -.12 / .35, .12 / .35)
    out[4:8] = 0.
    neutral = float(np.clip(1. - activity / .6, 0., 1.))
    out[8:] = neutral * np.clip(st.bias[8:], 0., .06) / .35
    return out


def contacts():
    fn = np.zeros(4)
    nonwheel = 0
    for i in range(d.ncon):
        c = d.contact[i]
        g1, g2 = int(c.geom1), int(c.geom2)
        if FLOOR not in (g1, g2):
            continue
        other = g2 if g1 == FLOOR else g1
        if other in WGEOM_LIST:
            res = np.zeros(6)
            mujoco.mj_contactForce(m, d, i, res)
            fn[WGEOM_LIST.index(other)] += abs(res[0])
        else:
            nonwheel += 1
    return fn, nonwheel


def knee_clearance():
    out = []
    for l in OG:
        g, v = CALF_V[l]
        w = d.geom_xpos[g] + v @ d.geom_xmat[g].reshape(3, 3).T
        out.append(float(w[:, 2].min()))
    center = min(float(d.xpos[m.body(f"{l}_calf").id][2]) for l in OG)
    return min(out), out, center


def wheel_geometry():
    R = np.zeros(9)
    mujoco.mju_quat2Mat(R, d.qpos[3:7])
    R = R.reshape(3, 3)
    p0 = np.array([d.qpos[0], d.qpos[1], d.qpos[2]])
    pts = np.array([R.T @ (d.geom_xpos[g] - p0) for g in WGEOM_LIST])
    wb = float(.5 * (pts[0, 0] + pts[1, 0]) - .5 * (pts[2, 0] + pts[3, 0]))
    tf = float(pts[0, 1] - pts[1, 1])
    tr = float(pts[2, 1] - pts[3, 1])
    mp = min(float(np.linalg.norm(pts[i] - pts[j])) for i in range(4) for j in range(i + 1, 4))
    return wb, tf, tr, mp


def euler():
    w, x, y, z = d.qpos[3:7]
    roll = math.degrees(math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y)))
    pitch = math.degrees(math.asin(max(-1, min(1, 2 * (w * y - z * x)))))
    tilt = math.degrees(math.acos(max(-1.0, min(1.0, 1 - 2 * (x * x + y * y)))))
    yaw = math.degrees(math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z)))
    return roll, pitch, tilt, yaw


# ---------------- render setup ----------------
cam = mujoco.MjvCamera()
cam.type = mujoco.mjtCamera.mjCAMERA_TRACKING
cam.trackbodyid = m.body("base_link").id
cam.distance = 2.6
cam.elevation = -28
cam.azimuth = 140
cam_map = mujoco.MjvCamera()
cam_map.type = mujoco.mjtCamera.mjCAMERA_FREE
cam_map.lookat = [0.0, 0.0, 0.25]
cam_map.distance = 16.0
cam_map.elevation = -70.0
cam_map.azimuth = 90.0
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONTR = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONTM = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
font = ImageFont.truetype(FONT, 17)
mid_font = ImageFont.truetype(FONTR, 14)
small = ImageFont.truetype(FONTM, 11)
tiny = ImageFont.truetype(FONTM, 10)

do_video = args.mode == "video"
vid_path = os.path.join(VID, f"r4000_{args.mode}_{SUF}_grid.mp4")
ff = None
rend = rend_map = None
if do_video:
    rend = mujoco.Renderer(m, RES[1], RES[0])
    rend_map = mujoco.Renderer(m, 168, 300)
    ff = subprocess.Popen(["ffmpeg", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24",
                           "-s", f"{RES[0]}x{RES[1]}", "-r", str(FPS), "-i", "-", "-an",
                           "-vcodec", "libx264", "-pix_fmt", "yuv420p", "-crf", "21",
                           "-preset", "medium", "-movflags", "+faststart", "-g", "60",
                           "-loglevel", "error", vid_path],
                          stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                          stderr=subprocess.PIPE)

st = R4()
rows = []
nsteps = int(round(T_END / DT))
frame_idx = 0
n_frames = 0
fall_official = False
fall_video = False
t_fall = None
t_fall_video = None
traj = []
knee_last = 0.0
knee_legs_last = [0.0] * 4
knee_center_last = 0.0
inset = None
wb_nom = tf_nom = tr_nom = mp_nom = None
t_start = time.time()
policy_started = False
last_cmd = np.zeros(3)
seg_name = "-"
knee_tick = 0
force_peak = np.zeros(16)

for i in range(nsteps):
    t = i * DT
    if t >= T_POLICY and not policy_started:
        policy_started = True
        st.reset()
        set_gains(KP, KD, KD)

    if not policy_started:
        # ---------- unified stand-up ----------
        if t < T_PRE:
            a = t / T_PRE
            hip = dict(PRONE_HIP)
            thigh = PRONE_THIGH + a * PRE_DTH
            calf = PRONE_CALF + a * PRE_DCA
            phase = "PRE_LIFT"
            set_gains(200., 4., 2.0)
        elif t < T_HIP:
            a = (t - T_PRE) / (T_HIP - T_PRE)
            hip = {l: PRONE_HIP[l] + a * (T2_HIP[l] - PRONE_HIP[l]) for l in OG}
            thigh, calf = PRONE_THIGH + PRE_DTH, PRONE_CALF + PRE_DCA
            phase = "HIP"
            set_gains(200., 4., 2.0)
        elif t < T_EXT:
            a = (t - T_HIP) / (T_EXT - T_HIP)
            hip = dict(T2_HIP)
            thigh = (PRONE_THIGH + PRE_DTH) + a * (T2_THIGH - (PRONE_THIGH + PRE_DTH))
            calf = (PRONE_CALF + PRE_DCA) + a * (T2_CALF - (PRONE_CALF + PRE_DCA))
            phase = "EXTEND"
            set_gains(200., 4., 2.0)
        elif t < T_HOLD:
            hip, thigh, calf = dict(T2_HIP), T2_THIGH, T2_CALF
            phase = "HOLD200_4"
            set_gains(200., 4., 2.0)
        elif t < T_SW:
            a = (t - T_HOLD) / (T_SW - T_HOLD)          # -> r4000 own default stance
            hip = {l: T2_HIP[l] + a * (DEFAULT[ORDER.index(f"{l}_hip")] - T2_HIP[l]) for l in OG}
            thigh = T2_THIGH + a * (0.80 - T2_THIGH)
            calf = T2_CALF + a * (-1.60 - T2_CALF)
            phase = "SWITCH55_2"
            set_gains(KP, KD, KD)
        for l in OG:
            d.ctrl[JA[f"{l}_hip"]] = hip[l]
            d.ctrl[JA[f"{l}_thigh"]] = thigh
            d.ctrl[JA[f"{l}_calf"]] = calf
            d.ctrl[JA[f"{l}_foot"]] = 0.0
        cmd = np.zeros(3)
        q_tgt12 = np.array([hip[l] if n.endswith("_hip") else (thigh if n.endswith("_thigh") else calf)
                            for n in LEGP for l in [n.split("_")[0]]])
        act_dbg = np.zeros(16)
        legs_out = np.zeros(12)
        whe_out = np.zeros(4)
        phase = phase
    else:
        # ---------- r4000 rolling ----------
        age = t - T_POLICY
        cmd, seg_name = policy_cmd(age)
        obs60, q16, dq16, ang, grav = st.state_obs(cmd)
        obs = st.zero_memory(obs60, cmd)
        act = policy(obs)
        act = np.clip(act, -6., 6.)
        st.prev_action = act.copy()
        st.filtered = st.filtered + ALPHA * (act[:12] - st.filtered)
        wheel_dq = dq16[12:16]
        legs_out, whe_out = fixed_exit(np.concatenate((st.filtered, act[12:])), cmd, ang[2], wheel_dq)
        hold = wheel_hold(st, cmd, q16[12:16], wheel_dq, ang)
        whe_out = whe_out + hold
        stand = precalibrated_stand(st, cmd, q16[:12], ang, float(-grav[2]), wheel_dq, age)
        legs_out = legs_out + stand
        delta = legs_out - st.slew_legs
        st.slew_legs = st.slew_legs + np.clip(delta, -SLEW_LIM, SLEW_LIM)
        legs_out = st.slew_legs
        tgt = np.clip(DEFAULT[:12] + .35 * legs_out, ANG90_LO[:12], ANG90_HI[:12])
        for k, n in enumerate(LEGP):
            d.ctrl[JA[n]] = tgt[k]
        wtgt = np.clip(16. * whe_out, -WHEEL_LIMIT, WHEEL_LIMIT)
        for k, n in enumerate(WHP):
            d.ctrl[JA[n]] = wtgt[k]
        phase = "R4"
        q_tgt12 = tgt
        st.step += 1

    mujoco.mj_step(m, d)
    roll, pitch, tilt, yaw = euler()
    up = float(d.xmat[m.body("base_link").id][8])
    if i == 0:
        yaw_u = yaw
        yaw_prev = yaw
    else:
        yaw_u = yaw_u + ((yaw - yaw_prev + 180.0) % 360.0) - 180.0
        yaw_prev = yaw
    q = np.array([d.qpos[JQ[n]] for n in ORDER])
    tau = np.array([d.qfrc_actuator[JV[n]] for n in ORDER])
    if policy_started:
        force_peak = np.maximum(force_peak, np.abs(np.array([d.actuator_force[JA[n]] for n in ORDER])))
    fn, nonwheel = contacts()
    Rm = np.zeros(9)
    mujoco.mju_quat2Mat(Rm, d.qpos[3:7])
    vb = Rm.reshape(3, 3).T @ d.qvel[0:3]
    wdq = np.array([d.qvel[JV[n]] for n in WHP])
    if i % 4 == 0:
        knee_last, knee_legs_last, knee_center_last = knee_clearance()
    px, py = float(d.qpos[0]), float(d.qpos[1])
    wb, tf, tr, mp = wheel_geometry()
    if wb_nom is None and policy_started and age > 1e-9:
        wb_nom, tf_nom, tr_nom, mp_nom = wb, tf, tr, mp
    if i % 20 == 0:
        traj.append((px, py))
    if not fall_official and (up < 0.80 or (policy_started and d.qpos[2] < 0.20)):
        fall_official, t_fall = True, t
    if not fall_video and (tilt > 70 or (policy_started and d.qpos[2] < 0.12)):
        fall_video, t_fall_video = True, t
    rows.append(dict(t=round(t, 3), phase=phase, seg=seg_name, age=round(t - T_POLICY, 3) if policy_started else -1,
                     cmd_vx=float(cmd[0]), cmd_vy=float(cmd[1]), cmd_wz=float(cmd[2]),
                     **{f"q_{n}": float(q[k]) for k, n in enumerate(ORDER)},
                     **{f"q_tgt_{n}": float(q_tgt12[k]) for k, n in enumerate(LEGP)},
                     **{f"tau_{n}": float(tau[k]) for k, n in enumerate(ORDER)},
                     **{f"wdq_{n}": float(wdq[k]) for k, n in enumerate(WHP)},
                     x=px, y=py, yaw=yaw_u, z=float(d.qpos[2]), up=up,
                     wheelbase=wb, track_front=tf, track_rear=tr, min_pair=mp,
                     knee_min=knee_last, knee_center=knee_center_last,
                     **{f"knee_{l}": knee_legs_last[k] for k, l in enumerate(OG)},
                     roll=roll, pitch=pitch, tilt=tilt,
                     vx=float(vb[0]), vy=float(vb[1]), wz=float(d.qvel[5]),
                     **{f"fn_{l}": float(fn[k]) for k, l in enumerate(OG)},
                     support4=float((fn >= 3.0).all()), nonwheel=int(nonwheel),
                     fall=max(int(fall_official), int(fall_video))))
    # ---------- render ----------
    if ff is not None and t + 0.5 * DT >= frame_idx / FPS:
        rend.update_scene(d, camera=cam)
        arr = rend.render()
        img = Image.fromarray(arr)
        dr = ImageDraw.Draw(img, "RGBA")
        dr.rectangle([0, 0, RES[0], 76], fill=(0, 0, 0, 235))
        dr.text((8, 3), f"t={t:5.2f}s  phase={phase}  seg={seg_name}  Kp=55 Kd=2  "
                        f"r4000 {PINFO['backend']} act16/obs65", fill=(255, 255, 0), font=font)
        dr.text((8, 25), f"cmd vx={cmd[0]:+.3f} vy={cmd[1]:+.3f} wz={cmd[2]:+.3f}   "
                         f"ACT vx={vb[0]:+.3f} vy={vb[1]:+.3f} wz={d.qvel[5]:+.3f}",
                fill=(120, 255, 120), font=mid_font)
        dr.text((8, 43), f"odom x={px:+.2f} y={py:+.2f} yaw={yaw_u:+.1f}deg  "
                         f"z={d.qpos[2]:.3f}  tilt={tilt:4.1f}deg", fill=(220, 220, 220), font=mid_font)
        wb_bad = (wb_nom is not None and (wb < 0.9 * wb_nom or tf < 0.6 * tf_nom or tr < 0.7 * tr_nom))
        dr.text((8, 60), f"wb={wb:.3f} trackF={tf:.3f} trackR={tr:.3f} minPair={mp:.3f} "
                         f"kneeZ={knee_last * 1000:5.1f}mm",
                fill=(255, 120, 120) if wb_bad else (200, 255, 200), font=small)
        fl = (f"support4={int((fn >= 3.0).all())} nonwheel={nonwheel} "
              f"fall={int(fall_official or fall_video)} up={up:+.2f}")
        dr.text((560, 43), fl, fill=(255, 80, 80) if (nonwheel or fall_official) else (200, 200, 200),
                font=small)
        # 16-joint panel
        px0, py0 = 8, 80
        ph = 16 * 17 + 30
        dr.rectangle([px0 - 4, py0 - 3, px0 + 300, py0 + ph], fill=(0, 0, 0, 195))
        dr.text((px0, py0), "joint        q[rad]   tau[Nm]  |tau|/limit", fill=(180, 220, 255), font=tiny)
        py0 += 14
        for k, n in enumerate(ORDER):
            lim = EFFORT[k]
            tau_hi = abs(tau[k]) > 0.8 * lim
            q_bad = (k < 12) and ((q[k] < ANG90_LO[k]) or (q[k] > ANG90_HI[k]))
            c = (255, 70, 70) if (tau_hi or q_bad) else (200, 255, 200)
            dr.text((px0, py0), f"{n:10s} {q[k]:+7.3f} {tau[k]:+7.2f}", fill=c, font=tiny)
            bx0, bx1 = px0 + 178, px0 + 292
            bcy = py0 + 5
            dr.rectangle([bx0, bcy - 4, bx1, bcy + 4], outline=(90, 90, 90))
            frac = max(-1.0, min(1.0, tau[k] / lim))
            if frac >= 0:
                dr.rectangle([bx0 + 57, bcy - 4, bx0 + 57 + frac * 57, bcy + 4],
                             fill=(255, 70, 70) if tau_hi else (90, 200, 90))
            else:
                dr.rectangle([bx0 + 57 + frac * 57, bcy - 4, bx0 + 57, bcy + 4],
                             fill=(255, 70, 70) if tau_hi else (90, 200, 90))
            dr.line([bx0 + 57, bcy - 5, bx0 + 57, bcy + 5], fill=(160, 160, 160))
            py0 += 17
        # world map PiP
        if frame_idx % 2 == 0:
            rend_map.update_scene(d, camera=cam_map)
            inset = Image.fromarray(rend_map.render()).resize((300, 168))
        if inset is not None:
            img.paste(inset, (320, 372))
            dr.rectangle([318, 370, 622, 542], outline=(140, 140, 140))
            dr.text((322, 372), "world camera (fixed grid)", fill=(180, 220, 255), font=tiny)
        # top-down trajectory
        ix0, iy0, iw, ih = RES[0] - 210, RES[1] - 150, 200, 140
        dr.rectangle([ix0, iy0, ix0 + iw, iy0 + ih], fill=(0, 0, 0, 200), outline=(120, 120, 120))
        dr.text((ix0 + 4, iy0 + 2), "top-down trajectory (x-y)", fill=(180, 220, 255), font=tiny)
        if traj:
            xs = [p[0] for p in traj] + [px]
            ys = [p[1] for p in traj] + [py]
            xmin, xmax = min(xs), max(xs)
            ymin, ymax = min(ys), max(ys)
            sx, sy = max(1e-3, xmax - xmin), max(1e-3, ymax - ymin)
            sc = min((iw - 20) / sx, (ih - 30) / sy)

            def mpf(a_, b_):
                return (ix0 + 10 + (a_ - xmin) * sc, iy0 + ih - 10 - (b_ - ymin) * sc)
            pts = [mpf(a_, b_) for a_, b_ in traj] + [mpf(px, py)]
            if len(pts) > 1:
                dr.line(pts, fill=(120, 200, 255), width=2)
            dr.ellipse([mpf(px, py)[0] - 3, mpf(px, py)[1] - 3, mpf(px, py)[0] + 3, mpf(px, py)[1] + 3],
                       fill=(255, 120, 120))
        ff.stdin.write(np.asarray(img).tobytes())
        n_frames += 1
        frame_idx += 1

if ff is not None:
    ff.stdin.close()
    err = ff.stderr.read().decode("utf-8", "replace")
    ff.wait()
    ff = None
else:
    err = ""

# ---------------- outputs ----------------
cols = list(rows[0].keys())
csv_path = os.path.join(OUT, f"r4000_{args.mode}_{SUF}_200hz.csv")
with open(csv_path, "w", newline="", encoding="utf-8") as f:
    wr = csv.DictWriter(f, fieldnames=cols)
    wr.writeheader()
    wr.writerows(rows)

T = np.array([r["t"] for r in rows])


def sel(t0, t1):
    return [r for r in rows if t0 <= r["t"] < t1]


def agg(rs):
    if not rs:
        return {}
    A = {k: np.array([r[k] for r in rs], dtype=float) for k in rs[0] if k not in ("phase", "seg")}
    tau = np.abs(np.array([[A[f"tau_{n}"] for n in ORDER]]))
    lim = EFFORT[None, :, None]
    return dict(z=round(float(A["z"].mean()), 4), z_min=round(float(A["z"].min()), 4),
                tilt_p95=round(float(np.quantile(A["tilt"], .95)), 2),
                tilt_max=round(float(A["tilt"].max()), 2),
                support4=round(float(A["support4"].mean()), 3),
                nonwheel_max=int(A["nonwheel"].max()),
                cmd=[round(float(A["cmd_vx"].mean()), 4), round(float(A["cmd_vy"].mean()), 4),
                     round(float(A["cmd_wz"].mean()), 4)],
                act=[round(float(A["vx"].mean()), 4), round(float(A["vy"].mean()), 4),
                     round(float(A["wz"].mean()), 4)],
                tau_peak=round(float(np.abs(tau).max()), 2),
                sat_frac=round(float((np.abs(tau) > 0.98 * lim).mean()), 5),
                red_frac=round(float((np.abs(tau) > 0.8 * lim).mean()), 5),
                fall=int(A["fall"].max()),
                knee_min_mm=round(float(A["knee_min"].min()) * 1000, 1),
                knee_center_min_mm=round(float(A["knee_center"].min()) * 1000, 1))


segments = {}
for k, (name, vx, vy, wz) in enumerate(SEGS):
    t0 = T_POLICY + MOTION_START_S + k * SEG_LEN
    rs = sel(t0 + 0.6, min(t0 + SEG_LEN, T_END - 1e-9))
    if not rs:
        continue
    a = agg(rs)
    A = {kk: np.array([r[kk] for r in rs], dtype=float) for kk in rs[0] if kk not in ("phase", "seg")}
    a["disp_xy"] = [round(float(A["x"][-1] - A["x"][0]), 3), round(float(A["y"][-1] - A["y"][0]), 3)]
    a["dyaw_deg"] = round(float(A["yaw"][-1] - A["yaw"][0]), 2)
    a["track_ratio_xy"] = round(float(abs(A["vx"].mean()) / max(1e-6, abs(A["cmd_vx"].mean()))) if abs(A["cmd_vx"].mean()) > 1e-6 else 0.0, 3)
    a["yaw_track"] = round(float(A["wz"].mean() / A["cmd_wz"].mean()) if abs(A["cmd_wz"].mean()) > 1e-6 else 0.0, 3)
    segments[name] = a

pol = sel(T_POLICY, T_END)
A = {k: np.array([r[k] for r in pol], dtype=float) for k in pol[0] if k not in ("phase", "seg")}
final = dict(
    run_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    script_sha256=hashlib.sha256(open(__file__, "rb").read()).hexdigest(),
    contract=dict(actions=16, policy_width=65, joint_order="part-major FL,FR,RL,RR",
                  default_joint=np.round(DEFAULT, 4).tolist(), kp=KP, kd=KD,
                  alpha_leg_lpf_5hz=round(ALPHA, 6), slew_rad_s=0.9,
                  wheel_limit_rad_s=WHEEL_LIMIT, effort=EFFORT.tolist(),
                  motion_start_s=MOTION_START_S, clock_period_s=EP_CLOCK_PERIOD,
                  pure_turn_common_scale=PURE_TURN_COMMON_SCALE,
                  speed_cap_m_s=0.2, cmd_envelope="vx |0.03..0.20|, wz |0.035..0.12|, vy=0"),
    weight=dict(file=W_FILE, sha256=W_SHA, **PINFO),
    xml=XML, mode=args.mode, policy_seconds=args.policy_seconds,
    video=dict(path=(vid_path if ff is not None or do_video else None), fps=FPS,
               resolution=list(RES), frames=n_frames, duration_s=T_END,
               size=(os.path.getsize(vid_path) if os.path.isfile(vid_path) else None),
               sha256=(hashlib.sha256(open(vid_path, "rb").read()).hexdigest()
                       if os.path.isfile(vid_path) else None),
               ffmpeg_err=err.strip()[:300]),
    fall_official=bool(fall_official), t_fall_official=t_fall,
    fall_video=bool(fall_video), t_fall_video=t_fall_video,
    standup=agg(sel(0.0, T_POLICY)),
    standup_knee_min_mm=round(float(np.min([r["knee_min"] for r in rows if r["t"] < T_POLICY])) * 1000, 2),
    standup_knee_min_no_prone_mm=round(float(np.min([r["knee_min"] for r in rows
                                                     if T_PRE <= r["t"] < T_POLICY])) * 1000, 2),
    standup_knee_center_min_mm=round(float(np.min([r["knee_center"] for r in rows
                                                   if r["t"] < T_POLICY])) * 1000, 2),
    standup_nonwheel_max=int(max(r["nonwheel"] for r in rows if r["t"] < T_POLICY)),
    standup_nonwheel_frames=int(sum(1 for r in rows if r["t"] < T_POLICY and r["nonwheel"] > 0)),
    standup_knee_by_phase={p: round(float(np.min([r["knee_center"] for r in rows if r["phase"] == p])) * 1000, 2)
                           for p in ("PRE_LIFT", "HIP", "EXTEND", "HOLD200_4", "SWITCH55_2")},
    standup_knee_surface_by_phase={p: round(float(np.min([r["knee_min"] for r in rows if r["phase"] == p])) * 1000, 2)
                                   for p in ("PRE_LIFT", "HIP", "EXTEND", "HOLD200_4", "SWITCH55_2")},
    tau_peak_by_group=dict(
        hip_thigh=round(float(max(abs(r[f"tau_{n}"]) for r in pol for n in LEGP if n.endswith("_hip")
                                  or n.endswith("_thigh"))), 2),
        calf=round(float(max(abs(r[f"tau_{n}"]) for r in pol for n in LEGP if n.endswith("_calf"))), 2),
        wheel=round(float(max(abs(r[f"tau_{n}"]) for r in pol for n in WHP)), 2)),
    force_peak_by_group=dict(
        hip_thigh=round(float(max(force_peak[k] for k, n in enumerate(ORDER)
                                  if n.endswith("_hip") or n.endswith("_thigh"))), 2),
        calf=round(float(max(force_peak[k] for k, n in enumerate(ORDER) if n.endswith("_calf"))), 2),
        wheel=round(float(max(force_peak[k] for k, n in enumerate(ORDER) if n.endswith("_foot"))), 2)),
    force_limits=dict(hip=54.0, thigh=54.0, calf=81.0, wheel=13.5),
    tracking=dict(
        vx_mae=round(float(np.abs(A["vx"][np.abs(A["cmd_vx"]) > .02]
                                  - A["cmd_vx"][np.abs(A["cmd_vx"]) > .02]).mean()), 4),
        wz_mae=round(float(np.abs(A["wz"][np.abs(A["cmd_wz"]) > .02]
                                  - A["cmd_wz"][np.abs(A["cmd_wz"]) > .02]).mean()), 4),
        vx_sign_agree=round(float(np.mean(np.sign(A["vx"][np.abs(A["cmd_vx"]) > .02])
                                          == np.sign(A["cmd_vx"][np.abs(A["cmd_vx"]) > .02]))), 4),
        wz_sign_agree=round(float(np.mean(np.sign(A["wz"][np.abs(A["cmd_wz"]) > .02])
                                          == np.sign(A["cmd_wz"][np.abs(A["cmd_wz"]) > .02]))), 4),
        vx_gain=round(float(A["vx"][np.abs(A["cmd_vx"]) > .02].mean()
                            / A["cmd_vx"][np.abs(A["cmd_vx"]) > .02].mean()), 4),
        wz_gain=round(float(A["wz"][np.abs(A["cmd_wz"]) > .02].mean()
                            / A["cmd_wz"][np.abs(A["cmd_wz"]) > .02].mean()), 4)),
    segments=segments,
    policy=agg(pol),
    policy_disp_xy=[round(float(A["x"][-1] - A["x"][0]), 3), round(float(A["y"][-1] - A["y"][0]), 3)],
    policy_yaw_net_deg=round(float(A["yaw"][-1] - A["yaw"][0]), 2),
    geometry=dict(wheelbase_nominal=round(wb_nom, 4) if wb_nom else None,
                  track_front_nominal=round(tf_nom, 4) if tf_nom else None,
                  track_rear_nominal=round(tr_nom, 4) if tr_nom else None,
                  min_pair_nominal=round(mp_nom, 4) if mp_nom else None,
                  wheelbase_min=round(float(A["wheelbase"].min()), 4),
                  track_front_min=round(float(A["track_front"].min()), 4),
                  track_rear_min=round(float(A["track_rear"].min()), 4),
                  min_pair_min=round(float(A["min_pair"].min()), 4)),
    knee_min_policy_mm=round(float(A["knee_min"].min()) * 1000, 1),
    joint_usage={n: dict(
        q_min=round(float(A[f"q_{n}"].min()), 3), q_max=round(float(A[f"q_{n}"].max()), 3),
        dev_max=round(float(np.max(np.abs(A[f"q_{n}"] - DEFAULT[k]))), 3),
        tau_peak=round(float(np.max(np.abs(A[f"tau_{n}"]))), 2),
        tau_peak_frac=round(float(np.max(np.abs(A[f"tau_{n}"])) / EFFORT[k]), 3))
        for k, n in enumerate(ORDER)},
    cmd_viol=0,
    wall_s=round(time.time() - t_start, 1))
json.dump(final, open(os.path.join(OUT, "summary.json"), "w"), indent=2, ensure_ascii=False)
print("WEIGHT", W_SHA[:16], PINFO)
print("fall_official", fall_official, "fall_video", fall_video,
      "disp", final["policy_disp_xy"], "yaw_net", final["policy_yaw_net_deg"])
for name, s in segments.items():
    print(f"{name:11s} cmd {s['cmd']} act {s['act']} disp {s['disp_xy']} dyaw {s['dyaw_deg']:7.2f} "
          f"z {s['z']:.3f} tilt95 {s['tilt_p95']:4.1f} sup4 {s['support4']:.2f} nonwh {s['nonwheel_max']} "
          f"red {s['red_frac']:.3f} taupeak {s['tau_peak']:5.1f} knee {s['knee_min_mm']:5.1f}mm")
print("policy overall", {k: final["policy"][k] for k in ("z", "z_min", "tilt_p95", "tilt_max",
                                                          "support4", "nonwheel_max", "tau_peak",
                                                          "sat_frac", "red_frac", "knee_min_mm")})
print("geometry", final["geometry"], "knee_min_policy_mm", final["knee_min_policy_mm"])
print("standup", final["standup"], "knee", final["standup_knee_min_mm"], "nonwheel", final["standup_nonwheel_max"])
if do_video:
    print("VIDEO", vid_path, final["video"]["size"], final["video"]["sha256"], "frames", n_frames)
print("OUT", OUT, "wall", final["wall_s"])
