#!/usr/bin/env bash
set -uo pipefail
WS=/root/as2w/retrain-wheeldiff-dr3c-20261122
RUN=/root/gpufree-data/as2w-runs/retrain-dr3c-20261122
V41=/root/as2w/retrain-wheeldiff-v41-20261121
AB=/root/gpufree-data/as2w-runs/retrain-dr3a-20261122/evals_AB_baseline
A_DR0=/root/gpufree-data/as2w-runs/retrain-dr2b-20261122/evals/dr2b_s1_seed42_final_dr0
log(){ echo "$(date -Is) $*" >> $WS/CSHORT_EVALONLY.log; }
log START
for seed in 42 43; do
  d=$RUN/cshort/baseline_s$seed/train
  for spec in 25:model_25.pt:26 50:endpoint.pt:50; do
    ckpt=${spec%%:*}; rest=${spec#*:}; file=${rest%%:*}; actual=${rest##*:}
    [ -s "$d/$file" ] || { log "MISSING s$seed $file"; exit 2; }
    for kind in obs0 dr0; do
      out=$RUN/cshort/evals/DR3C_cshort_s${seed}_${ckpt}_${kind}
      [ -s "$out/flat.npz" ] && { log "SKIP s$seed $ckpt $kind"; continue; }
      if [ "$kind" = obs0 ]; then dr=2; else dr=0; fi
      log "EVAL s$seed ckpt=$ckpt actual=$actual kind=$kind file=$file"
      bash $WS/src/eval_wheeldiff_dr3c.sh "$d/$file" "$out" "$dr" "" 0 > "$d/eval_${actual}_${kind}.log" 2>&1 || log "EVALFAIL s$seed $ckpt $kind"
    done
  done
done
# manifests & gate/check for 25,50 (tags use 25/50; actual recorded separately)
for ckpt in 25 50; do
  /usr/bin/python3 - "$RUN" "$ckpt" "$AB" "$A_DR0" > $RUN/cshort/v22/manifest_${ckpt}.json <<'PY'
import json,sys
run,ckpt,ab,adr0=sys.argv[1:5]
evals=[{"tag":"A_final_0","kind":"obs0","dir":f"{ab}/A_final_0"},{"tag":"A_dr0_parent","kind":"dr0","dir":adr0}]
for s in (42,43):
 for kind in ("obs0","dr0"):
  evals.append({"tag":f"D3B_s{s}_{ckpt}_{kind}","kind":kind,"dir":f"{run}/cshort/evals/DR3C_cshort_s{s}_{ckpt}_{kind}"})
print(json.dumps({"baseline_tag":"A_final_0","evals":evals},indent=1))
PY
  /root/as2w/preflight/isaac-python -W ignore $WS/gate_v22_dr3c.py --manifest $RUN/cshort/v22/manifest_${ckpt}.json --config $V41/gate_v22/gate_v22_config.json --outdir $RUN/cshort/v22/ckpt_${ckpt} > $RUN/cshort/v22/gate_${ckpt}.log 2>&1
  /usr/bin/python3 $WS/cshort_check.py --ckpt $ckpt --gate $RUN/cshort/v22/ckpt_${ckpt}/gate_v22_results.json >> $WS/CSHORT_EVALONLY.log 2>&1
  rc=$?; log "REGRESSION ckpt=$ckpt rc=$rc"
  [ "$rc" -ne 0 ] && { log "STOP ckpt=$ckpt"; exit 4; }
done
log "BASELINE_OK"
echo CSHORT_EVALONLY_OK
