#!/usr/bin/env bash
# T4 driver: same A/seed/25 updates/optimizer init as T3; only sampler = fixed C1.
# eval obs0/DR0 via P0 no-ring wrapper; frozen support<=0.02 / tracking<=0.03.
set -uo pipefail
WS=/root/as2w/retrain-wheeldiff-dr3c-20261122
RUN=/root/gpufree-data/as2w-runs/retrain-dr3c-20261122
T4=$RUN/T4
T3=$RUN/T3
AB=/root/gpufree-data/as2w-runs/retrain-dr3a-20261122/evals_AB_baseline
A_DR0=/root/gpufree-data/as2w-runs/retrain-dr2b-20261122/evals/dr2b_s1_seed42_final_dr0
V41=/root/as2w/retrain-wheeldiff-v41-20261121
PY=/root/as2w/preflight/isaac-python
SP=/usr/bin/python3
LOG=$WS/T4_DRIVER.log
mkdir -p "$T4/evals" "$T4/v22"
log() { echo "$(date -Is) $*" >> "$LOG"; }
log "T4_DRIVER_START pid=$$"
for seed in 42 43; do
  out=$T4/s${seed}/train
  mkdir -p "$(dirname "$out")"
  log "TRAIN_LAUNCH seed=$seed out=$out sampler=c1"
  AS2W_SAVE_INTERVAL=25 SEED=$seed OUT="$out" UPDATES=25 bash "$WS/src/run_wheeldiff_t4.sh" > "$T4/s${seed}/train.log" 2>&1 &
  log "TRAIN_PID seed=$seed pid=$!"
done
for i in $(seq 1 240); do
  ok=1
  for seed in 42 43; do [ -s "$T4/s${seed}/train/model_24.pt" ] || ok=0; done
  [ "$ok" = "1" ] && break
  sleep 20
done
for seed in 42 43; do
  [ -s "$T4/s${seed}/train/model_24.pt" ] || { log "ABORT missing model_24 s$seed"; echo T4_FAIL; exit 3; }
  cp -f "$T4/s${seed}/train/model_24.pt" "$T4/s${seed}/train/update_25.pt"
  log "UPDATE25 s$seed sha=$(sha256sum "$T4/s${seed}/train/update_25.pt" | cut -d' ' -f1) iters=$(grep -o 'Learning iteration [0-9]*/25' "$T4/s${seed}/train.log" | tail -1)"
done
log "TRAIN_DONE $(date -Is)"
# config diff vs T3 (only sampler should differ)
$SP - "$T3" "$T4" "$T4/config_diff.json" <<'PY'
import json, pathlib, sys
t3, t4, out = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[3])
def load(p):
    return json.loads((p/"s42/train/run.json").read_text())
a, b = load(t3), load(t4)
skip = {"out", "seed", "resume", "command_hold_s", "cmd_sampler", "domain_config"}
diff = {k: [a.get(k), b.get(k)] for k in sorted(set(a)|set(b)) if a.get(k) != b.get(k) and k not in skip}
out.write_text(json.dumps({"cmd_sampler_t3": a.get("cmd_sampler"), "cmd_sampler_t4": b.get("cmd_sampler"),
                           "other_diffs_excluding_paths": diff,
                           "same_parent": a.get("resume") == b.get("resume"),
                           "same_seed": a.get("seed") == b.get("seed"),
                           "base_update": [a.get("base_update"), b.get("base_update")],
                           "iterations": [a.get("iterations"), b.get("iterations")]}, indent=1)+"\n")
print(open(out).read())
PY
for seed in 42 43; do
  d=$T4/s${seed}/train
  for spec in "obs0 2 0" "dr0 0 0"; do
    set -- $spec; kind=$1; A=$2; O=$3; E=""
    o=$T4/evals/T4_s${seed}_25_${kind}
    [ -s "$o/flat.npz" ] || bash "$WS/src/eval_wheeldiff_dr3c.sh" "$d/update_25.pt" "$o" "$A" "$E" "$O" > "$T4/s${seed}/eval_${kind}.log" 2>&1
    [ -s "$o/flat.npz" ] || { log "ABORT eval missing $o"; echo T4_FAIL; exit 4; }
  done
done
$SP - "$RUN" "$AB" "$A_DR0" > "$T4/v22/manifest_25.json" <<'PY'
import json, sys
run, ab, a_dr0 = sys.argv[1:4]
evals = [{"tag": "A_final_0", "kind": "obs0", "dir": f"{ab}/A_final_0"},
         {"tag": "A_dr0_parent", "kind": "dr0", "dir": a_dr0}]
for s in (42, 43):
    for kind in ("obs0", "dr0"):
        evals.append({"tag": f"D3B_s{s}_25_{kind}", "kind": kind,
                      "dir": f"{run}/T4/evals/T4_s{s}_25_{kind}"})
print(json.dumps({"baseline_tag": "A_final_0", "evals": evals}, indent=1))
PY
$PY -W ignore "$WS/gate_v22_dr3c.py" --manifest "$T4/v22/manifest_25.json" \
   --config "$V41/gate_v22/gate_v22_config.json" --outdir "$T4/v22/ckpt_25" > "$T4/v22/gate_25.log" 2>&1
$SP "$WS/t4_check.py" --gate "$T4/v22/ckpt_25/gate_v22_results.json" >> "$LOG" 2>&1
RC=$?
if [ "$RC" -ne 0 ]; then log "T4_REGRESSION_FAIL rc=$RC"; echo T4_FAIL; exit 5; fi
log "T4_DONE $(date -Is)"
echo T4_DONE
