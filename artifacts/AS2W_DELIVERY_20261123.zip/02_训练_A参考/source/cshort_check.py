#!/usr/bin/env python3
"""C-short regression check: obs0/DR0 vs A baselines for 25/50-update ckpts."""
import argparse
import json
import pathlib
import sys

RUN = pathlib.Path("/root/gpufree-data/as2w-runs/retrain-dr3c-20261122")


def scene_med(gate_path, tag, label, field):
    d = json.loads(gate_path.read_text())
    for e in d["evals"]:
        if e["tag"] == tag:
            return e["scenes"].get(label, {}).get(field, {}).get("median")
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", default="baseline")
    ap.add_argument("--ckpt", type=int, required=True)
    ap.add_argument("--gate", type=pathlib.Path, required=True)
    args = ap.parse_args()
    base_gate = RUN / "v22/ckpt_200/gate_v22_results.json"  # contains A_final_0 / A_dr0_parent
    labels = ("reverse", "arc", "yaw_left_slow", "yaw_right_slow")
    out = {"arm": args.arm, "ckpt": args.ckpt, "checks": [], "pass": True, "fails": []}
    for seed in (42, 43):
        tag = f"D3B_s{seed}_{args.ckpt}"
        base_tag = f"A_final_0" if args.ckpt != 0 else "A_final_0"
        for obs_kind, base in (("obs0", "A_final_0"), ("dr0", "A_dr0_parent")):
            for lab in labels:
                for field, drop_max in (("support", 0.02), ("tracking", 0.03)):
                    cur = scene_med(args.gate, f"{tag}_{obs_kind}", lab, field)
                    ref = scene_med(base_gate, base, lab, field)
                    if cur is None or ref is None:
                        out["checks"].append({"check": f"s{seed}.{obs_kind}.{lab}.{field}",
                                              "cur": cur, "ref": ref, "pass": False})
                        out["pass"] = False
                        out["fails"].append(f"s{seed}.{obs_kind}.{lab}.{field}:missing")
                        continue
                    drop = ref - cur
                    ok = drop <= drop_max
                    out["checks"].append({"check": f"s{seed}.{obs_kind}.{lab}.{field}",
                                          "cur": cur, "ref": ref, "drop": drop,
                                          "drop_max": drop_max, "pass": bool(ok)})
                    if not ok:
                        out["pass"] = False
                        out["fails"].append(f"s{seed}.{obs_kind}.{lab}.{field}:drop={drop:.3f}")
    (RUN / "cshort" / f"regression_{args.arm}_{args.ckpt}.json").write_text(
        json.dumps(out, indent=1) + "\n")
    print(f"CSHORT_REGRESSION arm={args.arm} ckpt={args.ckpt} pass={out['pass']} "
          f"fails={len(out['fails'])}")
    sys.exit(0 if out["pass"] else 4)


if __name__ == "__main__":
    main()
