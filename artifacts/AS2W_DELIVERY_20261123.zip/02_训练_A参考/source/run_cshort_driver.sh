#!/usr/bin/env bash
# DR3c C-short driver: waits for zero-update consistency + special evals, then
# trains A-recipe 50 updates (save 25/50), evaluates obs0+DR0 at 25/50, checks
# regression vs A (support drop>0.03 or tracking drop>0.05 -> stop).
set -uo pipefail
WS=/root/as2w/retrain-wheeldiff-dr3c-20261122
RUN=/root/gpufree-data/as2w-runs/retrain-dr3c-20261122
V41=/root/as2w/retrain-wheeldiff-v41-20261121
PY=/root/as2w/preflight/isaac-python
SP=/usr/bin/python3
AB=/root/gpufree-data/as2w-runs/retrain-dr3a-20261122/evals_AB_baseline
A_DR0=/root/gpufree-data/as2w-runs/retrain-dr2b-20261122/evals/dr2b_s1_seed42_final_dr0
LOG=$WS/CSHORT_DRIVER.log
mkdir -p "$RUN/cshort/evals" "$RUN/cshort/v22"
log() { echo "$(date -Is) $*" >> "$LOG"; }
log "CSHORT_DRIVER_START pid=$$"
# 1) require zero-update consistency PASS
for i in $(seq 1 120); do
  [ -f "$RUN/zero_update/check.json" ] && break
  sleep 15
done
CONS=$($SP -c "import json;print(json.load(open('$RUN/zero_update/check.json'))['consistent'])" 2>/dev/null || echo ERR)
log "ZERO_UPDATE_CONSISTENT=$CONS"
[ "$CONS" = "True" ] || { log "ABORT zero-update consistency failed"; exit 2; }
# 2) special evals may run concurrently (small env count); proceed
log "GPU_PROCEED_CONCURRENT"
# 3) train 2 seeds x 50 updates (0/25/50 checkpoints)
for seed in 42 43; do
  out=$RUN/cshort/baseline_s${seed}/train
  mkdir -p "$(dirname "$out")"
  log "TRAIN_LAUNCH seed=$seed out=$out"
  AS2W_SAVE_INTERVAL=25 SEED=$seed OUT="$out" UPDATES=50 bash "$WS/src/run_wheeldiff_cshort.sh" > "$RUN/cshort/baseline_s${seed}/train.log" 2>&1 &
  log "TRAIN_PID seed=$seed pid=$!"
done
for i in $(seq 1 360); do
  ok=1
  for seed in 42 43; do [ -s "$RUN/cshort/baseline_s${seed}/train/model_50.pt" ] || ok=0; done
  [ "$ok" = "1" ] && break
  sleep 20
done
for seed in 42 43; do
  [ -s "$RUN/cshort/baseline_s${seed}/train/model_50.pt" ] || { log "ABORT missing model_50 s$seed"; exit 3; }
done
log "TRAIN_DONE $(date -Is)"
# 4) eval 25/50 obs0 + dr0
for ckpt in 25 50; do
  for seed in 42 43; do
    d=$RUN/cshort/baseline_s${seed}/train
    o=$RUN/cshort/evals/DR3C_cshort_s${seed}_${ckpt}
    [ -s "$o"_obs0/flat.npz ] || bash "$WS/src/eval_wheeldiff_dr3c.sh" "$d/model_${ckpt}.pt" "$o"_obs0 2 "" 0 > "$d/eval_${ckpt}_obs0.log" 2>&1
    [ -s "$o"_dr0/flat.npz ] || bash "$WS/src/eval_wheeldiff_dr3c.sh" "$d/model_${ckpt}.pt" "$o"_dr0 0 "" 0 > "$d/eval_${ckpt}_dr0.log" 2>&1
  done
  $SP - "$RUN" "$ckpt" "$AB" "$A_DR0" > "$RUN/cshort/v22/manifest_${ckpt}.json" <<'PY'
import json, sys
run, ckpt, ab, a_dr0 = sys.argv[1:5]
evals = [{"tag": "A_final_0", "kind": "obs0", "dir": f"{ab}/A_final_0"},
         {"tag": "A_dr0_parent", "kind": "dr0", "dir": a_dr0}]
for s in (42, 43):
    for kind in ("obs0", "dr0"):
        evals.append({"tag": f"D3B_s{s}_{ckpt}_{kind}", "kind": kind,
                      "dir": f"{run}/cshort/evals/DR3C_cshort_s{s}_{ckpt}_{kind}"})
print(json.dumps({"baseline_tag": "A_final_0", "evals": evals}, indent=1))
PY
  $PY -W ignore "$WS/gate_v22_dr3c.py" --manifest "$RUN/cshort/v22/manifest_${ckpt}.json" \
     --config "$V41/gate_v22/gate_v22_config.json" --outdir "$RUN/cshort/v22/ckpt_${ckpt}" \
     > "$RUN/cshort/v22/gate_${ckpt}.log" 2>&1
  $SP "$WS/cshort_check.py" --ckpt "$ckpt" --gate "$RUN/cshort/v22/ckpt_${ckpt}/gate_v22_results.json" \
     >> "$LOG" 2>&1
  RC=$?
  log "REGRESSION ckpt=$ckpt rc=$RC"
  [ "$ckpt" = "25" ] && [ "$RC" -ne 0 ] && { log "STOP at 25 (regression)"; echo "CSHORT_STOP_25"; exit 4; }
  [ "$ckpt" = "50" ] && [ "$RC" -ne 0 ] && { log "STOP at 50 (regression)"; echo "CSHORT_STOP_50"; exit 4; }
done
log "CSHORT_BASELINE_OK $(date -Is)"
echo "CSHORT_BASELINE_OK"
