#!/usr/bin/env python3
"""DR3c special evaluation (fixed 2026-11-23): zero-command 30 s + low-speed bins.

Fixes vs previous version:
  * yaw is unwrapped in radians and converted to DEGREES before the 3 deg gate.
  * fixed trial IDs; ALL attempts (including invalid/fallen) are recorded in the
    attempts list and counted in attempts/valid/invalid/falls totals; fallen
    trials are never dropped or rewritten as falls=0; valid trials are recorded
    exactly once (no duplicate rows).
  * absolute steady heights + all three height deltas are reported.
  * short-screen data (obs0/DR0 only for the continuation decision); obs2/exec3
    are diagnosis-only and are evaluated with the full v2.2 separately.
"""
import argparse
import csv
import json
import math
import pathlib
import sys
import traceback

WHEELS = ("FL", "FR", "RL", "RR")
ZERO_WARMUP_S = 2.0
ZERO_MEASURE_S = 30.0
LOW_BINS = (0.05, -0.05, 0.10, -0.10, 0.15, -0.15)
LOW_BIN_S = 8.0


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--ckpt", type=pathlib.Path, required=True)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--outdir", type=pathlib.Path, required=True)
    p.add_argument("--engine", choices=("isaac",), default="isaac")
    p.add_argument("--trials", type=int, default=6)
    p.add_argument("--max-attempts", type=int, default=20)
    p.add_argument("--terrain", default="flat")
    p.add_argument("--dr-level", type=int, default=0)
    p.add_argument("--ground-friction", type=float, default=0.35)
    p.add_argument("--asset", type=pathlib.Path,
                   default=pathlib.Path("/root/as2w/assets/generated/as2w/as2w.usda"))
    p.add_argument("--reward-config", type=pathlib.Path, default=None)
    return p.parse_args()


def build_raw(args, num_envs):
    import task as task_mod

    class A:
        pass
    a = A()
    a.out = args.outdir
    a.asset = args.asset
    a.terrain = args.terrain
    a.num_envs = num_envs
    a.dr_level = args.dr_level
    a.seed = args.seed
    a.wheel_diff = True
    a.ground_friction = args.ground_friction
    a.reward_config = args.reward_config or pathlib.Path(task_mod.__file__).with_name(
        "reward_config_wheeldiff_v41.json")
    a.obs_delay = 0
    a.command_hold_s = 2.5
    a.gait_phase = False
    a.gait_period_s = 1.0
    a.step_only = False
    a.right_only = False
    a.delay_ticks = None
    a.eval_delay_ticks = None
    a.eval_obs_delay_ticks = None
    a.cmd_scale = 1.0
    raw = task_mod.build_task(a)
    raw.cfg.episode_length_s = 60.0
    try:
        raw.max_episode_length = int(round(60.0 / raw.step_dt))
    except Exception:
        pass
    return raw


def make_policy(raw, ckpt):
    from tensordict import TensorDict
    from isaaclab_rl.rsl_rl import (RslRlVecEnvWrapper, create_rsl_rl_runner,
                                    check_rsl_rl_version, handle_deprecated_rsl_rl_cfg)
    from isaaclab_tasks.core.velocity.config.go2.agents.rsl_rl_ppo_cfg import UnitreeGo2RoughPPORunnerCfg
    config = UnitreeGo2RoughPPORunnerCfg()
    config.device = raw.device
    config.num_steps_per_env = 1
    config.obs_groups = {"actor": ["policy"], "critic": ["critic"]}
    config = handle_deprecated_rsl_rl_cfg(config, check_rsl_rl_version())
    runner = create_rsl_rl_runner(RslRlVecEnvWrapper(raw), config, log_dir=None)
    runner.load(str(ckpt), load_cfg={"actor": True, "critic": True})
    model = runner.get_inference_policy()

    def policy(obs):
        return model(TensorDict(obs, batch_size=[raw.num_envs], device=raw.device))
    return policy


class Snapshot:
    def __init__(self, raw):
        self.raw = raw
        from environment import tensor
        self._t = tensor
        contact = raw.scene["contacts"]
        self.feet = [contact.body_names.index(name) for name in ("FL_foot", "FR_foot", "RL_foot", "RR_foot")]
        self.wheel_ids = raw.wheel_ids
        self.steps = []

    def record(self):
        t = self._t
        d = self.raw.robot.data
        contact = self.raw.scene["contacts"]
        force = contact.data.net_normal_forces_w.norm(dim=-1)
        self.steps.append({
            "pos": t(d.root_pos_w)[:, :3].detach().cpu().numpy().copy(),
            "quat": t(d.root_quat_w).detach().cpu().numpy().copy(),
            "q": t(d.joint_pos)[:, self.wheel_ids].detach().cpu().numpy().copy(),
            "dq": t(d.joint_vel)[:, self.wheel_ids].detach().cpu().numpy().copy(),
            "tilt": __import__("torch").rad2deg(__import__("torch").acos(
                (-t(d.projected_gravity_b)[:, 2]).clamp(-1, 1))).detach().cpu().numpy().copy(),
            "vx": t(d.root_lin_vel_b)[:, 0].detach().cpu().numpy().copy(),
            "loads": force[:, self.feet].detach().cpu().numpy().copy(),
        })


def arrays_from_steps(steps):
    return {k: __import__("numpy").stack([s[k] for s in steps], axis=0) for k in
            ("pos", "quat", "q", "dq", "tilt", "vx", "loads")}


def yaw_from_quat_xyzw(q):
    x, y, z, w = q[..., 0], q[..., 1], q[..., 2], q[..., 3]
    return __import__("numpy").arctan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))


def run_group(raw, policy, command, steps, trials_needed, max_attempts):
    """Return attempts list (all attempts, unique trial IDs) and valid counts.

    Each attempt is recorded once per env slot. A fallen/terminated attempt is
    invalid=True, falls=1, and its window is never merged into another trial.
    """
    import numpy as np
    import torch
    n = command.shape[0]
    attempts = []
    valid_counts = [0] * n
    attempt = 0
    while any(v < trials_needed for v in valid_counts) and attempt < max_attempts:
        attempt += 1
        raw.reset()
        raw.exercise = command
        raw.command.copy_(command)
        obs = raw._get_observations()
        snap = Snapshot(raw)
        fell = np.zeros(n, dtype=bool)
        first_term = np.full(n, -1, dtype=int)
        with torch.inference_mode():
            for i in range(steps):
                act = policy(obs)
                obs, _, term, trunc, _ = raw.step(act)
                snap.record()
                bad = (term | trunc).detach().cpu().numpy().astype(bool)
                for j in np.flatnonzero(bad & ~fell):
                    first_term[j] = i
                fell |= bad
        arrays = arrays_from_steps(snap.steps)
        for j in range(n):
            if fell[j]:
                attempts.append({"trial_id": f"slot{j}-attempt{attempt}", "slot": j,
                                 "attempt": attempt, "valid": False, "falls": 1,
                                 "first_terminal_frame": int(first_term[j])})
                continue
            if valid_counts[j] >= trials_needed:
                continue
            valid_counts[j] += 1
            attempts.append({"trial_id": f"slot{j}-attempt{attempt}", "slot": j,
                             "attempt": attempt, "valid": True, "falls": 0,
                             "first_terminal_frame": None,
                             "arrays": {k: v[:, j] for k, v in arrays.items()}})
    return attempts


def summarize_zero(valid_rows):
    import numpy as np
    out = []
    for tr in valid_rows:
        a = tr["arrays"]
        p0 = np.median(a["pos"][100:150], axis=0)
        mid = np.median(a["pos"][300:350], axis=0)
        end = np.median(a["pos"][1550:1600], axis=0)
        xy = a["pos"][100:1600, :2] - p0[:2]
        xy_end = float(np.linalg.norm(end[:2] - p0[:2]))
        xy_max = float(np.max(np.linalg.norm(xy, axis=-1)))
        yaw = np.unwrap(yaw_from_quat_xyzw(a["quat"][:, :]))
        yaw0 = np.median(yaw[100:150], axis=0)
        yaw_end = np.median(yaw[1550:1600], axis=0)
        dyaw_rad = float(np.max(np.abs(yaw_end - yaw0)))
        q0 = np.median(a["q"][100:150], axis=0)
        qe = np.median(a["q"][1550:1600], axis=0)
        dq_wheel = qe - q0
        h_start = float(np.median(a["pos"][100:150, 2]))
        h_mid = float(np.median(a["pos"][300:350, 2]))
        h_end = float(np.median(a["pos"][1550:1600, 2]))
        out.append({"trial_id": tr["trial_id"], "slot": tr["slot"],
                    "xy_end_m": xy_end, "xy_max_m": xy_max,
                    "dyaw_rad": dyaw_rad, "dyaw_deg": math.degrees(dyaw_rad),
                    "wheel_max_rad": float(np.max(np.abs(dq_wheel))),
                    "wheel_abs_sum_rad": float(np.sum(np.abs(dq_wheel))),
                    "support_frac": float(np.mean((a["loads"][100:1600] >= 3.0).all(axis=-1))),
                    "h_start_cm": h_start * 100, "h_mid_cm": h_mid * 100, "h_end_cm": h_end * 100,
                    "dz_0_5_cm": (h_start - h_mid) * 100,
                    "dz_5_30_cm": (h_mid - h_end) * 100,
                    "dz_0_30_cm": (h_start - h_end) * 100,
                    "tilt_p95_deg": float(np.quantile(a["tilt"][100:1600], .95)),
                    "tilt_max_deg": float(np.max(a["tilt"][100:1600])),
                    "falls": 0, "valid": True})
    return out


def summarize_low(valid_rows, cmd, bin_name):
    import numpy as np
    out = []
    for tr in valid_rows:
        a = tr["arrays"]
        T = a["vx"].shape[0]
        steady = slice(50, T)
        v = float(np.mean(a["vx"][steady]))
        z0 = float(np.median(a["pos"][0:50, 2]))
        ze = float(np.median(a["pos"][T - 50:T, 2]))
        out.append({"trial_id": tr["trial_id"], "slot": tr["slot"],
                    "bin": bin_name, "cmd_m_s": cmd, "v_meas_m_s": v,
                    "tracking_ratio": v / cmd if cmd else float("nan"),
                    "abs_v_err_m_s": abs(v - cmd),
                    "tolerance_m_s": max(0.02, 0.2 * abs(cmd)),
                    "dz_cm": (z0 - ze) * 100, "support_frac": float(np.mean(
                        (a["loads"][steady] >= 3.0).all(axis=-1))),
                    "tilt_p95_deg": float(np.quantile(a["tilt"][steady], .95)),
                    "tilt_max_deg": float(np.max(a["tilt"][steady])),
                    "falls": 0})
    return out


def count(attempts, valid_rows):
    return {"attempts": len(attempts), "valid": len(valid_rows),
            "invalid": sum(1 for a in attempts if not a["valid"]),
            "falls_total": sum(int(a["falls"]) for a in attempts)}


def main():
    args = parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    from isaaclab.app import AppLauncher
    app = AppLauncher(headless=True).app
    global np, torch
    import numpy as np
    import torch
    raw = None
    try:
        raw = build_raw(args, args.trials)
        policy = make_policy(raw, args.ckpt)
        result = {"ckpt": str(args.ckpt), "seed": args.seed, "engine": "isaac",
                  "dr_level": args.dr_level, "protocol": "DR3c-special-v2",
                  "continue_training": False, "promotable": False, "status": "OK"}
        # A. zero command 30 s
        zero_cmd = torch.zeros(raw.num_envs, 3, device=raw.device)
        steps = int((ZERO_WARMUP_S + ZERO_MEASURE_S) / raw.step_dt)
        attempts = run_group(raw, policy, zero_cmd, steps, args.trials, args.max_attempts)
        valid_attempts = [a for a in attempts if a["valid"]]
        zero_rows = summarize_zero(valid_attempts)
        zg = {"falls_max": 0, "invalid_max": 0, "dz_5_30_max_cm": 0.20,
              "xy_max_cm": 5.0, "dyaw_max_deg": 3.0, "wheel_max_rad": 0.20,
              "support_min": 0.95, "tilt_p95_max_deg": 4.0}
        cnt0 = count(attempts, zero_rows)
        zero_pass = (cnt0["falls_total"] == 0 and cnt0["invalid"] == 0
                     and len(zero_rows) >= args.trials and all(
                         r["dz_5_30_cm"] <= zg["dz_5_30_max_cm"]
                         and r["xy_max_m"] * 100 <= zg["xy_max_cm"]
                         and r["dyaw_deg"] <= zg["dyaw_max_deg"]
                         and r["wheel_max_rad"] <= zg["wheel_max_rad"]
                         and r["support_frac"] >= zg["support_min"]
                         and r["tilt_p95_deg"] <= zg["tilt_p95_max_deg"] for r in zero_rows))
        result["zero"] = {"trials": zero_rows, "attempts_list": [
            {k: a[k] for k in ("trial_id", "slot", "attempt", "valid", "falls",
                               "first_terminal_frame") if k in a} for a in attempts],
            "attempts": cnt0["attempts"], "valid": cnt0["valid"],
            "invalid": cnt0["invalid"], "falls_total": cnt0["falls_total"],
            "gates": zg, "pass": bool(zero_pass)}
        # B. low-speed six bins
        low_gates = {"ratio_min": 0.80, "ratio_max": 1.20, "support_min": 0.90,
                     "falls_max": 0, "invalid_max": 0}
        bins = []
        all_low_ok = True
        low_falls = 0
        low_invalid = 0
        for cmd in LOW_BINS:
            cmd_t = torch.zeros(raw.num_envs, 3, device=raw.device)
            cmd_t[:, 0] = float(cmd)
            steps_low = int(LOW_BIN_S / raw.step_dt)
            att = run_group(raw, policy, cmd_t, steps_low, args.trials, args.max_attempts)
            vrows = summarize_low([a for a in att if a["valid"]], float(cmd), f"{cmd:+.2f}")
            c = count(att, vrows)
            low_falls += c["falls_total"]
            low_invalid += c["invalid"]
            ok = (c["falls_total"] == 0 and c["invalid"] == 0 and len(vrows) >= args.trials
                  and all(low_gates["ratio_min"] <= r["tracking_ratio"] <= low_gates["ratio_max"]
                          and r["abs_v_err_m_s"] <= r["tolerance_m_s"] + 1e-9
                          and r["support_frac"] >= low_gates["support_min"] for r in vrows))
            all_low_ok = all_low_ok and ok
            bins.append({"bin": f"{cmd:+.2f}", "cmd_m_s": float(cmd), "rows": vrows,
                         "attempts_list": [{k: a[k] for k in ("trial_id", "slot", "attempt",
                                                              "valid", "falls",
                                                              "first_terminal_frame") if k in a}
                                           for a in att],
                         "attempts": c["attempts"], "valid": c["valid"],
                         "invalid": c["invalid"], "falls_total": c["falls_total"],
                         "pass": bool(ok)})
        result["low"] = {"bins": bins, "gates": low_gates,
                         "falls_total": low_falls, "invalid": low_invalid,
                         "pass": bool(all_low_ok)}
        result["continue_training"] = bool(zero_pass and all_low_ok)
        result["promotable"] = bool(zero_pass and all_low_ok)
        result["note"] = ("short-screen uses zero-30s + low-speed six bins; "
                          "obs0/DR0 regression decides continuation; "
                          "obs2/exec3 are diagnosis-only; full v2.2 used for release")
        (args.outdir / "special.json").write_text(json.dumps(result, indent=1) + "\n")
        with (args.outdir / "trials.csv").open("w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["scene", "bin", "trial_id", "slot", "valid", "falls",
                        "xy_end_m", "xy_max_m", "dyaw_deg", "wheel_max_rad",
                        "support_frac", "h_start_cm", "h_mid_cm", "h_end_cm",
                        "dz_0_5_cm", "dz_5_30_cm", "dz_0_30_cm",
                        "tilt_p95_deg", "tilt_max_deg", "v_meas_m_s", "tracking_ratio",
                        "abs_v_err_m_s"])
            for r in zero_rows:
                w.writerow(["zero", "", r["trial_id"], r["slot"], r["valid"], r["falls"],
                            r["xy_end_m"], r["xy_max_m"], r["dyaw_deg"], r["wheel_max_rad"],
                            r["support_frac"], r["h_start_cm"], r["h_mid_cm"], r["h_end_cm"],
                            r["dz_0_5_cm"], r["dz_5_30_cm"], r["dz_0_30_cm"],
                            r["tilt_p95_deg"], r["tilt_max_deg"], "", "", ""])
            for b in bins:
                for r in b["rows"]:
                    w.writerow(["low", b["bin"], r["trial_id"], r["slot"], True, r["falls"],
                                "", "", "", "", r["support_frac"], "", "", "",
                                "", "", "", r["tilt_p95_deg"], r["tilt_max_deg"],
                                r["v_meas_m_s"], r["tracking_ratio"], r["abs_v_err_m_s"]])
        print("DR3C_SPECIAL_OK", args.outdir, "zero_pass", zero_pass,
              "low_pass", all_low_ok, "attempts", result["zero"]["attempts"],
              result["low"]["bins"][0]["attempts"], flush=True)
    except Exception:
        traceback.print_exc()
        try:
            (args.outdir / "special.json").write_text(json.dumps(
                {"status": "ABORT", "reason": "EXCEPTION", "continue_training": False,
                 "promotable": False}, indent=1) + "\n")
        except Exception:
            pass
        raise
    finally:
        if raw is not None:
            try:
                raw.close()
            except Exception:
                pass
        try:
            app.close()
        except Exception:
            pass


if __name__ == "__main__":
    main()
