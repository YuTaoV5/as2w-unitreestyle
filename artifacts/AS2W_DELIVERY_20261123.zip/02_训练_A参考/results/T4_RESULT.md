# T4_RESULT — 修正版 C1 25 更新（A 原配方，同 seed/预算/优化器初始化）

生成时间：2026-11-23 02:05 +08（Asia/Shanghai）
状态：**训练完成 25 实际更新；回归门 FAIL（1/32 checks）** → 按止损：T5 不启动、C2/C3/800 不启动、不再训练/不改阈值/不选种。

## 1. 配置与唯一变量（CONFIRMED）
| 项 | T3（C0） | T4（修正 C1） |
|---|---|---|
| parent | model_799.pt sha `4c92b1cb…` | 同 |
| seed | 42 / 43 | 同 |
| actual PPO updates | 25（iteration 24/25） | 25（iteration 24/25） |
| optimizer init / base_update | resume-update=0，同初始化 | 同 |
| lr / hold / obs0 / v4.1 | 1e-4 / 4.0 / obs0 / v4.1 | 同 |
| exec delay | 0/1/2/3 = .15/.35/.35/.15 | 同 |
| **command sampler** | **c0** | **c1（修正版）** |

`T4/config_diff.json`：`cmd_sampler_t3=c0`、`cmd_sampler_t4=c1`、`other_diffs_excluding_paths={}`、`same_parent=true`、`same_seed=true`、`base_update=[0,0]`。
显式复核 run.json：`command_hold_s` 均 4.0、`seed` 均 42、`resume` 同 model_799、`base_update` 均 0、`domain_config` 完全相等；`cmd_sampler` 唯一不同。
> `iterations` 顶层字段为 null（训练器把实际预算写在 `actual_invocation`），实际更新数以训练日志 `Learning iteration 24/25` 为准。

## 2. 产物与 SHA
- `T4/s42/train/update_25.pt` **`0432f104925af101cec15e35936a635a355e661b4ed0bd038de28ff97c670a79`**（与 model_24 完全相同，已验证）
- `T4/s43/train/update_25.pt` **`5562e69cabe55993db12b3ce241f6673bdf8ea3be0130cd9df56dfa8a8b8dfcd`**（与 model_24 相同）
- `T4/regression.json` **`a2459e23e6ed1970d39ad37db78ded5ecf87ed9de3e39835a36029c2250982c0`**
- `T4/v22/ckpt_25/gate_v22_results.json` `23820081a7a23ee759d06e054d51d9fd42b5e6c017d11c835015573be2d83f57`
- `T4_DRIVER.log` `2e5b9036ec6c8bd58c0ca0b363b6ca782f44a1e6f08c8a8314b36d469317ea1e`
- `t4_check.py` `92977e1ae7d3a4eda1808707b9eab848074b8856eb97b9342ee245cf8b874d47`
- 采样器/配置：`src/task.py`（修正 C1）`6629e0fb…`；`src/domain.py` `d08231f0…`（仅 T1 诊断 env 守卫，T4 未启用）；`src/run.py` `9bc3856f…`；`configs/domain_config_A_recipe.json` `2947bfc7…`；T4 wrapper `57f9eeaa…`。

## 3. 回归结果（冻结阈值 support≤0.02 / tracking≤0.03）
- **32 checks，31 pass，1 fail**：
  - **`s42.obs0.arc.tracking` drop = 0.031066… > 0.03（超 0.00107）**；cur=1.00335，ref=1.03442。
- Top-5 drops：
  1. s42.obs0.arc.tracking **0.03107**（FAIL）
  2. s43.dr0.yaw_left_slow.tracking 0.02730（pass）
  3. s42.dr0.yaw_left_slow.tracking 0.02716（pass）
  4. s42.obs0.reverse.support 0.02000（pass，恰在门限）
  5. s43.obs0.arc.tracking 0.01951（pass）
- 归因：这是**边缘超门限（0.0011）**，非崩塌；仅 seed42/obs0/arc 一项，seed43 同项 pass；无 support 崩塌、无 falls 类异常。T3(C0) 的 arc.tracking 未超门，因此不能把差异单独归咎于采样器（25 更新随机性/单 seed 边缘都可能）。**结论：修正 C1 25 更新未过冻结回归门，低速度收益问题未被回答。**

## 4. 评测口径（P0 无观测环）
- `src/eval_wheeldiff_dr3c.sh` sha **`242a99965d0e41ae8e25f69ca9eba4a0cf69535c9fdd985151569e8c999f7cd0`**（00:09 修补版：obsdelay=0 时不传 `--obs-delay-ticks`；eval_args 仍记 obs_delay=0）。
- `T4/evals/`：
  - `T4_s42_25_obs0` / `T4_s43_25_obs0`：`EVAL_CONFIG reward_config_wheeldiff_v41.json dr=2 exec_delay=none obs_delay=0`
  - `T4_s42_25_dr0` / `T4_s43_25_dr0`：`dr=0 exec_delay=none obs_delay=0`

## 5. T2 caveat（按 lead 口径，未改、不重跑）
L decel 的 0.5 s ramp 以 episode 边界 12.0 s 为终点，末步仍约 4% 幅值；mjsim 建议下一轮 `t_decel_end=11.5s`。本轮按要求**保持当前 fixed sampler**，不引入第二变量；该 caveat 只影响 episode 最后一帧，不改变“恒速档不被清零”的结论，T4 不因此重跑。T2 证据见 `diag/t2_c1_dwell/`、`diag/t2_fixedleg/`。

## 6. 止损与未做事项
- **T5 未启动/未 claim**；C2/C3/800 未启动；无补救训练；未改阈值/包/权重；未导出/切候选。
- 周一包 `policy.onnx` sha `63f1c5b6…`、阈值 JSON sha `119ca598…`、A `model_799.pt` sha `4c92b1cb…` 均未变。
- 证据全部保留在 `T4/`（143 MB），不删除/不覆盖。
