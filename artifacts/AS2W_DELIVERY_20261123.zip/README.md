# AS2-W 交付整理包（2026-11-23）

> 本目录把 **A/v4x 部署包、训练配方与结果、脚本、门限/现场证据** 分开归档；所有文件均为当前实测状态，不把“已编译/已回放”误写成“已发布”。

## 0. 当前结论（先读）

- **部署候选**：A（DR2b seed42 final，`model_799`），ONNX `63f1c5b6…`。
- **CPRO ARM64 离线部署已建立**：`/root/as2w_deploy_v4x`，CTest **9/9 PASS**，offline-audit **PASS**。
- **FixedStand 已按原厂数据修正**：leg **kp200/kd4**、wheel **kp0/kd0.5**、官方 t2 站姿；**策略阶段仍保持训练合同 55/2**。
- **发布仍未放行**：owner 已签方案 2（固定输入 raw action ≤1e-6、最终 LowCmd ≤1e-6；闭环 raw action 仅诊断），但 **完整 FSM/DDS LowCmd、DDS/publisher 50 Hz、M0、实际加载文件核验、owner 最终放行** 尚未全部完成。
- **zero-B 实机尚未通过**：
  - 55/2 版：A 进入 FixedStand，但 B 被拒（`pose_error=0.389 > 0.35`），X 退出；
  - 200/4 修正版：A 进入 FixedStand，但 B 未在 30 s 内按下，自动 squat；
  - 第二次重跑在 Passive 被 X 中止；
  - 机器人已恢复原厂 `ai`；**未进入 PolicyWalk、未完成 T0/T1**。
- **训练分支**：T3（A 原配方 @25）PASS；T4（修正 C1 @25）FAIL（s42 obs0 arc tracking 0.0311 > 0.03）；T5/C2/C3/800 未启动；2e-6 已撤回。

## 1. 目录结构

```text
AS2W-交付整理-20261123/
├── 01_部署包_A_v4x/
│   ├── bin/
│   │   ├── as2w_unitree58v4_lp5_publish      # ARM64, 零速/固定站发布端
│   │   ├── as2w_unitree58v4_lp5_replay       # ARM64, 离线回放
│   │   └── v4x_field.sh                      # status|audit|replay|sha（无发布入口）
│   ├── models/unitree58-v4x/{policy.onnx,deploy.yaml}
│   ├── config/unitree58_measured.map
│   ├── source/                               # controller/replay/publisher 源码
│   ├── manifest/V4X_DEPLOY_MANIFEST.json(.sha256)
│   ├── logs/                                 # CTest、audit、build、zero-B 现场日志
│   └── SHA256SUMS
├── 02_训练_A参考/
│   ├── configs/domain_config_A_recipe.json   # lr1e-4, hold4.0, exec0/1/2/3, obs0, v4.1
│   ├── source/{task.py,eval_special_dr3c.py,smoke_c1_commands.py,...}
│   ├── results/{T3,T4,cshort,c1_smoke}
│   ├── checkpoints/T3_s42/s43、T4_s42/s43 update_25.pt
│   └── scripts/patch_dr3c_sampler.py
├── 03_脚本/
│   ├── cpro_ubuntu.sh / cpro_host_net.sh     # CPRO 入口/网络（只读辅助）
│   ├── deploy_v4x_to_cpro.sh                 # 建立 /root/as2w_deploy_v4x
│   ├── deploy_v4x_stage_build.sh             # CPRO 原生 ARM64 构建
│   ├── patch_stand_gains.sh                  # 55/2 -> 200/4 + 轮0.5（stand阶段）
│   ├── patch_fixstand_full3.sh               # FixStand 起末段统一 200/4
│   ├── run_zero_b_release3.sh                # 一次 zero-B（会发 LowCmd）
│   ├── restore_ai.sh                         # SelectMode("ai")
│   ├── readonly_status.sh / mode_check.sh    # 只读状态
│   ├── wallclock_loop.cpp / run_wallclock3.sh
│   └── update_manifest_stand2.sh
└── 04_证据_T8 / 04_证据_门限与现场/
    ├── EXTENDED_REPLAY_REPORT.md
    ├── GATE_V4X_CROSSARCH_DRAFT.md
    ├── ZERO_B_FIELD_ATTEMPT-20261123.md
    └── CPRO_V4X_DEPLOY_ATTEMPT-20261123.md
```

## 2. 关键 SHA / 配置

| 对象 | 值 |
|---|---|
| A ONNX | `63f1c5b6a6bf5c7fd9fdcaa09cce93deb5aa5c81dc97c96e6c0dd72bf7ab64ee` |
| deploy.yaml | `531f07d0dbbf9ccc36d932db90e866c4db101d63e6e221b94dae0d4f358db123` |
| measured map | `a2f2963462bb566aec5eb016756d0e67591a5440e31c19cea627d518e01fe1bc` |
| ARM64 publish（stand 修正后） | `7418070199700fa7ffc503301c41db7c79c4abf992edde4b601fa632dcf175fc` |
| ARM64 replay | `6da02f9fc82018a775d2447bd9cf5e7e0166f792c77f19781159b770892745ea` |
| FixedStand | leg **200/4**，wheel **0/0.5**，官方 t2 q，dq=0 |
| PolicyWalk | leg **55/2**，wheel kd **2**（训练合同，不改） |

## 3. 使用方式（CPRO rootfs 内）

```bash
# 只读
cd /root/as2w_deploy_v4x
./tools/v4x_field.sh status
./tools/v4x_field.sh audit
./tools/v4x_field.sh replay /root/zero_speed_fixture.txt

# 0 Hz 现场测试（会发 LowCmd；必须现场急停/看护）
# 参考 03_脚本/run_zero_b_release3.sh；执行前先核对：
#   hdc target、robot ai → ReleaseMode、物理急停、吊装/看护
# 流程：ReleaseMode → publisher 等待 A → FixedStand 30 s → B 零速 → Brake/ReturnStand
# 任何异常按 X；结束务必 restore_ai.sh
```

> **注意**：当前包只有 `lp5_publish` / `lp5_replay`，**没有 ARM64 `lp5_joy_publish`**；本包不能做 T2/T3 遥控行走。JOY target 需按 ARM64_BUILD 补构建后再加入。

## 4. 现场 zero-B 事实
见 `04_证据_门限与现场/ZERO_B_FIELD_ATTEMPT-20261123.md`：
- 55/2：B reject pose_error **0.389**（RL calf 0.389）；
- 200/4：进入 FixedStand，但 B 未按期按下；
- 第二次：Passive 被 X 中止；
- 机器人已恢复 `ai`；**未进入 PolicyWalk**。

## 5. 门限状态
- Owner-signed 方案 2：固定输入 1e-6 / 最终 LowCmd 1e-6；闭环 raw action 仅诊断。
- T8：固定输入 12 场景 max **9.318e-7 PASS**；最终 LowCmd q **4.8e-7**/dq **9.6e-7**；闭环 raw action max **3.427e-6**（诊断）。
- **缺口**：完整 FSM/DDS LowCmd 逐帧、DDS/publisher 50 Hz、M0、实际加载文件哈希、owner 最终放行。
- 发布仍锁定；原门 FAIL 保留。

## 6. 训练分支
- A 原配方：`lr=1e-4, command_hold=4.0 s, exec delay 0/1/2/3, obs0, v4.1`。
- T3：2 seed 25 实际更新，regression 32/32 PASS。
- T4：修正 C1，2 seed 25 更新，**FAIL**（s42 obs0 arc tracking drop 0.0311 > 0.03）。
- C1 采样修复：恒速低速保持 vx、仅 decel 减速、直行只写 vx；smoke PASS。
- C2/C3/800 未启动；2e-6 已撤回。

## 7. 校验
```bash
cd AS2W-交付整理-20261123
sha256sum -c SHA256SUMS
```

## 8. 已知风险
1. **不能把本包当作已发布 A**；zero-B 尚未过 B gate。
2. 200/4 只允许 stand 阶段，**不得带进 PolicyWalk**。
3. `deploy.yaml` 的 `wz_limit=0.30` 是合同上限；现场必须 CLI 收紧到 **0.10**，vy=0。
4. 未完成 JOY target、DDS 50Hz、M0、完整 FSM 逐帧 LowCmd。
5. 训练 T4 失败；C1 旧权重不作为采样效果结论。

生成：2026-11-23 11:15（Asia/Shanghai）
