#!/bin/bash
set -euo pipefail
mkdir -p /root/as2w_deploy_v4x/field_zero_b_20261123c
cd /root/as2w_deploy
/root/as2w_deploy/build-sdk2/as2w_sdk2 motion-release eth0 > /root/as2w_deploy_v4x/field_zero_b_20261123c/release.log 2>&1 || true
cd /root/as2w_deploy_v4x/field_zero_b_20261123c
printf 'GO\n' | /root/as2w_deploy_v4x/build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish \
  /root/as2w_deploy_v4x/models/unitree58-v4x/deploy.yaml \
  /root/as2w_deploy_v4x/config/unitree58_measured.map eth0 \
  --i-confirm-lowcmd-publish --zero-b-trial --stand t2 \
  --interp-sec 3 --squat-sec 4 --stand-hold-seconds 30 --startup-wait-sec 180 \
  --vx-limit 0.10 --vy-limit 0.0 --wz-limit 0.10 \
  --stand-kp 200 --stand-kd 4 --debug >> publisher.log 2>&1
echo "PUBLISHER_RC=$?" >> publisher.log
