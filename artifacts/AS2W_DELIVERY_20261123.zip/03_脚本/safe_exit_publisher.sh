#!/bin/bash
# Safe stop for the v4x publisher, then restore official ai control.
# This script does NOT publish LowCmd itself; it only signals the publisher
# and then calls MotionSwitcher SelectMode("ai"). Prefer the remote buttons
# (A/Y/X) whenever they are reachable.
set -euo pipefail
ROOT=/root/as2w_deploy_v4x
export AS2W_UBUNTU_ROOTFS=/data/ubuntu_in_hm/ubuntu_rootfs
PIDS=$(pgrep -f 'build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish' || true)
if [ -n "$PIDS" ]; then
  echo "PUBLISHER_PIDS=$PIDS"
  kill -INT $PIDS 2>/dev/null || true
  for i in $(seq 1 10); do
    sleep 1
    PIDS=$(pgrep -f 'build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish' || true)
    [ -z "$PIDS" ] && break
  done
  if [ -n "$PIDS" ]; then
    echo "SIGINT did not stop; sending SIGTERM (no SIGKILL)"
    kill -TERM $PIDS 2>/dev/null || true
    sleep 3
    PIDS=$(pgrep -f 'build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish' || true)
  fi
  if [ -n "$PIDS" ]; then
    echo "STILL_RUNNING pids=$PIDS — use physical estop / remote X; do NOT kill -9 blindly"
    exit 20
  fi
else
  echo "NO_ACTIVE_PUBLISHER"
fi
cd /root/as2w_deploy
./build-sdk2/as2w_sdk2 motion-select eth0 ai 2>&1 | head -10 || true
timeout 8 ./build-sdk2/as2w_sdk2 motion-mode eth0 2>&1 | head -5 || true
echo "SAFE_EXIT_DONE"
