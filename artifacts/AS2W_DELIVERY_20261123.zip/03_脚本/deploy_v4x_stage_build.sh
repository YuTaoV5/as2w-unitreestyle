#!/bin/bash
# Stage/build v4x A package on CPRO inside Ubuntu rootfs.
# No LowCmd, no motion. Only local CPRO build/staging.
set -euo pipefail
ROOT=/root
PKG_TGZ=$ROOT/as2w_v4x_20261123_pkg.tar.gz
PKG_DIR=$ROOT/as2w_v4x_20261123_pkg
STAGE=$ROOT/as2w_deploy_v4x_staging_20261123
LOG=$ROOT/as2w_deploy_v4x_build_20261123.log
exec > >(tee "$LOG") 2>&1

echo "=== STEP 0 identity ==="
date -Is
uname -a
nproc

echo "=== STEP 1 package ==="
sha256sum "$PKG_TGZ"
rm -rf "$PKG_DIR"
mkdir -p "$PKG_DIR"
tar -xzf "$PKG_TGZ" -C "$PKG_DIR"
ls -l "$PKG_DIR/pkg"
sha256sum "$PKG_DIR/pkg/policy.onnx" "$PKG_DIR/pkg/deploy.yaml"

echo "=== STEP 2 stage source ==="
rm -rf "$STAGE"
cp -a /root/as2w_deploy "$STAGE"
rm -rf "$STAGE"/build* "$STAGE"/field_logs "$STAGE"/debug_*.csv 2>/dev/null || true
mkdir -p "$STAGE/deploy/robots/as2w/unitree58v4"
cp "$PKG_DIR/pkg/cpp_patch/CMakeLists.txt" "$STAGE/deploy/robots/as2w/unitree58v4/"
cp "$PKG_DIR/pkg/cpp_patch/unitree58v4_controller.cpp" "$STAGE/deploy/robots/as2w/unitree58v4/"
cp "$PKG_DIR/pkg/cpp_patch/unitree58v4_controller.hpp" "$STAGE/deploy/robots/as2w/unitree58v4/"
cp "$PKG_DIR/pkg/cpp_patch/unitree58v4_replay.cpp" "$STAGE/deploy/robots/as2w/unitree58v4/"
mkdir -p "$STAGE/models/unitree58-v4x"
cp "$PKG_DIR/pkg/policy.onnx" "$STAGE/models/unitree58-v4x/policy.onnx"
cp "$PKG_DIR/pkg/deploy.yaml" "$STAGE/models/unitree58-v4x/deploy.yaml"
test -s "$STAGE/config/unitree58_measured.map"
echo "map: $STAGE/config/unitree58_measured.map"

echo "=== STEP 3 patch common publisher for v4x ==="
python3 - <<'PY'
from pathlib import Path
p=Path('/root/as2w_deploy_v4x_staging_20261123/deploy/robots/as2w/common/as2w_publish.cpp')
s=p.read_text()
old='#include "../unitree58/unitree58_controller.hpp"\nnamespace active_policy = as2w_unitree58;'
new='#include "../unitree58v4/unitree58v4_controller.hpp"\nnamespace active_policy = as2w_unitree58v4;'
if old not in s:
    raise SystemExit('anchor common publish not found')
s=s.replace(old,new,1)
p.write_text(s)
print('patched common publisher include/namespace')

t=Path('/root/as2w_deploy_v4x_staging_20261123/CMakeLists.txt')
s=t.read_text()
old='if(AS2W_UNITREE58)\n  add_subdirectory(deploy/robots/as2w/unitree58)\nendif()'
new='if(AS2W_UNITREE58)\n  add_subdirectory(deploy/robots/as2w/unitree58v4)\nendif()'
if old not in s:
    raise SystemExit('anchor top CMake not found')
s=s.replace(old,new,1)
t.write_text(s)
print('patched top CMake subdir -> unitree58v4')
PY

echo "=== STEP 4 configure ==="
cd "$STAGE"
cmake -S . -B build-v4x \
  -DCMAKE_BUILD_TYPE=Release \
  -DAS2W_UNITREE58=ON -DAS2W_UNITREE58_LP5=ON \
  -DAS2W_UNITREE58_PUBLISH=ON -DAS2W_UNITREE58_ZERO_B_TRIAL=ON \
  -DBUILD_TESTING=ON \
  -DONNXRUNTIME_ROOT=/root/ort122 \
  -DCMAKE_PREFIX_PATH=/root/unitree_sdk2_install

echo "=== STEP 5 build ==="
cmake --build build-v4x -j"$(nproc)"

echo "=== STEP 6 ctest ==="
cd build-v4x
ctest --output-on-failure

echo "=== STEP 7 binaries ==="
find deploy/robots/as2w/unitree58v4 -maxdepth 1 -type f -printf '%p %s\n' 2>/dev/null || true
ls -l deploy/robots/as2w/unitree58v4 2>/dev/null || true
echo "=== DONE $(date -Is) ==="
