﻿#!/bin/bash
# Single-instance guarded zero-B launcher. Refuses to publish if:
#  - another publisher exists / lock held
#  - eth0 not UP / no LowState
#  - motion mode is not released (name= empty)
# After publisher exits: restore ai and release lock.
set -euo pipefail
ROOT=/root/as2w_deploy_v4x
D=${1:-/root/as2w_deploy_v4x/field_zero_b_guarded}
mkdir -p "$D"
LOCK=$ROOT/field_lowcmd.lock
if ! mkdir "$LOCK" 2>/dev/null; then
  if [ -f "$LOCK/pid" ] && kill -0 "$(cat "$LOCK/pid")" 2>/dev/null; then
    echo "ABORT: existing guarded publisher pid=$(cat "$LOCK/pid")" | tee -a "$D/preflight.log"
    exit 10
  fi
  rm -rf "$LOCK"; mkdir "$LOCK"
fi
cleanup() { rm -rf "$LOCK"; }
echo $$ > "$LOCK/pid"
trap cleanup EXIT
echo "GUARD pid=$$ dir=$D" | tee -a "$D/preflight.log"

if pgrep -af 'as2w_unitree58v4_lp5_publish' | grep -v "$0" >/dev/null 2>&1; then
  echo "ABORT: existing publisher process" | tee -a "$D/preflight.log"; exit 11
fi

ip link show eth0 2>/dev/null | grep -q 'state UP' || { echo "ABORT: eth0 not UP" | tee -a "$D/preflight.log"; exit 12; }
if ! timeout 8 /root/as2w_deploy/build-sdk2/as2w_sdk2 low-state eth0 rt/lowstate 2 2>&1 | grep -q 'low packets=[1-9]'; then
  echo "ABORT: no LowState packets" | tee -a "$D/preflight.log"; exit 13
fi
name=$(timeout 8 /root/as2w_deploy/build-sdk2/as2w_sdk2 motion-mode eth0 2>&1 | sed -n 's/.*name=//p' | head -1)
if [ -n "$name" ]; then
  echo "ABORT: motion mode is '$name', not released; run ReleaseMode explicitly first" | tee -a "$D/preflight.log"; exit 14
fi
echo "PREFLIGHT OK eth0=UP lowstate=OK mode=released" | tee -a "$D/preflight.log"

cd "$D"
printf 'GO\n' | /root/as2w_deploy_v4x/build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish \
  /root/as2w_deploy_v4x/models/unitree58-v4x/deploy.yaml \
  /root/as2w_deploy_v4x/config/unitree58_measured.map eth0 \
  --i-confirm-lowcmd-publish --zero-b-trial --stand t2 \
  --interp-sec 3 --squat-sec 4 --stand-hold-seconds 30 --startup-wait-sec 180 \
  --vx-limit 0.10 --vy-limit 0.0 --wz-limit 0.10 \
  --stand-kp 200 --stand-kd 4 --debug > publisher.log 2>&1 || true
echo "PUBLISHER_RC=$?" >> publisher.log
rm -rf "$LOCK"
cd /root/as2w_deploy
/root/as2w_deploy/build-sdk2/as2w_sdk2 motion-select eth0 ai > "$D/restore_ai.log" 2>&1 || true
echo DONE >> "$D/publisher.log"

