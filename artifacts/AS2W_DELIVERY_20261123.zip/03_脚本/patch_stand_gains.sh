#!/bin/bash
set -euo pipefail
cd /root/as2w_deploy_v4x
F=deploy/robots/as2w/common/as2w_publish.cpp
cp "$F" "deploy_logs/as2w_publish.cpp.bak-stand-gain-$(date +%Y%m%d-%H%M%S)"
python3 - <<'PY'
from pathlib import Path
p=Path('/root/as2w_deploy_v4x/deploy/robots/as2w/common/as2w_publish.cpp')
s=p.read_text()
# official FixedStand gains
s=s.replace('float stand_kp = 55.f;','float stand_kp = 200.f;',1)
s=s.replace('float stand_kd = 2.f;','float stand_kd = 4.f;',1)
s=s.replace('stand_kp < 55.f || stand_kp > 90.f','stand_kp < 55.f || stand_kp > 200.f',1)
# fixed stand target: official wheel damping 0.5
s=s.replace('        t.motors[i].kd = 2.f;\n    }\n    return t;','        t.motors[i].kd = 0.5f;\n    }\n    return t;',1)
# FixStand B2: use stand_kd instead of hardcoded 2 for legs
s=s.replace('                        t.motors[j].kp = interp.kp2;\n                        t.motors[j].kd = 2.f;','                        t.motors[j].kp = interp.kp2;\n                        t.motors[j].kd = stand_kd;',1)
p.write_text(s)
print('patched stand gains/wheel')
PY
echo "=== verify ==="
grep -nE "float stand_kp|float stand_kd|stand_kp >|t.motors\[i\]\.kd = 0.5f|t.motors\[j\]\.kd = stand_kd" "$F" | head -20
cmake --build build-v4x --target as2w_unitree58v4_lp5_publish -j"$(nproc)" > deploy_logs/rebuild_standgain.log 2>&1
ctest --test-dir build-v4x --output-on-failure > deploy_logs/ctest_standgain.log 2>&1
./build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish \
  models/unitree58-v4x/deploy.yaml config/unitree58_measured.map --offline-audit \
  > deploy_logs/offline_audit_standgain.stdout 2> deploy_logs/offline_audit_standgain.stderr
tail -2 deploy_logs/ctest_standgain.log
tail -2 deploy_logs/offline_audit_standgain.stdout
sha256sum build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish
