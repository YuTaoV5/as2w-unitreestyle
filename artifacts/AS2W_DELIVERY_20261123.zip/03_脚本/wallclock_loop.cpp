#include "unitree58v4_controller.hpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <fstream>
#include <iostream>
#include <numeric>
#include <stdexcept>
#include <thread>
#include <vector>

using Clock = std::chrono::steady_clock;
using as2w_unitree58v4::Controller;
using as2w_unitree58v4::load_config;
using as2w_unitree58v4::SensorState;
using as2w_unitree58v4::Vector3;

static double pct(std::vector<double> v, double p) {
    if (v.empty()) return 0.0;
    std::sort(v.begin(), v.end());
    size_t i = static_cast<size_t>(p * (v.size() - 1));
    return v[i];
}

int main(int argc, char** argv) {
    if (argc != 3) {
        std::cerr << "usage: wallclock_loop deploy.yaml fixture.txt\n";
        return 2;
    }
    try {
        Controller c(load_config(argv[1]));
        std::ifstream input(argv[2]);
        if (!input) throw std::runtime_error("Cannot open fixture");
        std::vector<std::array<float, 43>> rows;
        while (input) {
            std::array<float, 43> r{};
            bool ok = true;
            for (float& x : r) if (!(input >> x)) { ok = false; break; }
            if (ok) rows.push_back(r);
        }
        if (rows.empty()) throw std::runtime_error("Empty fixture");
        c.arm();
        constexpr int Frames = 600;              // 12 s at 50 Hz
        constexpr auto Period = std::chrono::milliseconds(20);
        std::ofstream csv("/root/wallclock_frames.csv");
        csv << "frame,step_us,period_us\n";
        std::vector<double> step_us, period_us;
        step_us.reserve(Frames);
        period_us.reserve(Frames);
        auto next = Clock::now();
        for (int f = 0; f < Frames; ++f) {
            const auto& r = rows[f % rows.size()];
            SensorState s;
            for (int i = 0; i < 4; ++i) s.body_to_world_wxyz[i] = r[1 + i];
            for (int i = 0; i < 3; ++i) s.gyro[i] = r[5 + i];
            for (int i = 0; i < 16; ++i) s.position[i] = r[8 + i];
            for (int i = 0; i < 16; ++i) s.velocity[i] = r[24 + i];
            Vector3 command{r[40], r[41], r[42]};
            const auto t0 = Clock::now();
            c.step(s, command, .02f);
            const auto t1 = Clock::now();
            next += Period;
            std::this_thread::sleep_until(next);
            const auto t2 = Clock::now();
            step_us.push_back(std::chrono::duration<double, std::micro>(t1 - t0).count());
            period_us.push_back(std::chrono::duration<double, std::micro>(t2 - t1).count() + step_us.back());
            csv << f << "," << step_us.back() << "," << period_us.back() << "\n";
        }
        auto stat = [](std::vector<double> v) {
            std::sort(v.begin(), v.end());
            double sum = std::accumulate(v.begin(), v.end(), 0.0);
            return std::array<double, 5>{v[0], v[v.size() / 2], v[static_cast<size_t>(0.95 * (v.size() - 1))], v.back(), sum / v.size()};
        };
        auto s = stat(step_us);
        auto p = stat(period_us);
        int over = 0, over_step = 0;
        for (double x : period_us) if (x > 20000.0) ++over;
        for (double x : step_us) if (x > 20000.0) ++over_step;
        std::cout << "STEP_US min=" << s[0] << " p50=" << s[1] << " p95=" << s[2] << " max=" << s[3] << " mean=" << s[4] << " gt20ms=" << over_step << "\n";
        std::cout << "PERIOD_US min=" << p[0] << " p50=" << p[1] << " p95=" << p[2] << " max=" << p[3] << " mean=" << p[4] << " gt20ms=" << over << "\n";
        std::cout << "FRAMES=" << Frames << " note=controller-only wall-clock sleep loop; no DDS/publisher/HDC/fileIO\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "wallclock_loop failed: " << e.what() << "\n";
        return 1;
    }
}

