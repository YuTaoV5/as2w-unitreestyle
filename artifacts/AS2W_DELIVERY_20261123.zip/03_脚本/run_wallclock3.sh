#!/bin/bash
set -euo pipefail
cd /root/as2w_deploy_v4x
g++ -O2 -std=c++17 -DAS2W_UNITREE58_LP5=1 -I deploy/robots/as2w/unitree58v4 -I deploy/include -I /root/ort122/include \
  /root/wallclock_loop.cpp deploy/robots/as2w/unitree58v4/unitree58v4_controller.cpp \
  -L/root/ort122/lib -lonnxruntime -lyaml-cpp -pthread -Wl,-rpath,/root/ort122/lib \
  -o /root/wallclock_loop > /root/wallclock_build.log 2>&1
/root/wallclock_loop models/unitree58-v4x/deploy.yaml /root/zero_speed_fixture.txt > /root/wallclock.out 2> /root/wallclock.err
cp /root/wallclock_frames.csv deploy_logs/wallclock_frames.csv
cat /root/wallclock.out
sha256sum /root/wallclock.out /root/wallclock_frames.csv deploy_logs/wallclock_frames.csv