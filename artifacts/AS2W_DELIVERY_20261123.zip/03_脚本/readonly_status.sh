#!/bin/bash
set -euo pipefail
echo "=== host net status ==="
/data/local/tmp/as2w_field/cpro_host_net.sh status 2>&1 || true
echo "=== sdk2 read-only state ==="
cd /root/as2w_deploy
if [ -x build-sdk2/as2w_sdk2 ]; then
  timeout 12 ./build-sdk2/as2w_sdk2 sport-state eth0 3 2>&1 | head -40 || echo "sport-state rc=$?"
  timeout 12 ./build-sdk2/as2w_sdk2 low-state eth0 rt/lowstate 3 2>&1 | head -80 || echo "low-state rc=$?"
else
  echo "no build-sdk2/as2w_sdk2"
fi
echo "=== publisher help (no run) ==="
cd /root/as2w_deploy_v4x
timeout 10 ./build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish --help 2>&1 | head -80 || true
