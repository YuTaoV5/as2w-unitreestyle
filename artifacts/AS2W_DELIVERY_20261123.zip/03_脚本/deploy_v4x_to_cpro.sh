#!/bin/bash
set -euo pipefail
ROOT=/root
SRC=$ROOT/as2w_deploy_v4x_staging_20261123
DEST=$ROOT/as2w_deploy_v4x
TS=$(date +%Y%m%d-%H%M%S)
LOG=$ROOT/as2w_deploy_v4x_deploy_${TS}.log
exec > >(tee "$LOG") 2>&1

echo "=== DEPLOY START $(date -Is) ==="
[ -d "$SRC" ] || { echo "missing staging $SRC"; exit 2; }
[ -s "$SRC/models/unitree58-v4x/policy.onnx" ] || exit 3
[ -s "$SRC/config/unitree58_measured.map" ] || exit 3

if [ -e "$DEST" ]; then
  mv "$DEST" "${DEST}.backup-${TS}"
  echo "backup old DEST -> ${DEST}.backup-${TS}"
fi
cp -a "$SRC" "$DEST"
cd "$DEST"
mkdir -p deploy_logs
chmod +x build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish \
         build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_replay

echo "=== KEY SHA ==="
sha256sum models/unitree58-v4x/policy.onnx models/unitree58-v4x/deploy.yaml \
  config/unitree58_measured.map \
  build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish \
  build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_replay | tee deploy_logs/KEY_SHA256.txt

echo "=== CTest ==="
ctest --test-dir build-v4x --output-on-failure 2>&1 | tee deploy_logs/ctest.log
rc_ctest=${PIPESTATUS[0]}; echo "CTEST_RC=$rc_ctest"
[ "$rc_ctest" -eq 0 ] || exit 4

echo "=== offline audit ==="
./build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish \
  models/unitree58-v4x/deploy.yaml config/unitree58_measured.map --offline-audit \
  > deploy_logs/offline_audit.stdout 2> deploy_logs/offline_audit.stderr
rc_audit=$?; echo "AUDIT_RC=$rc_audit"
tail -20 deploy_logs/offline_audit.stdout || true
tail -20 deploy_logs/offline_audit.stderr || true
[ "$rc_audit" -eq 0 ] || exit 5

echo "=== manifest ==="
python3 - <<'PY'
import hashlib, json, pathlib, datetime
D=pathlib.Path('/root/as2w_deploy_v4x')
def sha(p):
    h=hashlib.sha256(); h.update(pathlib.Path(p).read_bytes()); return h.hexdigest()
files={
 'policy.onnx':'models/unitree58-v4x/policy.onnx',
 'deploy.yaml':'models/unitree58-v4x/deploy.yaml',
 'unitree58_measured.map':'config/unitree58_measured.map',
 'lp5_publish':'build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish',
 'lp5_replay':'build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_replay',
}
m={
 'generated_at':datetime.datetime.now(datetime.timezone.utc).astimezone().isoformat(),
 'candidate':'A / DR2b seed42 final (model_799)',
 'onnx_sha256':sha(D/files['policy.onnx']),
 'deploy_yaml_sha256':sha(D/files['deploy.yaml']),
 'map_sha256':sha(D/files['unitree58_measured.map']),
 'publish_sha256':sha(D/files['lp5_publish']),
 'replay_sha256':sha(D/files['lp5_replay']),
 'ctest':'9/9 PASS',
 'offline_audit':'PASS',
 'cross_arch_original_gate':'FAIL 1.341e-6 > 1e-6',
 'gate_draft':'1e-6/2e-6/1e-6 framework signed, release NOT effective',
 'lowcmd_published':False,
 'publisher_started':False,
 'strict_first_flight':'vx<=0.10, wz<=0.10, vy=0, no arc/mixed; B gate 0.35'
}
(D/'V4X_DEPLOY_MANIFEST.json').write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
(D/'V4X_DEPLOY_MANIFEST.sha256').write_text(sha(D/'V4X_DEPLOY_MANIFEST.json')+'  V4X_DEPLOY_MANIFEST.json\n')
print(json.dumps(m,indent=2,ensure_ascii=False))
PY

echo "=== field helper (offline only) ==="
cat > tools/v4x_field.sh <<'EOS'
#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
cd "$ROOT"
case "${1:-status}" in
  status)
    echo "candidate=A; onnx=$(sha256sum models/unitree58-v4x/policy.onnx | cut -d' ' -f1)"
    echo "LOWCMD_PUBLISHED=false; publisher_started=false"
    ;;
  audit)
    exec ./build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish \
      models/unitree58-v4x/deploy.yaml config/unitree58_measured.map --offline-audit
    ;;
  replay)
    exec ./build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_replay \
      models/unitree58-v4x/deploy.yaml "${2:?fixture.txt}"
    ;;
  sha)
    sha256sum models/unitree58-v4x/policy.onnx models/unitree58-v4x/deploy.yaml \
      config/unitree58_measured.map \
      build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish
    ;;
  *) echo "usage: $0 status|audit|replay <fixture>|sha"; exit 2 ;;
esac
EOS
chmod +x tools/v4x_field.sh
./tools/v4x_field.sh status | tee deploy_logs/field_status.txt
echo "=== DEPLOY DONE $(date -Is) ==="
echo "DEST=$DEST LOG=$LOG"
