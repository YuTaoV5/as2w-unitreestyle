#!/bin/bash
set -euo pipefail
cd /root/as2w_deploy_v4x
python3 - <<'PY'
import hashlib,json,pathlib,datetime
D=pathlib.Path('/root/as2w_deploy_v4x')
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
m=json.loads((D/'V4X_DEPLOY_MANIFEST.json').read_text())
m['publish_sha256']=sha(D/'build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish')
m['gate']='OWNER-SIGNED scheme2: fixed-input raw action <=1e-6 + final LowCmd <=1e-6; closed-loop raw action diagnostic only; release NOT effective'
m['lowcmd_published_in_tests']=True
m['publisher_started_in_tests']=True
m['current_active_publisher']=False
m['release_authorized']=False
m['field_test_note']='zero-B tests 2026-11-23: 55/2 attempt B rejected pose_error=0.389; 200/4 attempt entered FixedStand but B not pressed; robot restored ai'
m['generated_at']=datetime.datetime.now(datetime.timezone.utc).astimezone().isoformat()
(D/'V4X_DEPLOY_MANIFEST.json').write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
(D/'V4X_DEPLOY_MANIFEST.sha256').write_text(sha(D/'V4X_DEPLOY_MANIFEST.json')+'  V4X_DEPLOY_MANIFEST.json\n')
print(json.dumps(m,indent=2,ensure_ascii=False))
PY
