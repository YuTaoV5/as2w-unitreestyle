#!/bin/bash
set -euo pipefail
cd /root/as2w_deploy_v4x
F=deploy/robots/as2w/common/as2w_publish.cpp
cp "$F" "deploy_logs/as2w_publish.cpp.bak-fixstand-full3-$(date +%Y%m%d-%H%M%S)"
python3 - <<'PY'
from pathlib import Path
p=Path('/root/as2w_deploy_v4x/deploy/robots/as2w/common/as2w_publish.cpp')
s=p.read_text()
old='                    interp.kp1 = 20.f; interp.kp2 = stand_kp;'
new='                    interp.kp1 = stand_kp; interp.kp2 = stand_kp; interp.kd2 = stand_kd;'
if old not in s: raise SystemExit('FixStand start anchor missing')
s=s.replace(old,new,1)
p.write_text(s)
print('patched FixStand kp1=stand_kp/kd2')
PY
grep -nE "interp.kp1 =|interp.kd2 =|t.motors\[j\]\.kd = interp.kd2" "$F" | head -20
cmake --build build-v4x --target as2w_unitree58v4_lp5_publish -j"$(nproc)" > deploy_logs/rebuild_fixstand_full3.log 2>&1
ctest --test-dir build-v4x --output-on-failure > deploy_logs/ctest_fixstand_full3.log 2>&1
./build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish \
  models/unitree58-v4x/deploy.yaml config/unitree58_measured.map --offline-audit \
  > deploy_logs/offline_audit_fixstand_full3.stdout 2> deploy_logs/offline_audit_fixstand_full3.stderr
grep -E "tests passed|failed" deploy_logs/ctest_fixstand_full3.log | tail -2
tail -1 deploy_logs/offline_audit_fixstand_full3.stdout
sha256sum build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish
