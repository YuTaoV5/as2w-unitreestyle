"""T11: after standing up with 200/4 from the OG ai_damping prone pose to official t2,
switch leg gains to 55/2 (policy training contract) while keeping the target:
  A: target stays official t2 (pure gain effect)
  B: target frozen to the actual q at the switch instant (no target jump)
Question: does 55/2 change posture / collapse backward / lose hip inward?
MuJoCo only, 26 kg / mu=0.35, 200 Hz, no robot/publisher.
"""
import csv
import hashlib
import json
import math
import os
import time

import numpy as np
import mujoco

W = "/root/as2w/mujoco-sim2sim-20261121"
os.chdir(W)
OUT = os.path.join(W, "results", "switch_552")
os.makedirs(OUT, exist_ok=True)
XML = os.path.join(W, "as2w_stand200.xml")
assert os.path.isfile(XML)

T2 = {"hip": [0.15, -0.15, 0.15, -0.15], "thigh": 0.60, "calf": -1.20}
PRONE = {"hip": [-0.562, 0.562, -0.562, 0.562], "thigh": 1.019, "calf": -2.762}
MJ_LEGS = [f"{l}_{p}" for l in ("FL", "FR", "RL", "RR") for p in ("hip", "thigh", "calf")]
OFF_ORDER = ["FR", "FL", "RR", "RL"]
WH_NAMES = ("FL_foot", "FR_foot", "RL_foot", "RR_foot")


def off_to_mj(vec_off):
    d = {}
    for i, name in enumerate(OFF_ORDER):
        d[f"{name}_hip"] = vec_off[3 * i]
        d[f"{name}_thigh"] = vec_off[3 * i + 1]
        d[f"{name}_calf"] = vec_off[3 * i + 2]
    return np.array([d[n] for n in MJ_LEGS])


def q_of(pose):
    v = []
    for name in OFF_ORDER:
        j = {"FR": 0, "FL": 1, "RR": 2, "RL": 3}[name]
        v += [pose["hip"][j], pose["thigh"], pose["calf"]]
    return off_to_mj(np.array(v))


Q_T2 = q_of(T2)
Q_PRONE = q_of(PRONE)
LIM = {"hip": 60.0, "thigh": 60.0, "calf": 90.0}
LEG_LIM = np.array([LIM[n.split("_")[1]] for n in MJ_LEGS])

m = mujoco.MjModel.from_xml_path(XML)
d = mujoco.MjData(m)
LEG_AID = [m.actuator(f"a_{n}").id for n in MJ_LEGS]
WH_AID = [m.actuator(f"a_{n}").id for n in WH_NAMES]
LEG_QADR = [m.jnt_qposadr[m.joint(n).id] for n in MJ_LEGS]
WH_QADR = [m.jnt_qposadr[m.joint(n).id] for n in WH_NAMES]
LEG_DADR = [m.jnt_dofadr[m.joint(n).id] for n in MJ_LEGS]
WHEEL_GEOMS = []
for n in WH_NAMES:
    b = m.body(n).id
    WHEEL_GEOMS.append([g for g in range(m.ngeom) if m.geom_bodyid[g] == b and m.geom_contype[g] != 0][0])
FLOOR_GID = int(m.geom("floor").id)


def set_gains(kp, kv, wheel_kv=0.5):
    for aid in LEG_AID:
        m.actuator_gainprm[aid, 0] = kp
        m.actuator_biasprm[aid, 1] = -kp
        m.actuator_biasprm[aid, 2] = -kv
    for aid in WH_AID:
        m.actuator_gainprm[aid, 0] = wheel_kv
        m.actuator_biasprm[aid, 0] = 0.0
        m.actuator_biasprm[aid, 1] = 0.0
        m.actuator_biasprm[aid, 2] = -wheel_kv


def wheel_forces():
    fn = np.zeros(4)
    nonwheel = 0
    for i in range(d.ncon):
        c = d.contact[i]
        g1, g2 = int(c.geom1), int(c.geom2)
        if FLOOR_GID not in (g1, g2):
            continue
        other = g2 if g1 == FLOOR_GID else g1
        res = np.zeros(6)
        mujoco.mj_contactForce(m, d, i, res)
        if other in WHEEL_GEOMS:
            fn[WHEEL_GEOMS.index(other)] += abs(res[0])
        else:
            nonwheel += 1
    return fn, nonwheel


def init_prone():
    mujoco.mj_resetData(m, d)
    for k, a in enumerate(LEG_QADR):
        d.qpos[a] = Q_PRONE[k]
    for a in WH_QADR:
        d.qpos[a] = 0.0
    d.qpos[0:2] = 0.0
    d.qpos[3:7] = [1.0, 0.0, 0.0, 0.0]

    def hit():
        for i in range(d.ncon):
            c = d.contact[i]
            g1, g2 = int(c.geom1), int(c.geom2)
            if FLOOR_GID in (g1, g2) and ((g2 if g1 == FLOOR_GID else g1) in WHEEL_GEOMS):
                return True
        return False
    lo, hi = 0.02, 0.60
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        d.qpos[2] = mid
        d.qvel[:] = 0
        mujoco.mj_forward(m, d)
        if hit():
            lo = mid
        else:
            hi = mid
    d.qpos[2] = hi + 1e-4
    mujoco.mj_forward(m, d)
    for _ in range(100):                      # settle prone pose at 200/4
        set_gains(200, 4)
        for k, aid in enumerate(LEG_AID):
            d.ctrl[aid] = Q_PRONE[k]
        for aid in WH_AID:
            d.ctrl[aid] = 0.0
        mujoco.mj_step(m, d)


def run(group, switch_t=8.0, end_t=18.0, rise_t=3.0, seed=42):
    init_prone()
    dt = m.opt.timestep
    rows = []
    q_freeze = None
    nsteps = int(round(end_t / dt))
    for i in range(nsteps):
        t = i * dt
        if t < rise_t:
            a = t / rise_t
            q_t = Q_PRONE + a * (Q_T2 - Q_PRONE)
            kp, kv = 200.0, 4.0
        elif t < switch_t:
            q_t = Q_T2.copy()
            kp, kv = 200.0, 4.0
        else:
            kp, kv = 55.0, 2.0
            if group == "A_keep_target":
                q_t = Q_T2.copy()
            else:
                if q_freeze is None:
                    q_freeze = np.array([d.qpos[a] for a in LEG_QADR]).copy()
                q_t = q_freeze
        set_gains(kp, kv)
        for k, aid in enumerate(LEG_AID):
            d.ctrl[aid] = q_t[k]
        for aid in WH_AID:
            d.ctrl[aid] = 0.0
        mujoco.mj_step(m, d)
        w, x, y, z = d.qpos[3:7]
        roll = math.degrees(math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y)))
        pitch = math.degrees(math.asin(max(-1, min(1, 2 * (w * y - z * x)))))
        tilt = math.degrees(math.acos(max(-1.0, min(1.0, 1 - 2 * (x * x + y * y)))))
        q = np.array([d.qpos[a] for a in LEG_QADR])
        dq = np.array([d.qvel[a] for a in LEG_DADR])
        tau = np.array([d.qfrc_actuator[a] for a in LEG_AID])
        fn, nonwheel = wheel_forces()
        rows.append(dict(t=round(t, 3), group=group,
                         **{f"q_tgt_{n}": float(q_t[k]) for k, n in enumerate(MJ_LEGS)},
                         **{f"q_act_{n}": float(q[k]) for k, n in enumerate(MJ_LEGS)},
                         **{f"dq_{n}": float(dq[k]) for k, n in enumerate(MJ_LEGS)},
                         **{f"tau_{n}": float(tau[k]) for k, n in enumerate(MJ_LEGS)},
                         z=float(d.qpos[2]), roll=roll, pitch=pitch, tilt=tilt,
                         **{f"fn_{n}": float(fn[k]) for k, n in enumerate(WH_NAMES)},
                         support4=float((fn >= 3.0).all()), nonwheel=int(nonwheel),
                         kp=kp, kv=kv))
    return rows


def summarize(group, rows, switch_t=8.0):
    A = {k: np.array([r[k] for r in rows]) for k in rows[0] if k not in ("group",)}
    t = A["t"]
    pre = (t >= switch_t - 2.0) & (t < switch_t)
    post = t >= t[-1] - 2.0
    trans = t >= switch_t
    qcols = [f"q_act_{n}" for n in MJ_LEGS]
    q_pre = np.array([A[c][pre].mean() for c in qcols])
    q_post = np.array([A[c][post].mean() for c in qcols])
    q_diff = q_post - q_pre
    hip_idx = [MJ_LEGS.index(f"{l}_hip") for l in ("FL", "FR", "RL", "RR")]
    tgt = np.array([A[f"q_tgt_{n}"][post][0] for n in MJ_LEGS])
    pose_err_post = float(np.mean(np.abs(q_post - tgt)))
    pose_err_pre = float(np.mean(np.abs(q_pre - tgt)))
    # transition: max deviation from pre-switch baseline and recovery time
    q_bl = q_pre
    dev = np.max(np.abs(np.array([A[c] for c in qcols]).T - q_bl[None, :]), axis=1)
    max_dev = float(dev[trans].max())
    q_final = q_post
    rec = None
    for i in np.flatnonzero(trans):
        if np.all(np.abs(np.array([A[c][i] for c in qcols]) - q_final) < 0.02):
            rec = float(t[i] - switch_t)
            break
    z_pre, z_post = A["z"][pre].mean(), A["z"][post].mean()
    tau = np.array([[A[f"tau_{n}"][i] for n in MJ_LEGS] for i in range(len(t))])
    sat = (np.abs(tau) > 0.98 * LEG_LIM[None, :]).mean()
    fn = np.array([A[f"fn_{n}"] for n in WH_NAMES])
    return dict(group=group, switch_t=switch_t,
                q_pre={MJ_LEGS[i]: round(float(q_pre[i]), 4) for i in range(12)},
                q_post={MJ_LEGS[i]: round(float(q_post[i]), 4) for i in range(12)},
                q_diff={MJ_LEGS[i]: round(float(q_diff[i]), 4) for i in range(12)},
                hip_pre={l: round(float(q_pre[hip_idx[k]]), 4) for k, l in enumerate(("FL", "FR", "RL", "RR"))},
                hip_post={l: round(float(q_post[hip_idx[k]]), 4) for k, l in enumerate(("FL", "FR", "RL", "RR"))},
                hip_diff={l: round(float(q_diff[hip_idx[k]]), 4) for k, l in enumerate(("FL", "FR", "RL", "RR"))},
                pose_err_pre=round(pose_err_pre, 4), pose_err_post=round(pose_err_post, 4),
                z_pre=round(float(z_pre), 4), z_post=round(float(z_post), 4),
                z_drop_cm=round(float((z_pre - z_post) * 100), 2),
                pitch_pre=round(float(A["pitch"][pre].mean()), 3),
                pitch_post=round(float(A["pitch"][post].mean()), 3),
                pitch_delta=round(float(A["pitch"][post].mean() - A["pitch"][pre].mean()), 3),
                tilt_max_post=round(float(A["tilt"][post].max()), 2),
                support4_post=round(float(A["support4"][post].mean()), 3),
                nonwheel_post=int(A["nonwheel"][post].max()),
                tau_peak=round(float(np.abs(tau).max()), 2),
                tau_rms_pre=round(float(np.sqrt((tau[pre] ** 2).mean())), 2),
                tau_rms_post=round(float(np.sqrt((tau[post] ** 2).mean())), 2),
                sat_frac=round(float(sat), 5),
                max_transition_dev=round(max_dev, 4),
                recovery_s=round(rec, 3) if rec is not None else None,
                wheel_load_pre={n: round(float(fn[k][pre].mean()), 1) for k, n in enumerate(WH_NAMES)},
                wheel_load_post={n: round(float(fn[k][post].mean()), 1) for k, n in enumerate(WH_NAMES)})


summary = {}
for group in ("A_keep_target", "B_freeze_target"):
    rows = run(group)
    s = summarize(group, rows)
    summary[group] = s
    with open(os.path.join(OUT, f"{group}_200hz.csv"), "w", newline="", encoding="utf-8") as f:
        wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wr.writeheader()
        wr.writerows(rows)
    print(f"[{group}] hip_pre={s['hip_pre']} hip_post={s['hip_post']} hip_diff={s['hip_diff']} "
          f"pose_err {s['pose_err_pre']}->{s['pose_err_post']} z {s['z_pre']}->{s['z_post']} "
          f"(drop {s['z_drop_cm']}cm) pitch {s['pitch_pre']}->{s['pitch_post']} "
          f"sup4={s['support4_post']} nonwheel={s['nonwheel_post']} tau {s['tau_rms_pre']}->{s['tau_rms_post']} "
          f"sat={s['sat_frac']} maxdev={s['max_transition_dev']} rec={s['recovery_s']}s", flush=True)

meta = dict(run_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            script_sha256=hashlib.sha256(open(__file__, "rb").read()).hexdigest(),
            xml=XML, xml_sha256=hashlib.sha256(open(XML, "rb").read()).hexdigest(),
            model="as2w 26 kg, mu=0.35", T2_pose=T2, prone_pose=PRONE,
            prone_source="OG ai_damping measured prone pose (2026-11-19), hip mirrored",
            protocol="prone -> t2 over 3 s at 200/4, hold 5 s, switch to 55/2 at t=8 s, hold 10 s",
            groups={"A_keep_target": "target stays official t2", "B_freeze_target": "target frozen to actual q at switch"})
json.dump(dict(meta=meta, results=summary), open(os.path.join(OUT, "summary.json"), "w"), indent=2, ensure_ascii=False)
print("WROTE", OUT)
