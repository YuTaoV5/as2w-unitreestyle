﻿"""T12: official OG prone_to_stand order (hip first, then calf, then thigh) vs the current
simultaneous interpolation in MuJoCo; optional S2 with 300/6 in the hip phase only.

Official timeline (from LowCmd, 14.25 s start -> relative):
  H: 0.00-1.44 s  hip prone -> +-0.15   (kp200/kd4)
  hold 0.34 s
  K: 1.78-2.57 s  calf prone -> -1.20  (thigh still prone until 2.29 s)
  T: 2.29-2.58 s  thigh prone -> +0.60
  then FixedStand hold 10 s
MuJoCo only: 26 kg / mu=0.35 / 200 Hz / no robot / no publisher.
Outputs results/hip_first_standup/<case>_200hz.csv + summary.json + report.
"""
import csv
import hashlib
import json
import math
import os
import time

import numpy as np
import mujoco

W = "/root/as2w/mujoco-sim2sim-20261121"
os.chdir(W)
OUT = os.path.join(W, "results", "hip_first_standup")
os.makedirs(OUT, exist_ok=True)

T2 = {"hip": [0.15, -0.15, 0.15, -0.15], "thigh": 0.60, "calf": -1.20}
PRONE = {"hip": [-0.562, 0.562, -0.562, 0.562], "thigh": 1.019, "calf": -2.762}
MJ_LEGS = [f"{l}_{p}" for l in ("FL", "FR", "RL", "RR") for p in ("hip", "thigh", "calf")]
OFF_ORDER = ["FR", "FL", "RR", "RL"]
WH = ("FL_foot", "FR_foot", "RL_foot", "RR_foot")
LIM = np.array([{"hip": 60.0, "thigh": 60.0, "calf": 90.0}[n.split("_")[1]] for n in MJ_LEGS])


def q_of(pose):
    d = {}
    for i, name in enumerate(OFF_ORDER):
        d[f"{name}_hip"] = pose["hip"][i]
        d[f"{name}_thigh"] = pose["thigh"]
        d[f"{name}_calf"] = pose["calf"]
    return np.array([d[n] for n in MJ_LEGS])


Q_T2 = q_of(T2)
Q_PRONE = q_of(PRONE)
# official timeline (relative seconds)
H0, H1 = 0.00, 1.44
K0, K1 = 1.78, 2.57
T0, T1 = 2.29, 2.58
HOLD = 10.0


def blend(a, b, s):
    s = min(1.0, max(0.0, s))
    return a + s * (b - a)


def targets_official(t):
    hip = Q_PRONE[0::3].copy()
    thigh = PRONE["thigh"]
    calf = PRONE["calf"]
    if t >= H0:
        hip = blend(Q_PRONE[0::3], Q_T2[0::3], (t - H0) / (H1 - H0))
    if t >= K0:
        calf = blend(PRONE["calf"], T2["calf"], (t - K0) / (K1 - K0))
    if t >= T0:
        thigh = blend(PRONE["thigh"], T2["thigh"], (t - T0) / (T1 - T0))
    q = np.zeros(12)
    for k in range(4):
        q[3 * k] = hip[k]
        q[3 * k + 1] = thigh
        q[3 * k + 2] = calf
    return q, t


def build_matrix():
    return mujoco.MjModel.from_xml_path(os.path.join(W, "as2w_stand200.xml"))


class Sim:
    def __init__(self, xml):
        self.m = mujoco.MjModel.from_xml_path(xml)
        self.d = mujoco.MjData(self.m)
        self.leg_aid = [self.m.actuator(f"a_{n}").id for n in MJ_LEGS]
        self.wh_aid = [self.m.actuator(f"a_{n}").id for n in WH]
        self.leg_qadr = [self.m.jnt_qposadr[self.m.joint(n).id] for n in MJ_LEGS]
        self.wh_qadr = [self.m.jnt_qposadr[self.m.joint(n).id] for n in WH]
        self.leg_dadr = [self.m.jnt_dofadr[self.m.joint(n).id] for n in MJ_LEGS]
        self.wheel_geoms = []
        for n in WH:
            b = self.m.body(n).id
            self.wheel_geoms.append([g for g in range(self.m.ngeom)
                                     if self.m.geom_bodyid[g] == b and self.m.geom_contype[g] != 0][0])
        self.floor = int(self.m.geom("floor").id)

    def gains(self, kp, kv, wheel_kv=0.5):
        m = self.m
        for aid in self.leg_aid:
            m.actuator_gainprm[aid, 0] = kp
            m.actuator_biasprm[aid, 1] = -kp
            m.actuator_biasprm[aid, 2] = -kv
        for aid in self.wh_aid:
            m.actuator_gainprm[aid, 0] = wheel_kv
            m.actuator_biasprm[aid, 0] = 0.0
            m.actuator_biasprm[aid, 1] = 0.0
            m.actuator_biasprm[aid, 2] = -wheel_kv

    def contacts(self):
        fn = np.zeros(4)
        nonwheel = 0
        for i in range(self.d.ncon):
            c = self.d.contact[i]
            g1, g2 = int(c.geom1), int(c.geom2)
            if self.floor not in (g1, g2):
                continue
            other = g2 if g1 == self.floor else g1
            res = np.zeros(6)
            mujoco.mj_contactForce(self.m, self.d, i, res)
            if other in self.wheel_geoms:
                fn[self.wheel_geoms.index(other)] += abs(res[0])
            else:
                nonwheel += 1
        return fn, nonwheel

    def init_prone(self):
        m, d = self.m, self.d
        mujoco.mj_resetData(m, d)
        for k, a in enumerate(self.leg_qadr):
            d.qpos[a] = Q_PRONE[k]
        for a in self.wh_qadr:
            d.qpos[a] = 0.0
        d.qpos[0:2] = 0.0
        d.qpos[3:7] = [1.0, 0.0, 0.0, 0.0]

        def hit():
            for i in range(d.ncon):
                c = d.contact[i]
                g1, g2 = int(c.geom1), int(c.geom2)
                if self.floor in (g1, g2) and ((g2 if g1 == self.floor else g1) in self.wheel_geoms):
                    return True
            return False
        lo, hi = 0.02, 0.60
        for _ in range(40):
            mid = 0.5 * (lo + hi)
            d.qpos[2] = mid
            d.qvel[:] = 0
            mujoco.mj_forward(m, d)
            if hit():
                lo = mid
            else:
                hi = mid
        d.qpos[2] = hi + 1e-4
        mujoco.mj_forward(m, d)
        for _ in range(100):
            self.gains(200, 4)
            for k, aid in enumerate(self.leg_aid):
                d.ctrl[aid] = Q_PRONE[k]
            for aid in self.wh_aid:
                d.ctrl[aid] = 0.0
            mujoco.mj_step(m, d)


def schedule(case, t):
    """returns (q_target, kp, kv, phase)"""
    if case == "baseline_simul_200_4":
        if t < 3.0:
            return Q_PRONE + (t / 3.0) * (Q_T2 - Q_PRONE), 200.0, 4.0, "simul"
        return Q_T2.copy(), 200.0, 4.0, "hold"
    if case in ("S1_official_200_4", "S1_official_fl30"):
        q, _ = targets_official(t)
        ph = "H" if t < K0 else ("K" if t < T0 else ("T" if t < T1 else "hold"))
        return q, 200.0, 4.0, ph
    if case == "S2_H300_then200":
        q, _ = targets_official(t)
        if t < H1 + 0.34:
            return q, 300.0, 6.0, "H_high"
        ph = "K" if t < T0 else ("T" if t < T1 else "hold")
        return q, 200.0, 4.0, ph
    raise KeyError(case)


def run(case, xml, end_t=None):
    sim = Sim(xml)
    sim.init_prone()
    m, d = sim.m, sim.d
    dt = m.opt.timestep
    if end_t is None:
        end_t = (3.0 + HOLD) if case == "baseline_simul_200_4" else (T1 + HOLD)
    rows = []
    fall = False
    t_fall = None
    for i in range(int(round(end_t / dt))):
        t = i * dt
        q_t, kp, kv, ph = schedule(case, t)
        sim.gains(kp, kv)
        for k, aid in enumerate(sim.leg_aid):
            d.ctrl[aid] = q_t[k]
        for aid in sim.wh_aid:
            d.ctrl[aid] = 0.0
        mujoco.mj_step(m, d)
        w, x, y, z = d.qpos[3:7]
        roll = math.degrees(math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y)))
        pitch = math.degrees(math.asin(max(-1, min(1, 2 * (w * y - z * x)))))
        tilt = math.degrees(math.acos(max(-1.0, min(1.0, 1 - 2 * (x * x + y * y)))))
        q = np.array([d.qpos[a] for a in sim.leg_qadr])
        dq = np.array([d.qvel[a] for a in sim.leg_dadr])
        tau = np.array([d.qfrc_actuator[a] for a in sim.leg_aid])
        fn, nonwheel = sim.contacts()
        if not fall and t > 1.0 and (tilt > 70 or d.qpos[2] < 0.12):
            fall, t_fall = True, t
        rows.append(dict(t=round(t, 3), case=case, phase=ph,
                         **{f"q_tgt_{n}": float(q_t[k]) for k, n in enumerate(MJ_LEGS)},
                         **{f"q_act_{n}": float(q[k]) for k, n in enumerate(MJ_LEGS)},
                         **{f"tau_{n}": float(tau[k]) for k, n in enumerate(MJ_LEGS)},
                         z=float(d.qpos[2]), roll=roll, pitch=pitch, tilt=tilt,
                         **{f"fn_{n}": float(fn[k]) for k, n in enumerate(WH)},
                         support4=float((fn >= 3.0).all()), nonwheel=int(nonwheel),
                         kp=kp, kv=kv, fall=int(fall)))
    return rows


def summarize(case, rows):
    A = {k: np.array([r[k] for r in rows]) for k in rows[0] if k not in ("phase", "case")}
    t = A["t"]
    pre = t < 0.2
    tail = t >= t[-1] - 2.0
    qcols = [f"q_act_{n}" for n in MJ_LEGS]
    q_tcols = [f"q_tgt_{n}" for n in MJ_LEGS]
    q_pre = np.array([A[c][pre].mean() for c in qcols])
    q_fin = np.array([A[c][tail].mean() for c in qcols])
    q_tgt = np.array([A[c][tail].mean() for c in q_tcols])
    hip_idx = [MJ_LEGS.index(f"{l}_hip") for l in ("FL", "FR", "RL", "RR")]
    tgt_v = np.array([A[f"q_tgt_{n}"][tail].mean() for n in MJ_LEGS])
    dev = np.max(np.abs(np.array([A[c] for c in qcols]).T - q_fin[None, :]), axis=1)
    max_dev = float(dev.max())
    rec = None
    for i in range(len(t)):
        if np.all(np.abs(np.array([A[c][i] for c in qcols]) - q_fin) < 0.02):
            rec = float(t[i])
            break
    tau = np.array([[A[f"tau_{n}"][i] for n in MJ_LEGS] for i in range(len(t))])
    return dict(case=case, fall=bool(A["fall"].any()),
                n_steps=len(t), duration_s=round(float(t[-1]), 2),
                hip_final={l: round(float(q_fin[hip_idx[k]]), 4) for k, l in enumerate(("FL", "FR", "RL", "RR"))},
                hip_target_err={l: round(float(q_tgt[hip_idx[k]] - q_fin[hip_idx[k]]), 4) for k, l in enumerate(("FL", "FR", "RL", "RR"))},
                calf_final={l: round(float(q_fin[MJ_LEGS.index(f"{l}_calf")]), 4) for l in ("FL", "FR", "RL", "RR")},
                calf_target_err={l: round(float(q_tgt[MJ_LEGS.index(f"{l}_calf")] - q_fin[MJ_LEGS.index(f"{l}_calf")]), 4) for l in ("FL", "FR", "RL", "RR")},
                thigh_final={l: round(float(q_fin[MJ_LEGS.index(f"{l}_thigh")]), 4) for l in ("FL", "FR", "RL", "RR")},
                pose_err_final=round(float(np.mean(np.abs(q_fin - tgt_v))), 4),
                z_final=round(float(A["z"][tail].mean()), 4), z_min=round(float(A["z"].min()), 4),
                tilt_max=round(float(A["tilt"].max()), 2),
                support4_final=round(float(A["support4"][tail].mean()), 3),
                nonwheel_max=int(A["nonwheel"].max()),
                tau_peak=round(float(np.abs(tau).max()), 2),
                tau_rms_final=round(float(np.sqrt((tau[tail] ** 2).mean())), 2),
                sat_frac=round(float((np.abs(tau) > 0.98 * LIM[None, :]).mean()), 5),
                max_dev_from_final=round(max_dev, 4),
                settle_time_s=round(rec, 3) if rec is not None else None)


CASES = [
    ("baseline_simul_200_4", "as2w_stand200.xml"),
    ("S1_official_200_4", "as2w_stand200.xml"),
    ("S2_H300_then200", "as2w_stand200.xml"),
    ("S1_official_fl30", "as2w_stand200_fl30.xml"),   # stiction-proxy diagnostic arm
]
results = {}
meta = dict(run_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            script_sha256=hashlib.sha256(open(__file__, "rb").read()).hexdigest(),
            official_timeline_s=dict(H=[H0, H1], K=[K0, K1], T=[T0, T1], hold=HOLD),
            T2_pose=T2, prone_pose=PRONE,
            prone_source="OG ai_damping measured prone pose (2026-11-19), hip mirrored",
            note="official order from LowCmd parse (14.25 s start): hip 1.44s, calf 1.78-2.57s, thigh 2.29-2.58s")
for case, xml in CASES:
    t0 = time.time()
    rows = run(case, os.path.join(W, xml))
    s = summarize(case, rows)
    s["xml"] = xml
    s["wall_s"] = round(time.time() - t0, 2)
    results[case] = s
    with open(os.path.join(OUT, f"{case}_200hz.csv"), "w", newline="", encoding="utf-8") as f:
        wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wr.writeheader()
        wr.writerows(rows)
    print(f"[{case}] fall={s['fall']} hip={s['hip_final']} hip_err={s['hip_target_err']} "
          f"calf={s['calf_final']} pose={s['pose_err_final']} z={s['z_final']} "
          f"tilt_max={s['tilt_max']} sup4={s['support4_final']} tau_peak={s['tau_peak']} "
          f"sat={s['sat_frac']} maxdev={s['max_dev_from_final']} settle={s['settle_time_s']}", flush=True)
json.dump(dict(meta=meta, results=results), open(os.path.join(OUT, "summary.json"), "w"), indent=2, ensure_ascii=False)
print("WROTE", OUT)
