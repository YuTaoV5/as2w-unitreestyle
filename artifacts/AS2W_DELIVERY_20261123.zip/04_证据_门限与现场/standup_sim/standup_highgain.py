﻿"""T10: high kp/kd stand-up -> interpolate back to official FixedStand pose (MuJoCo only).

Model: as2w MuJoCo asset (26 kg, mu=0.35, kp/kv set at runtime to match the official
firmware 200/4; wheels velocity servo kp0/kd0.5). No policy, no publisher, no robot.

Initial pose: official ai_damping prone pose measured in the 2026-11-19 OG session
(QC_SUMMARY: FR hip -0.562, thigh 1.019, calf -2.762), mirrored for the other legs;
base z solved so all four wheels just touch the ground.

Cases (all 13 s, 200 Hz):
  baseline_200_4    : 200/4, target prone -> t2 over 3 s, hold 10 s
  H1_300_6 / H1_400_8: 300/6 / 400/8, same 3 s rise, hold 10 s
  H2_400_8_to_200_4 : 400/8 prone -> q_mid over 1.5 s, then q_mid -> t2 over 2 s while
                      gains ramp down to 200/4, hold 9.5 s
  H2_300_6_to_200_4 : same with 300/6

Outputs: results/standup_highgain/<case>_200hz.csv, summary.json; STANDUP_HIGHGAIN_SIM_REPORT.md
"""
import argparse
import csv
import hashlib
import json
import math
import os
import time

import numpy as np
import mujoco

import argparse
_ap = argparse.ArgumentParser()
_ap.add_argument("--xml", default="")
_ap.add_argument("--outdir", default="results/standup_highgain")
_ap.add_argument("--cases", default="")
_args = _ap.parse_args()

W = "/root/as2w/mujoco-sim2sim-20261121"
os.chdir(W)
OUT = os.path.join(W, _args.outdir)
os.makedirs(OUT, exist_ok=True)

# official FixedStand t2 (firmware units, FR/FL/RR/RL order, part-major)
T2 = {"hip": [0.15, -0.15, 0.15, -0.15], "thigh": 0.60, "calf": -1.20}
# official ai_damping prone (FR measured; mirrored hip sign for FL/RL)
PRONE = {"hip": [-0.562, 0.562, -0.562, 0.562], "thigh": 1.019, "calf": -2.762}
# official ai measured hip actual under FixedStand (real robot, OG session e_q)
OFFICIAL_HIP = {"FR": 0.1213, "FL": -0.1285, "RR": 0.1279, "RL": -0.1205}

# MuJoCo leg order: FL,FR,RL,RR ; map official FR/FL/RR/RL
MJ_LEGS = [f"{l}_{p}" for l in ("FL", "FR", "RL", "RR") for p in ("hip", "thigh", "calf")]
OFF_ORDER = ["FR", "FL", "RR", "RL"]


def off_to_mj(vec_off):
    """reorder [FR hip,FR thigh,FR calf, FL..., RR..., RL...] -> MJ_LEGS order."""
    d = {}
    for i, name in enumerate(OFF_ORDER):
        d[f"{name}_hip"] = vec_off[3 * i]
        d[f"{name}_thigh"] = vec_off[3 * i + 1]
        d[f"{name}_calf"] = vec_off[3 * i + 2]
    return np.array([d[n] for n in MJ_LEGS])


def q_of(pose):
    v = []
    for i, name in enumerate(OFF_ORDER):
        j = {"FR": 0, "FL": 1, "RR": 2, "RL": 3}[name]
        v += [pose["hip"][j], pose["thigh"], pose["calf"]]
    return off_to_mj(np.array(v))


Q_T2 = q_of(T2)
Q_PRONE = q_of(PRONE)


def build_model():
    xml = os.path.join(W, "as2w_stand200.xml")
    if not os.path.isfile(xml):
        import subprocess
        subprocess.run(["/root/as2w/preflight/isaac-python",
                        "build_mjcf.py", "--base", "isaac26", "--mu", "0.35",
                        "--kp", "200", "--kd", "4", "--out", xml], check=True)
    return xml


XML = _args.xml if _args.xml else build_model()
XML = os.path.join(W, XML) if not os.path.isabs(XML) else XML
m = mujoco.MjModel.from_xml_path(XML)
d = mujoco.MjData(m)
LEG_AID = [m.actuator(f"a_{n}").id for n in MJ_LEGS]
WH_AID = [m.actuator(f"a_{n}").id for n in ("FL_foot", "FR_foot", "RL_foot", "RR_foot")]
LEG_QADR = [m.jnt_qposadr[m.joint(n).id] for n in MJ_LEGS]
WH_QADR = [m.jnt_qposadr[m.joint(n).id] for n in ("FL_foot", "FR_foot", "RL_foot", "RR_foot")]
LEG_DADR = [m.jnt_dofadr[m.joint(n).id] for n in MJ_LEGS]
LIM = {"hip": 60.0, "thigh": 60.0, "calf": 90.0}
LEG_LIM = np.array([LIM[n.split("_")[1]] for n in MJ_LEGS])
WHEEL_LIM = 15.0
WHEEL_GEOMS = []
for n in ("FL_foot", "FR_foot", "RL_foot", "RR_foot"):
    b = m.body(n).id
    WHEEL_GEOMS.append([g for g in range(m.ngeom) if m.geom_bodyid[g] == b and m.geom_contype[g] != 0][0])
try:
    FLOOR_GID = int(m.geom("floor").id)
except Exception:
    FLOOR_GID = int([g for g in range(m.ngeom) if m.geom_type[g] == mujoco.mjtGeom.mjGEOM_PLANE][0])


def set_gains(kp, kv, wheel_kv=0.5):
    """runtime implicit-PD gains: position actuator gainprm[0]=kp, biasprm[1]=-kp,
    biasprm[2]=-kv; velocity actuator gainprm[0]=kv, biasprm[2]=-kv."""
    for aid in LEG_AID:
        m.actuator_gainprm[aid, 0] = kp
        m.actuator_biasprm[aid, 1] = -kp      # position actuator: biasprm[1] = -kp
        m.actuator_biasprm[aid, 2] = -kv      # biasprm[2] = -kv
    for aid in WH_AID:
        m.actuator_gainprm[aid, 0] = wheel_kv  # velocity actuator: gainprm[0]=kv, biasprm[2]=-kv
        m.actuator_biasprm[aid, 0] = 0.0
        m.actuator_biasprm[aid, 1] = 0.0
        m.actuator_biasprm[aid, 2] = -wheel_kv


def wheel_contacts():
    """(n_wheel_contacts, n_nonwheel_contacts_with_floor, per-wheel normal forces)"""
    fn = np.zeros(4)
    nonwheel = 0
    for i in range(d.ncon):
        c = d.contact[i]
        g1, g2 = int(c.geom1), int(c.geom2)
        if FLOOR_GID not in (g1, g2):
            continue
        other = g2 if g1 == FLOOR_GID else g1
        res = np.zeros(6)
        mujoco.mj_contactForce(m, d, i, res)
        if other in WHEEL_GEOMS:
            fn[WHEEL_GEOMS.index(other)] += abs(res[0])
        else:
            nonwheel += 1
    return fn, nonwheel


def init_state():
    mujoco.mj_resetData(m, d)
    for k, a in enumerate(LEG_QADR):
        d.qpos[a] = Q_PRONE[k]
    for a in WH_QADR:
        d.qpos[a] = 0.0
    d.qpos[0:2] = [0.0, 0.0]
    d.qpos[3:7] = [1.0, 0.0, 0.0, 0.0]
    # solve base z so that the first wheel-floor contact just appears (contact-based)
    def wheel_hit():
        for i in range(d.ncon):
            c = d.contact[i]
            g1, g2 = int(c.geom1), int(c.geom2)
            if FLOOR_GID in (g1, g2) and ((g2 if g1 == FLOOR_GID else g1) in WHEEL_GEOMS):
                return True
        return False
    lo, hi = 0.02, 0.60
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        d.qpos[2] = mid
        d.qvel[:] = 0
        mujoco.mj_forward(m, d)
        if wheel_hit():
            lo = mid
        else:
            hi = mid
    d.qpos[2] = hi + 1e-4
    mujoco.mj_forward(m, d)


def run_case(name, profile, seed=42, record=True):
    """profile(t) -> (q_target_mj, kp, kv)"""
    init_state()
    np.random.seed(seed)
    # tiny settle: hold prone target with the case's initial gains for 0.2 s
    q0, kp0, kv0 = profile(0.0)
    set_gains(kp0, kv0)
    for _ in range(100):
        for k, aid in enumerate(LEG_AID):
            d.ctrl[aid] = q0[k]
        for aid in WH_AID:
            d.ctrl[aid] = 0.0
        mujoco.mj_step(m, d)
    t = 0.0
    dt = m.opt.timestep
    rows = []
    fall = False
    t_fall = None
    T = 13.0
    nsteps = int(round(T / dt))
    for i in range(nsteps):
        t = i * dt
        q_t, kp, kv = profile(t)
        set_gains(kp, kv)
        for k, aid in enumerate(LEG_AID):
            d.ctrl[aid] = q_t[k]
        for aid in WH_AID:
            d.ctrl[aid] = 0.0
        mujoco.mj_step(m, d)
        w, x, y, z = d.qpos[3:7]
        # body tilt from quat
        roll = math.degrees(math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y)))
        pitch = math.degrees(math.asin(max(-1, min(1, 2 * (w * y - z * x)))))
        cos_tilt = 1 - 2 * (x * x + y * y)      # world z of body z axis
        tilt = math.degrees(math.acos(max(-1.0, min(1.0, cos_tilt))))
        q = np.array([d.qpos[a] for a in LEG_QADR])
        dq = np.array([d.qvel[a] for a in LEG_DADR])
        tau = np.array([d.qfrc_actuator[a] for a in LEG_AID])
        fn, nonwheel = wheel_contacts()
        hip_err = np.array([q[k] - Q_T2[k] for k in range(0, 12, 3)])
        pose_err = float(np.mean(np.abs(q - q_t)))
        if not fall and t > 2.0 and (tilt > 70.0 or d.qpos[2] < 0.15):
            fall = True
            t_fall = t
        if record:
            rows.append(dict(t=round(t, 3), case=name,
                             **{f"q_tgt_{n}": float(q_t[k]) for k, n in enumerate(MJ_LEGS)},
                             **{f"q_act_{n}": float(q[k]) for k, n in enumerate(MJ_LEGS)},
                             **{f"hip_err_{n}": float(hip_err[k // 3]) for k, n in enumerate(MJ_LEGS) if n.endswith("_hip")},
                             z=float(d.qpos[2]), roll=roll, pitch=pitch, tilt=tilt,
                             pose_err=pose_err,
                             **{f"tau_{n}": float(tau[k]) for k, n in enumerate(MJ_LEGS)},
                             **{f"fn_{n}": float(fn[k]) for k, n in enumerate(("FL_foot", "FR_foot", "RL_foot", "RR_foot"))},
                             support4=float((fn >= 3.0).all()), nonwheel_contacts=int(nonwheel),
                             kp=kp, kv=kv, fall=int(fall)))
        if fall:
            break
    arr = rows
    return dict(name=name, rows=arr, fall=fall, t_fall=t_fall,
                z0=(arr[0]["z"] if arr else None), ncon0=0)


def make_profile_baseline(kp, kv, rise=3.0):
    def f(t):
        a = min(1.0, t / rise)
        q = Q_PRONE + a * (Q_T2 - Q_PRONE)
        return q, kp, kv
    return f


def make_profile_h2(kp_hi, kv_hi, kp_lo=200.0, kv_lo=4.0, rise=1.5, blend=2.0, mid_frac=0.6):
    q_mid = Q_PRONE + mid_frac * (Q_T2 - Q_PRONE)

    def f(t):
        if t < rise:
            a = t / rise
            return Q_PRONE + a * (q_mid - Q_PRONE), kp_hi, kv_hi
        if t < rise + blend:
            a = (t - rise) / blend
            kp = kp_hi + a * (kp_lo - kp_hi)
            kv = kv_hi + a * (kv_lo - kv_hi)
            return q_mid + a * (Q_T2 - q_mid), kp, kv
        return Q_T2, kp_lo, kv_lo
    return f


CASES = {
    "baseline_200_4": make_profile_baseline(200, 4),
    "H1_300_6": make_profile_baseline(300, 6),
    "H1_400_8": make_profile_baseline(400, 8),
    "H2_400_8_to_200_4": make_profile_h2(400, 8),
    "H2_300_6_to_200_4": make_profile_h2(300, 6),
}


def summarize(case):
    rows = case["rows"]
    if not rows:
        return dict(case=case["name"], error="no rows")
    n = len(rows)
    tlast = [r for r in rows if r["t"] >= rows[-1]["t"] - 2.0]
    hips = {k: round(float(np.mean([r[f"q_act_{k}_hip"] for r in tlast])), 4) for k in ("FL", "FR", "RL", "RR")}
    hip_err = {k: round(float(np.mean([abs(r[f"q_tgt_{k}_hip"] - r[f"q_act_{k}_hip"]) for r in tlast])), 4) for k in ("FL", "FR", "RL", "RR")}
    z = [r["z"] for r in rows]
    tau = np.array([[r[f"tau_{n}"] for n in MJ_LEGS] for r in rows])
    sat = (np.abs(tau) > 0.98 * LEG_LIM[None, :]).mean()
    nonwheel = [r["nonwheel_contacts"] for r in tlast]
    return dict(case=case["name"], n_steps=n, fall=case["fall"], t_fall=case["t_fall"],
                final_hip=hips,
                final_hip_target_err=hip_err,
                official_hip={k: OFFICIAL_HIP[k] for k in ("FR", "FL", "RR", "RL")},
                hip_vs_official={k: round(hips[k] - OFFICIAL_HIP[k], 4) for k in hips},
                final_pose_err=round(float(np.mean([r["pose_err"] for r in tlast])), 4),
                final_z=round(float(np.mean(z[-400:])), 4), z_min=round(float(np.min(z)), 4),
                tilt_max=round(float(max(r["tilt"] for r in rows)), 2),
                support4_final=round(float(np.mean([r["support4"] for r in tlast])), 3),
                nonwheel_contacts_final=int(max(nonwheel)),
                tau_peak=round(float(np.abs(tau).max()), 2),
                tau_rms=round(float(np.sqrt((tau ** 2).mean())), 2),
                sat_frac=round(float(sat), 5),
                hip_tau_final={k: round(float(np.mean([r[f"tau_{k}_hip"] for r in tlast])), 2) for k in ("FL", "FR", "RL", "RR")},
                wheel_load_final={n: round(float(np.mean([r[f"fn_{n}"] for r in tlast])), 1) for n in ("FL_foot", "FR_foot", "RL_foot", "RR_foot")})


results = {}
_keep = set(_args.cases.split(",")) if _args.cases else set(CASES)
for name, prof in CASES.items():
    if name not in _keep:
        continue
    t0 = time.time()
    r = run_case(name, prof)
    s = summarize(r)
    s["wall_s"] = round(time.time() - t0, 2)
    results[name] = s
    if r["rows"]:
        cols = list(r["rows"][0].keys())
        with open(os.path.join(OUT, f"{name}_200hz.csv"), "w", newline="", encoding="utf-8") as f:
            wr = csv.DictWriter(f, fieldnames=cols)
            wr.writeheader()
            wr.writerows(r["rows"])
        print(f"[{name}] steps={s['n_steps']} fall={s['fall']} final_hip={s['final_hip']} "
              f"pose_err={s['final_pose_err']} z={s['final_z']} sup4={s['support4_final']} "
              f"sat={s['sat_frac']} wall={s['wall_s']}s", flush=True)
    else:
        print(f"[{name}] FAILED/empty", flush=True)

meta = dict(run_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            script_sha256=hashlib.sha256(open(__file__, "rb").read()).hexdigest(),
            xml=XML, xml_sha256=hashlib.sha256(open(XML, "rb").read()).hexdigest(),
            model_base="as2w 26 kg (isaac26) mu=0.35", T2_pose=T2, prone_pose=PRONE,
            prone_source="official ai_damping prone pose measured 2026-11-19 OG session "
                         "(QC_SUMMARY: FR -0.562/1.019/-2.762), hip mirrored",
            official_hip=OFFICIAL_HIP, cases=list(CASES), record_hz=1 / 0.005)
json.dump(dict(meta=meta, results=results), open(os.path.join(OUT, "summary.json"), "w"), indent=2, ensure_ascii=False)
print(json.dumps(results, indent=1))
print("WROTE", OUT)
