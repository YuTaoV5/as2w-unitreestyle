# T8 时延证据 corrigendum（2026-11-23 11:00）

> 目的：修正 `EXTENDED_REPLAY_REPORT.md` 中 B/C 时延数字的来源标注；**不改变结论**：controller-only 贴边、DDS/publisher 50Hz 未测，不能判 50Hz PASS，不发布。

## 1. 原始文件
- `wallclock_frames.csv`
  - 600 帧，`run_wallclock3`，2026-11-23 10:54:39（CPRO ARM64）
  - SHA256 **`0B9B0CC53AA7A87A318953DB4AB14525D0BA38A726F554152E94696733AE30E7`**
  - 11650 B
- 复算（numpy）：
  - step：p50 **283.75 µs**、p95 **352.70 µs**、max **590.47 µs**、>20 ms **0**
  - period：p50 **19.968 ms**、p95 **20.028 ms**、max **21.009 ms**、>20 ms **83/600（13.8%）**

## 2. 报告 B/C 与原始文件的差异
- 报告 B：step p50 287.5 µs、p95 360.5、max 1130.6；来源 `timing/lead_measurements.json`（自称 lead message 10:56，**外部补充，不是原始件**）。
- 报告 C：controller-only p50 19.995 ms、p95 20.055、max 20.94、>20 ms **235/600**；同一外部补充件。
- 原始 CSV 是同任务另一次 run：step max 590.47、period max 21.009、>20 ms **83/600**。
- 结论：**存在两次不同 run，run-to-run 波动大**；两者都是 controller-only，不含 DDS/publisher；不得用任一作 50Hz 发布证据。

## 3. 结论
- 50 Hz 只能表述为“**controller-only 边缘 + DDS/publisher 未测缺口**”，**不能 PASS**。
- 全 FSM/DDS LowCmd 仍仅 2 帧 audit；发布仍锁定。
- 未启动 publisher、未发 LowCmd、未切包。
