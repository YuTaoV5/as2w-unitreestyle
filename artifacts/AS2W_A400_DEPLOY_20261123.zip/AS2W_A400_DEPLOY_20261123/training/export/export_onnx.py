#!/usr/bin/env python3
"""Export a v4.x wheel-differential candidate checkpoint (obs58 -> action12) to ONNX.

Contract (matches /root/as2w/retrain-wheeldiff-v41-20261121/src/environment.py):
  * actor = 512-256-128 ELU MLP, input obs[1,58], output action[1,12]
  * training squashes the raw mean with tanh, then legs use 0.25*tanh(a) offset
  * default mode bakes tanh into the graph (deploy action_clip = 1.0 is the identity),
    exactly like the previous unitree58-v2step delivery; use --no-tanh for the raw model.
  * wheels are NOT network outputs; the deployment controller derives the wheel
    target from (vx,wz) with B=0.44 / eta=0.415 / clamp 12 (see parity_v4x.py).

Usage:
  python export_onnx.py <ckpt.pt> <out.onnx> [--no-tanh] [--obs 58] [--act 12]
Outputs: <out.onnx> plus <out>.export.json (ckpt/onnx sha256, shapes, tanh baked,
torch-vs-onnxruntime max abs error). CPU only; no GPU needed.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import torch


class Actor(torch.nn.Module):
    def __init__(self, obs=58, act=12, squash=True):
        super().__init__()
        self.squash = squash
        self.mlp = torch.nn.Sequential(
            torch.nn.Linear(obs, 512), torch.nn.ELU(),
            torch.nn.Linear(512, 256), torch.nn.ELU(),
            torch.nn.Linear(256, 128), torch.nn.ELU(),
            torch.nn.Linear(128, act),
        )

    def forward(self, obs):
        out = self.mlp(obs)
        return torch.tanh(out) if self.squash else out


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("ckpt", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--obs", type=int, default=58)
    ap.add_argument("--act", type=int, default=12)
    ap.add_argument("--no-tanh", action="store_true", help="export the raw mean (no tanh)")
    ap.add_argument("--parity-samples", type=int, default=50)
    ap.add_argument("--parity-limit", type=float, default=2e-5)
    args = ap.parse_args()

    blob = torch.load(args.ckpt, map_location="cpu", weights_only=False)
    if not isinstance(blob, dict) or "actor_state_dict" not in blob:
        raise SystemExit(f"{args.ckpt}: expected an rsl_rl checkpoint with actor_state_dict")
    sd = blob["actor_state_dict"]
    missing = [k for k in ("mlp.0.weight", "mlp.2.weight", "mlp.4.weight", "mlp.6.weight") if k not in sd]
    if missing:
        raise SystemExit(f"{args.ckpt}: missing actor keys {missing}")
    in_shape = tuple(sd["mlp.0.weight"].shape)
    out_shape = tuple(sd["mlp.6.weight"].shape)
    if in_shape[1] != args.obs or out_shape[0] != args.act:
        raise SystemExit(f"checkpoint MLP is {in_shape}->{out_shape}, expected obs {args.obs} act {args.act}")

    squash = not args.no_tanh
    model = Actor(args.obs, args.act, squash=squash)
    model.load_state_dict({k: v for k, v in sd.items() if k.startswith("mlp.")}, strict=True)
    model.eval()

    args.out.parent.mkdir(parents=True, exist_ok=True)
    dummy = torch.zeros(1, args.obs)
    torch.onnx.export(
        model, dummy, str(args.out),
        input_names=["obs"], output_names=["act"],
        dynamic_axes={"obs": {0: "batch"}, "act": {0: "batch"}},
        opset_version=17, dynamo=False,
    )

    import onnxruntime as ort
    sess = ort.InferenceSession(str(args.out), providers=["CPUExecutionProvider"])
    inp, out = sess.get_inputs()[0], sess.get_outputs()[0]
    rng = np.random.default_rng(20261121)
    worst = 0.0
    for _ in range(args.parity_samples):
        x = rng.normal(0, 0.5, size=(1, args.obs)).astype("float32")
        with torch.no_grad():
            ref = model(torch.from_numpy(x)).numpy()
        got = sess.run(None, {inp.name: x})[0]
        worst = max(worst, float(np.abs(ref - got).max()))
    if worst > args.parity_limit:
        raise SystemExit(f"torch<->onnxruntime parity failed: max_abs_err={worst:.3e}")

    report = {
        "ckpt": str(args.ckpt),
        "ckpt_sha256": sha256(args.ckpt),
        "ckpt_iter": int(blob.get("iter", -1)) if blob.get("iter") is not None else None,
        "onnx": str(args.out),
        "onnx_sha256": sha256(args.out),
        "onnx_bytes": args.out.stat().st_size,
        "obs_dim": args.obs,
        "act_dim": args.act,
        "input": [inp.name, inp.shape, inp.type],
        "output": [out.name, out.shape, out.type],
        "opset": 17,
        "tanh_baked": squash,
        "torch_ort_max_abs_err": worst,
        "parity_limit": args.parity_limit,
        "deploy_note": ("graph outputs tanh(raw) in (-1,1); set action_clip=1.0 so the "
                        "deployment clamp is the identity") if squash else
                       ("graph outputs the raw mean; the deployment controller must apply tanh"),
        "wheel_contract": {"mode": "vx_wz_differential", "track_width_m": 0.44,
                           "yaw_efficiency": 0.415, "wheel_rate_clamp": 12.0,
                           "radius_m": 0.086},
        "action_contract": {"leg_action_scale_rad": 0.25,
                            "leg_target_cutoff_hz": 5.0, "wheel_target_cutoff_hz": 5.0,
                            "obs_height_m": 0.45},
    }
    args.out.with_suffix(".export.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: report[k] for k in ("ckpt_sha256", "onnx_sha256", "onnx_bytes",
                                            "tanh_baked", "torch_ort_max_abs_err")}, indent=2))


if __name__ == "__main__":
    main()
