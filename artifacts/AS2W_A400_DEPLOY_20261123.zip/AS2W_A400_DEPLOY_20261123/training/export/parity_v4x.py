#!/usr/bin/env python3
"""v4.x deployment parity: Python training-reference vs ONNX vs (future) C++ replay.

The Python side reproduces, from an evaluate.py sensor tape, exactly what the
training environment did for the v4.x contract:
  obs(58) = command(3) + body_ang_vel(3) + projected_gravity(3)
            + (q - default)(16, wheels zeroed) + dq*0.05(16)
            + prev_target(16: leg/0.25, wheel/12) + HEIGHT(1)
  action:  target_leg <- lerp(target_leg, 0.25*tanh(a), alpha_leg)
           alpha_leg = -expm1(-2*pi*5*dt) = 0.4665119
  wheels:  base = vx/R ; yaw = wz*(B/2)/(R*eta) ; FL/RL = base-yaw ; FR/RR = base+yaw ;
           target_wheel <- lerp(target_wheel, clamp(+-12), alpha_wheel) ;
           zero snap only when vx==0 and wz==0 and |target|<0.02
  B=0.44, eta=0.415, R=0.086, HEIGHT=0.45 (official stance contact ~ -0.448).

C++ side (when a v4.x replay binary exists) must print the existing unitree58
replay format, which this script already parses:
    UNITREE58_OBS,<elapsed>,<obs 0..57>
    UNITREE58_TARGET,<elapsed>,<action 0..11>,<leg q 0..11>,<wheel dq 12..15>
Until then the script runs the pure-Python self-checks (obs reproduction from the
tape, ONNX action/target recursion) and --emit-fixture writes the sensor fixture
the future C++ replay binary consumes:
    elapsed quat_wxyz gyro q(16 policy order) dq(16) vx vy wz      (one row/frame)

Usage:
  python parity_v4x.py --tape flat-sensor-tape.npz --onnx policy.onnx \
      [--cpp-replay replay_out.txt] [--deploy-yaml deploy-v4x.draft.yaml] \
      [--report parity.json] [--emit-fixture fixture.txt] [--max-frames 300]
Exit code 0 only if every requested comparison passes (default limit 2e-5).
"""
import argparse
import json
from pathlib import Path

import numpy as np

RADIUS = 0.086
TRACK_WIDTH = 0.44
YAW_EFF = 0.415
WHEEL_LIMIT = 12.0
HEIGHT = 0.45
LEG_SCALE = 0.25
LEG_CUTOFF_HZ = 5.0
WHEEL_CUTOFF_HZ = 5.0
DT = 0.02
# policy joint order = training order: legs FL,FR,RL,RR (hip,thigh,calf) then wheels
DEFAULT_STANCE = np.array(
    [-0.15, 0.60, -1.20, 0.15, 0.60, -1.20, -0.15, 0.60, -1.20, 0.15, 0.60, -1.20,
     0.0, 0.0, 0.0, 0.0], dtype=np.float64)
SIDE = np.array([-1.0, 1.0, -1.0, 1.0])  # FL,FR,RL,RR: left = base - yaw


def alpha(cutoff_hz):
    return 1.0 - np.exp(-2.0 * np.pi * cutoff_hz * DT)


def projected_gravity(quat_wxyz):
    w, x, y, z = quat_wxyz
    return np.array([2.0 * (w * y - x * z), -2.0 * (w * x + y * z),
                     -1.0 + 2.0 * (x * x + y * y)])


def build_obs(command, gyro, quat, q, dq, target, defaults=DEFAULT_STANCE, height=HEIGHT):
    """Reproduce environment.py::_frame for one frame (numpy, float64)."""
    obs = np.empty(58, dtype=np.float64)
    obs[0:3] = command
    obs[3:6] = gyro
    obs[6:9] = projected_gravity(quat)
    offset = np.array(q, dtype=np.float64) - defaults
    offset[12:] = 0.0
    obs[9:25] = offset
    obs[25:41] = np.array(dq, dtype=np.float64) * 0.05
    obs[41:53] = np.array(target, dtype=np.float64)[:12] / LEG_SCALE
    obs[53:57] = np.array(target, dtype=np.float64)[12:] / WHEEL_LIMIT
    obs[57] = height
    return obs


def wheel_target(command):
    base = command[0] / RADIUS
    yaw = command[2] * (TRACK_WIDTH * 0.5) / (RADIUS * YAW_EFF)
    wheel = base + SIDE * yaw
    return np.clip(wheel, -WHEEL_LIMIT, WHEEL_LIMIT)


def step_targets(command, action, target, tanh_baked=False):
    """One env step: filtered leg target + differential wheel target + zero snap.

    `action` is what the deployment graph outputs. With a tanh-baked ONNX graph the
    network mean is already squashed (do NOT tanh again here); with a raw-mean
    graph the controller must apply tanh exactly like the training env.
    """
    new_target = np.array(target, dtype=np.float64)
    a = np.asarray(action, dtype=np.float64) if tanh_baked else np.tanh(np.clip(action, -6.0, 6.0))
    new_target[:12] += (a * LEG_SCALE - new_target[:12]) * alpha(LEG_CUTOFF_HZ)
    wheel = wheel_target(command)
    new_target[12:] += (wheel - new_target[12:]) * alpha(WHEEL_CUTOFF_HZ)
    still = abs(command[0]) < 1e-9 and abs(command[2]) < 1e-9
    new_target[12:] = np.where(still & (np.abs(new_target[12:]) < 0.02), 0.0, new_target[12:])
    return new_target


def event_trial(tape, label, index=0):
    labels = tape["labels"]
    frames = np.flatnonzero(labels == label)
    if len(frames) == 0:
        raise SystemExit(f"label {label!r} missing from tape")
    return int(frames[index])


def parse_cpp_replay(path):
    observations, targets = [], []
    for line in Path(path).read_text(errors="replace").splitlines():
        fields = line.strip().split(",")
        if not fields:
            continue
        if fields[0] == "UNITREE58_OBS" and len(fields) >= 60:
            observations.append([float(v) for v in fields[2:60]])
        elif fields[0] == "UNITREE58_TARGET" and len(fields) >= 30:
            targets.append([float(v) for v in fields[2:]])
    return np.asarray(observations), np.asarray(targets)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tape", type=Path, required=True, help="flat-sensor-tape.npz from evaluate.py")
    ap.add_argument("--onnx", type=Path, required=True)
    ap.add_argument("--cpp-replay", type=Path, default=None,
                    help="optional C++ replay output (UNITREE58_OBS/TARGET lines)")
    ap.add_argument("--label", default="forward", help="tape label used for the parity segment")
    ap.add_argument("--trial", type=int, default=0)
    ap.add_argument("--max-frames", type=int, default=300)
    ap.add_argument("--limit", type=float, default=2e-5)
    ap.add_argument("--report", type=Path, default=None)
    ap.add_argument("--emit-fixture", type=Path, default=None,
                    help="write the C++ replay fixture (one row per frame)")
    ap.add_argument("--skip-tape-checks", action="store_true",
                    help="skip obs/action-vs-tape checks (tape only supplies sensor frames; use for deployment C++ parity)")
    ap.add_argument("--cold-start", action="store_true",
                    help="start the target recursion from zero (matches the C++ replay's "
                         "arm() handoff); disables the tape next_target comparison")
    args = ap.parse_args()

    import onnxruntime as ort
    sess = ort.InferenceSession(str(args.onnx), providers=["CPUExecutionProvider"])
    inp = sess.get_inputs()[0]

    with np.load(args.tape, allow_pickle=False) as replay:
        tape = {key: replay[key] for key in replay.files}
    frame = event_trial(tape, args.label, args.trial)
    n = min(args.max_frames, tape["observation"].shape[0])
    report = {"tape": str(args.tape), "onnx": str(args.onnx), "label": args.label,
              "trial": args.trial, "frames": int(n), "limit": args.limit}
    checks = []

    # 1) observation reproduction: Python reference vs the tape's recorded sensors and
    #    the tape's recorded prior target (validates the 58-dim layout and stance/HEIGHT).
    obs_py = np.zeros((n, 58), dtype=np.float64)
    for i in range(n):
        q = tape["q_rad"][i, frame]
        dq = tape["dq_rad_s"][i, frame]
        quat = tape["quat_wxyz"][i, frame]
        gyro = tape["gyro_rad_s"][i, frame]
        command = tape["command_si"][i, frame]
        prior = tape["prior_target"][i, frame]
        obs_py[i] = build_obs(command, gyro, quat, q, dq, prior)
    err_obs = float(np.max(np.abs(obs_py - tape["observation"][:n, frame])))
    report["obs_max_abs_err"] = err_obs
    checks.append(("obs_python_vs_tape", err_obs, args.limit))

    # 2) ONNX action vs recorded raw action (tanh baked => compare against tanh(raw)).
    onnx_out = np.zeros((n, 12), dtype=np.float64)
    for i in range(n):
        onnx_out[i] = sess.run(None, {inp.name: obs_py[i].astype("float32").reshape(1, -1)})[0][0]
    baked = bool(json.loads(Path(args.onnx).with_suffix(".export.json").read_text())["tanh_baked"]) \
        if Path(args.onnx).with_suffix(".export.json").is_file() else True
    ref_action = np.tanh(tape["raw_action"][:n, frame]) if baked else tape["raw_action"][:n, frame]
    err_action = float(np.max(np.abs(onnx_out - ref_action)))
    report["onnx_tanh_baked"] = baked
    report["action_max_abs_err"] = err_action
    if not args.skip_tape_checks:
        checks.append(("onnx_action_vs_tape", err_action, max(args.limit, 2e-5)))

    # 3) closed-loop deployment recursion (obs built from the recursively updated target,
    #    exactly like the C++ controller). With --cold-start the recursion starts at zero,
    #    matching replay's arm(); otherwise it starts from the tape's first prior target.
    target = (np.zeros(16) if args.cold_start
              else np.array(tape["prior_target"][0, frame], dtype=np.float64))
    leg_q = np.zeros((n, 12))
    wheel_dq = np.zeros((n, 4))
    next_target = np.zeros((n, 16))
    obs_rec = np.zeros((n, 58))
    action_rec = np.zeros((n, 12))
    for i in range(n):
        q = tape["q_rad"][i, frame]
        dq = tape["dq_rad_s"][i, frame]
        quat = tape["quat_wxyz"][i, frame]
        gyro = tape["gyro_rad_s"][i, frame]
        command = tape["command_si"][i, frame]
        obs_i = build_obs(command, gyro, quat, q, dq, target)
        action = sess.run(None, {inp.name: obs_i.astype("float32").reshape(1, -1)})[0][0]
        obs_rec[i] = obs_i
        action_rec[i] = action
        target = step_targets(command, action, target, tanh_baked=baked)
        next_target[i] = target
        leg_q[i] = DEFAULT_STANCE[:12] + target[:12]
        wheel_dq[i] = target[12:]
    err_target = float(np.max(np.abs(next_target - tape["next_target"][:n, frame])))
    err_legq = float(np.max(np.abs(leg_q - tape["leg_q_target"][:n, frame])))
    err_wheel = float(np.max(np.abs(wheel_dq - tape["wheel_dq_target"][:n, frame])))
    report["target_max_abs_err"] = err_target
    report["leg_q_target_max_abs_err"] = err_legq
    report["wheel_dq_target_max_abs_err"] = err_wheel
    report["cold_start"] = bool(args.cold_start)
    if args.cold_start:
        report["tape_target_parity_note"] = ("cold-start recursion: next_target deltas vs tape "
                                             "are expected (different initial filtered target) "
                                             "and are report-only; C++ parity uses this recursion")
    else:
        checks.append(("target_vs_tape", err_target, args.limit))
        checks.append(("leg_q_vs_tape", err_legq, args.limit))
        checks.append(("wheel_dq_vs_tape", err_wheel, args.limit))

    # 4) optional C++ replay comparison.
    if args.cpp_replay is not None:
        cpp_obs, cpp_target = parse_cpp_replay(args.cpp_replay)
        m = min(n, len(cpp_obs), len(cpp_target))
        if m == 0:
            checks.append(("cpp_replay_parsed", float("inf"), args.limit))
        else:
            cpp_action = cpp_target[:m, 0:12]
            cpp_legq = cpp_target[:m, 12:24]
            cpp_wheel = cpp_target[:m, 24:28]
            errs = {
                "cpp_obs_max_abs_err": float(np.max(np.abs(cpp_obs[:m] - obs_rec[:m]))),
                "cpp_action_max_abs_err": float(np.max(np.abs(cpp_action - action_rec[:m]))),
                "cpp_leg_q_max_abs_err": float(np.max(np.abs(cpp_legq - leg_q[:m]))),
                "cpp_wheel_dq_max_abs_err": float(np.max(np.abs(cpp_wheel - wheel_dq[:m]))),
            }
            report["cpp"] = {"frames": int(m), **errs}
            for key, value in errs.items():
                checks.append((key, value, args.limit))
    else:
        report["cpp"] = None
        report["cpp_note"] = ("no --cpp-replay supplied: C++ parity pending the v4.x C++ "
                              "controller/replay binary (existing unitree58 controller is "
                              "vx-only wheel mapping; see TOOLCHAIN_STATUS.md)")

    # 5) optional fixture for the future C++ replay binary.
    if args.emit_fixture is not None:
        rows = []
        for i in range(n):
            q = tape["q_rad"][i, frame]
            dq = tape["dq_rad_s"][i, frame]
            quat = tape["quat_wxyz"][i, frame]
            gyro = tape["gyro_rad_s"][i, frame]
            command = tape["command_si"][i, frame]
            elapsed = i * DT
            rows.append(" ".join(f"{v:.9g}" for v in
                                 [elapsed, *quat, *gyro, *q, *dq, *command]))
        args.emit_fixture.write_text("\n".join(rows) + "\n")
        report["fixture"] = str(args.emit_fixture)
        report["fixture_frames"] = n

    failed = [(name, value) for name, value, limit in checks if not (value <= limit)]
    report["checks"] = [{"name": name, "max_abs_err": value, "limit": limit,
                         "pass": bool(value <= limit)} for name, value, limit in checks]
    report["pass"] = not failed
    if args.report is not None:
        args.report.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: report[k] for k in
                      ("frames", "obs_max_abs_err", "action_max_abs_err", "target_max_abs_err",
                       "wheel_dq_target_max_abs_err", "pass")}, indent=2))
    if failed:
        print("FAILED:", ", ".join(f"{name}={value:.3e}" for name, value in failed))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
