#!/usr/bin/env bash
# v4.1 wheel-differential retrain (2026-11-21): v4 contract/DR/asset, v4.1 reward (only
# stability_weight/unstable_penalty withdrawn), doubled envs (default 16384).
# env: OUT UPDATES required; PARENT defaults to the 45b36ee7 endpoint.
#   optional: NUM_ENVS DR_LEVEL REWARD_CONFIG ASSET SEED RESUME_UPDATE GROUND_FRICTION.
set -euo pipefail
cd /root/as2w/retrain-wheeldiff-dr2b-20261122/src
: "${OUT:?}"; : "${UPDATES:?}"
PARENT="${PARENT:=/root/gpufree-data/as2w-runs/v2-stephard600/train/endpoint.pt}"
ASSET="${ASSET:-/root/as2w/assets/generated/as2w/as2w.usda}"
REWARD_CONFIG="${REWARD_CONFIG:-$PWD/reward_config_wheeldiff_v41.json}"
[[ -f "$PARENT" ]] || { echo "PARENT missing: $PARENT" >&2; exit 1; }
[[ -f "$ASSET" ]] || { echo "ASSET missing: $ASSET" >&2; exit 1; }
[[ -f "$REWARD_CONFIG" ]] || { echo "REWARD_CONFIG missing: $REWARD_CONFIG" >&2; exit 1; }
[[ ! -e "$OUT" ]] || { echo "OUT exists: $OUT" >&2; exit 1; }
exec /root/as2w/preflight/isaac-python run.py --out "$OUT" --asset "$ASSET" --terrain flat \
  --num-envs "${NUM_ENVS:-16384}" --rollout-steps 48 --iterations "$UPDATES" \
  --dr-level "${DR_LEVEL:-0}" --seed "${SEED:-42}" --resume "$PARENT" --resume-update "${RESUME_UPDATE:-0}" \
  --ground-friction "${GROUND_FRICTION:-0.35}" --reward-config "$REWARD_CONFIG" \
  --command-hold-s 4.0 --wheel-diff "$@"
