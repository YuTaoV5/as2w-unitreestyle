# A_400 训练溯源

## 来源
- 训练 run：`/root/gpufree-data/as2w-runs/retrain-dr2b-20261122/dr2b_s1_seed42`
- checkpoint：`train/model_400.pt`，iter **400**
- checkpoint SHA256：`88cff1a264ad3ffe5e7b9fc61ddee4998d6101a1f30fa68d0218696e5bbf4802`
- 训练源码：`/root/as2w/retrain-wheeldiff-dr2b-20261122/src`
- 配方：DR2b / v4.1 wheel-differential；A 原配方（lr=1e-4、command_hold=4.0、exec delay 0/1/2/3、obs0、v4.1 reward）
- resolved config：`training/configs/a400_resolved_config.json`
- run/best：`training/configs/a400_train_run.json`、`a400_best.json`

## 导出
- 脚本：`training/export/export_onnx.py`（A/v4x 同脚本）
- 命令：
```bash
CKPT=/root/.../dr2b_s1_seed42/train/model_400.pt
/root/as2w/preflight/isaac-python export_onnx.py "$CKPT" policy.onnx
```
- 导出结果：
  - ONNX SHA256：`acccdedba62312adc15732c8048ff49b2a5e9e12ceb91df730f2d8add3a1b715`
  - bytes：785123
  - obs58→act12，opset17，tanh baked
  - torch↔ORT max abs err：**4.172e-6**（limit 2e-5）
- `policy.export.json` 已随包提供。

## 训练/评测证据
- `training/eval400/flat.json`、`flat-gait-gate.json`、`run.json`、`eval.log`
- `training/evidence/WEIGHT_TOEIN_COMPARISON.md`
- `training/evidence/A_POLICY_TOEIN_60S_REPORT.md`

## 注意
- A_400 是**中间 checkpoint**，不是 A_799 最终版；部署包不改变训练配方。
- 训练资产仅为复现/审计用，不要在机器人上运行训练脚本。
