# CPRO 部署步骤（A_400）

## 0. 前置
- CPRO：HarmonyOS host + Ubuntu 22.04 rootfs；USB HDC `0123456789ABCDEF`。
- 机器人 eth0 在 `192.168.123.0/24`，DDS `rt/lowstate`/`rt/lowcmd`。
- SDK2 工具：`/root/as2w_deploy/build-sdk2/as2w_sdk2`。
- 现场急停/吊装/看护到位；**不要在 ai 模式下起 publisher**。
- 本包 release_authorized=false；zero-B 前必须 owner 明确放行。

## 1. 传包/解压/校验
```bash
hdc file send AS2W_A400_DEPLOY_20261123.zip /data/local/tmp/
cd /data/local/tmp
unzip -o AS2W_A400_DEPLOY_20261123.zip
cd AS2W_A400_DEPLOY_20261123
sha256sum -c SHA256SUMS
```
必须全 OK；任一 FAIL 停止。

## 2. 安装到独立目录（不覆盖 A/C1）
```bash
cd /data/local/tmp
bash AS2W_A400_DEPLOY_20261123/deployment/scripts/install_a400_cpro.sh /root/as2w_deploy_a400_s42_400
```
脚本：
1. 校验 SHA；
2. 复制到 `/root/as2w_deploy_a400_s42_400`；
3. 执行 `as2w_unitree58v4_lp5_publish --offline-audit`；
4. **不启动 publisher、不发 LowCmd**。

只有看到 `AUDIT PASS` 才能继续；否则停止并保留 `logs/offline_audit_a400_installed.stdout`。

## 3. 只读预检
```bash
cd /root/as2w_deploy_a400_s42_400
sha256sum bin/as2w_unitree58v4_lp5_publish models/unitree58-v4x/policy.onnx
ip -br addr | grep eth0          # UP
timeout 8 /root/as2w_deploy/build-sdk2/as2w_sdk2 low-state eth0 rt/lowstate 2 | head -2
timeout 8 /root/as2w_deploy/build-sdk2/as2w_sdk2 motion-mode eth0
```
必须 `name=ai`、LowState 有包、eth0 UP、无 active publisher。

## 4. zero-B（仅现场授权后）
```bash
# 现场操作员执行一次 ReleaseMode，确认 motion-mode name= 空
cd /root/as2w_deploy_a400_s42_400
bash scripts/run_zero_b_guarded_a400.sh
```
- B 被拒/Emergency：立即 X；publisher 停止后 `motion-select ai`。
- 正常路径：A → FixedStand → B 零速 → Brake/ReturnStand → Y squat。
- 本包不自动绕过 B gate；不允许 `--b-gate-pose` 放宽首飞。

## 5. 回滚 A_799
```bash
cd /root/as2w_deploy_a400_s42_400
bash scripts/rollback_A.sh
```
回滚后只读 audit，不自动发布。

## 6. 常见失败
| 现象 | 原因/处理 |
|---|---|
| `sha256sum -c` FAIL | 包损坏/传输不完整；重传，不继续 |
| `AUDIT PASS` 未出现 | 模型/配置/map 不匹配；停止，保留日志 |
| `ABORT: eth0 DOWN` | 检查 PC1/网线/机器人上电 |
| `ABORT: no LowState` | DDS 未就绪；不要发 LowCmd |
| `ABORT: motion mode 'ai'` | 还在 ai；先 ReleaseMode，不能跳过 |
| FOC acknowledgement timeout | publisher fail-closed 停止；恢复 ai，查链路/上电 |
