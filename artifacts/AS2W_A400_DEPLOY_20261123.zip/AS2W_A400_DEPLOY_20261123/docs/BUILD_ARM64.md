# ARM64 源码重建（严格部署建议）

> 包内 `deployment/bin/` 是 A/v4x 参考 ARM64 构建（SHA `741807...`）。
> `deployment/source/` 已包含 FixedStand 200/4 参数修正（`fixed_stand_targets(..., stand_kp, stand_kd)`、hip map +1、wheel kd 0.5），但打包环境无法重编译。
> 若要求 binary/source 严格一致，请在 CPRO rootfs 上重建并替换二进制，再重新 audit。

## 1. 进入 CPRO rootfs
```bash
cd /data/local/tmp/as2w_field
./cpro_ubuntu.sh bash
```

## 2. 准备源码
```bash
D=/root/as2w_deploy_a400_s42_400
# 包已安装时，源码在 $D/source；或从 zip 复制
cd $D/source
# 确认有 CMakeLists.txt、as2w_publish.cpp、unitree58v4_controller.*
```

## 3. 构建 ARM64 publish/replay
以下路径以现有 CPRO 构建树为例；若没有，需要按 CMakeLists 配置：
```bash
cd /root/as2w_deploy_v4x
cmake --build build-v4x --target as2w_unitree58v4_lp5_publish -j"$(nproc)"
cmake --build build-v4x --target as2w_unitree58v4_lp5_replay -j"$(nproc)"
```
把新二进制复制到部署目录并**先跑 audit**：
```bash
D=/root/as2w_deploy_a400_s42_400
cp build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish $D/bin/
cp build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_replay $D/bin/
cd $D
./bin/as2w_unitree58v4_lp5_publish models/unitree58-v4x/deploy.yaml \
  config/unitree58_measured.map --offline-audit
```
只有 `AUDIT PASS` 才继续。

## 4. 记录新 SHA
```bash
sha256sum bin/as2w_unitree58v4_lp5_publish bin/as2w_unitree58v4_lp5_replay
```
把结果写入 manifest/README，重新生成 `SHA256SUMS`；不要用旧 SHA 继续发放。

## 5. 必须保留的回退
- `deployment/rollback_A/policy.onnx`：A_799 回滚模型。
- 独立安装目录：不要覆盖 `/root/as2w_deploy_v4x`。
- 如果重建失败，退回包内参考二进制但**必须标注审计状态**，不能当已验证二进制。
