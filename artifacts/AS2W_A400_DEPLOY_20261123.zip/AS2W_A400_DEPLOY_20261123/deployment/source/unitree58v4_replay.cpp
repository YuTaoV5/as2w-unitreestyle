#include "unitree58v4_controller.hpp"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <vector>

// Offline replay for the unitree58 (58 obs / 12 action) controller. DDS-free.
//
// Fixture rows (whitespace separated, one policy frame per row):
//   elapsed quat_w quat_x quat_y quat_z gyro_x gyro_y gyro_z
//   q0..q15 (policy order) dq0..dq15 vx_cmd vy_cmd wz_cmd
//
// gyro must be the BODY-FRAME angular velocity and quat the body-to-world
// wxyz quaternion — the same semantics the publisher feeds from LowState.
// Each fixture is one continuous segment: the controller is armed fresh
// (targets and previous-target observation zero), matching a B handoff.
// Per frame it prints:
//   UNITREE58_OBS,<elapsed>,<obs 0..57>
//   UNITREE58_TARGET,<elapsed>,<action 0..11>,<leg q 0..11>,<wheel dq 12..15>
// and a final summary with the worst single-frame leg-target step, which is the
// quantity the field guard watches (theoretical worst case is
// alpha_leg * 2 * 0.25 = 0.358 rad for a full +-1 action reversal).

int main(int argc, char** argv) {
    if (argc != 3) {
        std::cerr << "usage: as2w_unitree58v4_replay deploy.yaml fixture.txt\n";
        return 2;
    }
    try {
        as2w_unitree58v4::Controller c(as2w_unitree58v4::load_config(argv[1]));
        std::ifstream input(argv[2]);
        if (!input) throw std::runtime_error("Cannot open fixture");
        c.arm();
        int n = 0;
        float elapsed;
        float max_leg_step = 0.f;
        float max_wheel_target = 0.f;
        std::vector<float> prev_q(12, 0.f);
        bool have_prev = false;
        while (input >> elapsed) {
            as2w_unitree58v4::SensorState s;
            for (auto& v : s.body_to_world_wxyz) if (!(input >> v)) throw std::runtime_error("quat");
            for (auto& v : s.gyro) if (!(input >> v)) throw std::runtime_error("gyro");
            for (auto& v : s.position) if (!(input >> v)) throw std::runtime_error("position");
            for (auto& v : s.velocity) if (!(input >> v)) throw std::runtime_error("velocity");
            as2w_unitree58v4::Vector3 command{};
            for (auto& v : command) if (!(input >> v)) throw std::runtime_error("command");
            const auto target = c.step(s, command, .02f);
            if (!target.active) throw std::runtime_error("Controller disarmed");
            for (std::size_t i = 0; i < 12; ++i) {
                if (have_prev)
                    max_leg_step = std::max(max_leg_step,
                        std::abs(target.motors[i].q - prev_q[i]));
                prev_q[i] = target.motors[i].q;
            }
            have_prev = true;
            for (std::size_t i = 12; i < 16; ++i)
                max_wheel_target = std::max(max_wheel_target,
                    std::abs(target.motors[i].dq));
            std::cout << std::setprecision(9) << "UNITREE58_OBS," << elapsed;
            for (auto v : c.last_observation()) std::cout << ',' << v;
            std::cout << '\n';
            std::cout << std::setprecision(9) << "UNITREE58_TARGET," << elapsed;
            for (std::size_t i = 0; i < 12; ++i) std::cout << ',' << target.action[i];
            for (std::size_t i = 0; i < 12; ++i) std::cout << ',' << target.motors[i].q;
            for (std::size_t i = 12; i < 16; ++i) std::cout << ',' << target.motors[i].dq;
            std::cout << '\n';
            std::cout << std::setprecision(9) << "UNITREE58V4_WHEELCMD," << elapsed;
            for (auto v : c.last_wheel_cmd()) std::cout << ',' << v;
            std::cout << '\n';
            ++n;
        }
        if (!n) throw std::runtime_error("Empty fixture");
        std::cerr << "UNITREE58_REPLAY_FRAMES=" << n
                  << " LEG_ALPHA=" << c.leg_alpha()
                  << " WHEEL_ALPHA=" << c.wheel_alpha()
                  << " MAX_LEG_STEP=" << max_leg_step
                  << " MAX_WHEEL_TARGET=" << max_wheel_target << '\n';
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "unitree58 replay failed: " << e.what() << '\n';
        return 1;
    }
}
