#include "unitree58v4_controller.hpp"

#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <vector>

#include <yaml-cpp/yaml.h>

namespace as2w_unitree58v4 {
namespace {

constexpr float Pi = 3.14159265358979323846f;
// Leg axes (12) = ActionSize. Deliberately file-local: as2w_publish.cpp keeps a
// global LegCount and pulls this namespace in with `using namespace`, so a
// namespace-level duplicate would be ambiguous there.
constexpr std::size_t LegAxes = ActionSize;

template <class Range> bool finite(const Range& xs) {
    return std::all_of(xs.begin(), xs.end(), [](float x) { return std::isfinite(x); });
}

template <typename T, std::size_t N>
std::array<T, N> read_array(const YAML::Node& n, const char* what) {
    if (!n || !n.IsSequence() || n.size() != N)
        throw std::runtime_error(std::string("unitree58 deploy.yaml needs ") + what);
    std::array<T, N> out{};
    for (std::size_t i = 0; i < N; ++i) out[i] = n[i].as<T>();
    return out;
}

// Model contract gate. Runs before any LowCmd target can exist: an ONNX that is
// not exactly 58->12 with input "obs" means the wrong file was copied next to
// the YAML, and that must fail at startup, not on the robot.
//
// The OUTPUT NAME is deliberately NOT pinned: the verified export
// (unitree58/model_1000.onnx, SHA f617840c…) names it "fc6" (the last layer),
// not "action" as the hand-off doc claimed. Any single float32 [N,12] output is
// accepted and step() consumes it through OrtRunner::act(), which prefers
// "actions" and otherwise takes the first output. What IS pinned: exactly one
// input named "obs" of [N,58], exactly one output of [N,12], both float32.
std::string checked_model(const std::filesystem::path& path) {
    Ort::Env env(ORT_LOGGING_LEVEL_WARNING, "as2w_unitree58v4_contract");
    Ort::SessionOptions options;
    options.SetIntraOpNumThreads(1);
    Ort::Session session(env, path.string().c_str(), options);
    Ort::AllocatorWithDefaultOptions allocator;
    if (session.GetInputCount() != 1 || session.GetOutputCount() != 1)
        throw std::runtime_error("unitree58v4 expects one ONNX input and one output");
    const auto input = session.GetInputNameAllocated(0, allocator);
    const auto output = session.GetOutputNameAllocated(0, allocator);
    // Two-step form (not chained temporaries): mirrors armd_controller.cpp so
    // the TypeInfo outlives the TensorTypeAndShapeInfo on every ORT version.
    const auto input_type = session.GetInputTypeInfo(0);
    const auto output_type = session.GetOutputTypeInfo(0);
    const auto in = input_type.GetTensorTypeAndShapeInfo();
    const auto out = output_type.GetTensorTypeAndShapeInfo();
    const auto in_shape = in.GetShape();
    const auto out_shape = out.GetShape();
    if (std::string(input.get()) != "obs" ||
        in_shape.size() != 2 || in_shape[1] != static_cast<int64_t>(ObsSize) ||
        out_shape.size() != 2 || out_shape[1] != static_cast<int64_t>(ActionSize) ||
        in.GetElementType() != ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT ||
        out.GetElementType() != ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT)
        throw std::runtime_error(
            "unitree58v4 ONNX tensor contract mismatch (need obs[N,58] -> [N,12] float32)");
    std::cout << "UNITREE58V4_MODEL input=" << input.get()
              << "[N," << ObsSize << "] output=" << output.get()
              << "[N," << ActionSize << "] float32\n";
    return path.string();
}

float alpha_from_cutoff(float hz, float dt) { return -std::expm1(-2.f * Pi * hz * dt); }

}  // namespace

Config load_config(const std::filesystem::path& yaml_path) {
    const auto y = YAML::LoadFile(yaml_path.string());
    Config c;
    if (!y["model_version"])
        throw std::runtime_error("unitree58 deploy.yaml needs model_version");
    c.model_version = y["model_version"].as<std::string>();
    if (!y["policy_file"]) throw std::runtime_error("unitree58 deploy.yaml needs policy_file");
    c.onnx = std::filesystem::absolute(yaml_path.parent_path() /
                                       y["policy_file"].as<std::string>());
    c.dt = y["step_dt"] ? y["step_dt"].as<float>() : .02f;
    const int obs = y["observation_size"] ? y["observation_size"].as<int>() : 0;
    const int act = y["action_size"] ? y["action_size"].as<int>() : 0;
    if (obs != static_cast<int>(ObsSize))
        throw std::runtime_error("unitree58 requires observation_size 58");
    if (act != static_cast<int>(ActionSize))
        throw std::runtime_error("unitree58 requires action_size 12");
    c.joint_names = read_array<std::string, MotorCount>(y["joint_names"], "joint_names(16)");
    c.defaults = read_array<float, MotorCount>(y["default_joint_pos"], "default_joint_pos(16)");
    c.stiffness = read_array<float, MotorCount>(y["stiffness"], "stiffness(16)");
    c.damping = read_array<float, MotorCount>(y["damping"], "damping(16)");
    if (y["vx_limit"]) c.vx_limit = y["vx_limit"].as<float>();
    if (y["wz_limit"]) c.wz_limit = y["wz_limit"].as<float>();
    if (y["wheel_idle_eps"]) c.wheel_idle_eps = y["wheel_idle_eps"].as<float>();
    // Contract constants: required, no silent defaults (a typo must not degrade
    // into a different closed loop).
    const auto need = [&](const char* key) {
        if (!y[key])
            throw std::runtime_error(std::string("unitree58 deploy.yaml needs ") + key);
        return y[key].as<float>();
    };
    c.leg_target_cutoff_hz = need("leg_target_cutoff_hz");
    c.wheel_target_cutoff_hz = need("wheel_target_cutoff_hz");
    c.wheel_radius = need("wheel_radius");
    c.leg_action_scale = need("leg_action_scale_rad");
    c.wheel_rate_clamp = need("wheel_rate_clamp");
    c.height = need("obs_height");
    c.track_width = need("track_width_m");
    c.yaw_efficiency = need("yaw_efficiency");

    if (!(c.dt > 0.f) || !(c.leg_target_cutoff_hz > 0.f) ||
        !(c.wheel_target_cutoff_hz > 0.f) || !(c.wheel_radius > 0.f) ||
        !(c.leg_action_scale > 0.f) || !(c.wheel_rate_clamp > 0.f) || !(c.height > 0.f) ||
        !(c.track_width > 0.f) || !(c.yaw_efficiency > 0.f))
        throw std::runtime_error("unitree58v4 deploy.yaml has a non-positive contract constant");
    if (!finite(c.defaults) || !finite(c.stiffness) || !finite(c.damping) ||
        !std::isfinite(c.vx_limit) || !std::isfinite(c.wz_limit) ||
        !std::isfinite(c.wheel_idle_eps) || c.vx_limit <= 0.f || c.vx_limit > .60f ||
        c.wz_limit < 0.f || c.wz_limit > .60f)
        throw std::runtime_error(
            "unitree58v4 deploy.yaml envelope/defaults invalid (vx<=.60, 0<=wz<=.60)");

    // ── exact training contract (as2w-unitreestyle/common/environment.py,
    //    preflight/control.toml) ────────────────────────────────────────────
    // Joint order is LEG-MAJOR: environment.py:22 builds
    //   LEGS = [f"{leg}_{part}" for leg in (FL,FR,RL,RR) for part in (hip,thigh,calf)]
    // i.e. FL_hip, FL_thigh, FL_calf, FR_hip, ... — each leg's three joints are
    // contiguous. This is NOT armd's part-major order (FL_hip, FR_hip, RL_hip,
    // RR_hip, FL_thigh, ...). Same physical stance, different index order: a
    // permutation here mis-assigns every observation and every action while all
    // the width/gain checks still pass.
    static const std::array<std::string, MotorCount> expected{
        "FL_hip", "FL_thigh", "FL_calf", "FR_hip", "FR_thigh", "FR_calf",
        "RL_hip", "RL_thigh", "RL_calf", "RR_hip", "RR_thigh", "RR_calf",
        "FL_foot", "FR_foot", "RL_foot", "RR_foot"};
    for (std::size_t i = 0; i < MotorCount; ++i) {
        // v4.x official stance: hip FL/RL -0.15, FR/RR +0.15; thigh .60; calf -1.20.
        const float def = i >= LegAxes ? 0.f
            : i % 3 == 0 ? (((i / 3) % 2) ? .15f : -.15f)
            : i % 3 == 1 ? .60f : -1.20f;
        if (c.joint_names[i] != expected[i] ||
            std::abs(c.defaults[i] - def) > 1e-5f ||
            std::abs(c.stiffness[i] - (i < LegAxes ? 55.f : 0.f)) > 1e-5f ||
            std::abs(c.damping[i] - 2.f) > 1e-5f)
            throw std::runtime_error("unitree58 joint/default/gain contract mismatch");
    }
    // Contract tag, not a weights tag: swapping in new 58/12 weights of the same
    // training family keeps this string, so it must NOT encode a checkpoint id.
    // It exists to reject an unrelated 58/12 ONNX that happens to be sitting in
    // the model dir (e.g. a different experiment with the same shapes).
    if (c.model_version != "unitree-wheeldiff-58")
        throw std::runtime_error(
            "unitree58v4 deploy.yaml model_version must be 'unitree-wheeldiff-58'");
    // The leg-target cutoff is the ONE constant that differs between the trained
    // contract (10 Hz) and the LP5 deployment variant (5 Hz). A binary can only
    // load the YAML whose cutoff matches its build, so a mismatched pair fails at
    // startup instead of silently running a different closed loop.
#if defined(AS2W_UNITREE58_LP5) && defined(AS2W_UNITREE58_S15)
#error "unitree58: pick ONE deployment variant (LP5 leg filter 5 Hz OR S15 action scale 0.15)"
#endif
#if defined(AS2W_UNITREE58_LP5)
    constexpr float kExpectedLegHz = 5.f;
#else
    constexpr float kExpectedLegHz = 10.f;
#endif
#if defined(AS2W_UNITREE58_S15)
    constexpr float kExpectedScale = .15f;
#else
    constexpr float kExpectedScale = .25f;
#endif
#if defined(AS2W_UNITREE58_LP5)
    constexpr const char* kContractName = "unitree58v4 (v4.x wheel-diff, 5 Hz leg filter)";
#elif defined(AS2W_UNITREE58_S15)
    constexpr const char* kContractName = "unitree58-s15 (leg action scale 0.15, NEW contract)";
#else
    constexpr const char* kContractName = "unitree58v4 requires AS2W_UNITREE58_LP5 (5 Hz)";
#endif
    if (std::abs(c.dt - .02f) > 1e-6f ||
        std::abs(c.leg_target_cutoff_hz - kExpectedLegHz) > 1e-6f ||
        std::abs(c.wheel_target_cutoff_hz - 5.f) > 1e-6f ||
        std::abs(c.wheel_radius - .086f) > 1e-6f ||
        std::abs(c.leg_action_scale - kExpectedScale) > 1e-6f ||
        std::abs(c.wheel_rate_clamp - 12.f) > 1e-6f ||
        std::abs(c.height - .45f) > 1e-6f ||
        std::abs(c.wheel_idle_eps - .02f) > 1e-6f ||
        std::abs(c.track_width - .44f) > 1e-6f ||
        std::abs(c.yaw_efficiency - .415f) > 1e-6f)
        throw std::runtime_error(
            std::string("unitree58v4 contract constants mismatch vs ") + kContractName +
            " (dt .02 / leg cutoff from build / wheel 5 Hz / R .086 / B .44 / eta .415 / "
            "leg scale from build / clamp 12 / HEIGHT .45 / idle .02)");
    return c;
}

Controller::Controller(Config config)
    : config_(std::move(config)), runner_(checked_model(config_.onnx)),
      leg_alpha_(alpha_from_cutoff(config_.leg_target_cutoff_hz, config_.dt)),
      wheel_alpha_(alpha_from_cutoff(config_.wheel_target_cutoff_hz, config_.dt)) {}

void Controller::arm() {
    target_leg_.fill(0.f);
    target_wheel_.fill(0.f);
    obs_.fill(0.f);
    last_raw_.fill(0.f);
    armed_ = true;
}

void Controller::stop() { arm(); armed_ = false; }

Targets Controller::step(const SensorState& s, const Vector3& command, float age_seconds) {
    if (!armed_) return {};
    // The publisher only runs the policy in PolicyHandoff/PolicyWalk; a stale or
    // non-finite frame must disarm rather than publish a target computed from it.
    if (!std::isfinite(age_seconds) || age_seconds < 0.f || age_seconds > .05f ||
        !finite(s.gyro) || !finite(s.body_to_world_wxyz) || !finite(s.position) ||
        !finite(s.velocity) || !finite(command)) {
        stop();
        return {};
    }
    // ── body-frame projected gravity ───────────────────────────────────────
    // Training feeds `d.projected_gravity_b` (physics-authoritative). Its
    // convention is R^T * (0,0,-1): UPRIGHT IS (0,0,-1), proven by
    // environment.py:189 `failed = projected_gravity_b[:,2] > -.52` — with a +1
    // upright convention every episode would fail on its first frame. The
    // sibling armd_controller.cpp:200-202 uses the same sign. This file used to
    // emit +R3i (upright +1), i.e. inverted gravity; do not "simplify" it back.
    const auto& q = s.body_to_world_wxyz;
    const float n2 = q[0]*q[0] + q[1]*q[1] + q[2]*q[2] + q[3]*q[3];
    if (n2 < .81f || n2 > 1.21f) { stop(); return {}; }
    const float inv = 1.f / std::sqrt(n2);
    const float w = q[0]*inv, x = q[1]*inv, y = q[2]*inv, z = q[3]*inv;
    const float gx = -2.f * (x * z - w * y);
    const float gy = -2.f * (y * z + w * x);
    const float gz = 2.f * (x * x + y * y) - 1.f;

    // ── observation (58), environment.py:_frame ────────────────────────────
    std::size_t k = 0;
    obs_[k++] = command[0]; obs_[k++] = command[1]; obs_[k++] = command[2];
    obs_[k++] = s.gyro[0];  obs_[k++] = s.gyro[1];  obs_[k++] = s.gyro[2];
    obs_[k++] = gx; obs_[k++] = gy; obs_[k++] = gz;
    // obs[9..24] joint_pos - default, wheel 4 zeroed (environment.py:170).
    for (std::size_t i = 0; i < MotorCount; ++i) obs_[k++] = s.position[i] - config_.defaults[i];
    obs_[9 + 12] = obs_[9 + 13] = obs_[9 + 14] = obs_[9 + 15] = 0.f;  // == obs[21..24]
    // obs[25..40] joint_vel*0.05 for ALL 16 axes, wheels included
    // (environment.py:173 applies the scale to the whole `self.ids` slice).
    // Zeroing the wheel entries here would be a different observation.
    for (std::size_t i = 0; i < MotorCount; ++i) obs_[k++] = s.velocity[i] * .05f;
    // obs[41..52] leg targets, obs[53..56] wheel targets, obs[57] HEIGHT.
    for (std::size_t i = 0; i < LegAxes; ++i)
        obs_[k++] = target_leg_[i] / config_.leg_action_scale;
    for (std::size_t i = 0; i < 4; ++i)
        obs_[k++] = target_wheel_[i] / config_.wheel_rate_clamp;
    obs_[k++] = config_.height;
    if (k != ObsSize) { stop(); return {}; }

    // ── inference ─────────────────────────────────────────────────────────
    // act() = forward() + take "actions" if present, else the FIRST output. The
    // verified export's output is named "fc6", so a hard `.at("action")` would
    // throw std::out_of_range at the very first policy step (caught by
    // checked_model at startup, but fail-closed beats fail-on-robot).
    const auto raw = runner_.act(
        {{"obs", std::vector<float>(obs_.begin(), obs_.end())}});
    if (raw.size() != ActionSize) { stop(); return {}; }
    for (float v : raw) if (!std::isfinite(v)) { stop(); return {}; }
    last_raw_.fill(0.f);
    std::copy(raw.begin(), raw.end(), last_raw_.begin());

    // ── action application ────────────────────────────────────────────────
    Targets out;
    out.active = true;
    for (std::size_t i = 0; i < LegAxes; ++i) {
        const float a = std::clamp(raw[i], -1.f, 1.f);
        out.action[i] = a;
        target_leg_[i] += (a * config_.leg_action_scale - target_leg_[i]) * leg_alpha_;
    }
    // ── wheel targets: v4.x differential contract ────────────────────────
    //   base = vx/R ; yaw = wz*(B/2)/(R*eta)
    //   FL = RL = base - yaw ; FR = RR = base + yaw ; clamp +-12
    // AS2W_WHEEL_LEGACY restores the frozen v2step vx/R mapping for rollback.
    std::array<float, 4> wheel_cmd{};
#if defined(AS2W_WHEEL_LEGACY)
    wheel_cmd.fill(command[0] / config_.wheel_radius);
#else
    const float base = command[0] / config_.wheel_radius;
    const float yaw = command[2] * (config_.track_width * .5f) /
                      (config_.wheel_radius * config_.yaw_efficiency);
    wheel_cmd = {{base - yaw, base + yaw, base - yaw, base + yaw}};  // FL, FR, RL, RR
#endif
    for (std::size_t i = 0; i < 4; ++i)
        wheel_cmd[i] = std::clamp(wheel_cmd[i], -config_.wheel_rate_clamp,
                                  config_.wheel_rate_clamp);
    last_wheel_cmd_ = wheel_cmd;
    for (std::size_t i = 0; i < 4; ++i)
        target_wheel_[i] += (wheel_cmd[i] - target_wheel_[i]) * wheel_alpha_;
    // v4.x zero-speed snap: only when BOTH vx and wz are zero.
    if (std::abs(command[0]) < 1e-6f && std::abs(command[2]) < 1e-6f)
        for (std::size_t i = 0; i < 4; ++i)
            if (std::abs(target_wheel_[i]) < config_.wheel_idle_eps) target_wheel_[i] = 0.f;

    for (std::size_t i = 0; i < LegAxes; ++i) {
        out.motors[i].q = config_.defaults[i] + target_leg_[i];
        out.motors[i].kp = config_.stiffness[i];
        out.motors[i].kd = config_.damping[i];
    }
    for (std::size_t i = LegAxes; i < MotorCount; ++i) {
        out.motors[i].dq = target_wheel_[i - LegAxes];
        out.motors[i].kp = 0.f;
        out.motors[i].kd = config_.damping[i];
    }
    return out;
}

}  // namespace as2w_unitree58v4
