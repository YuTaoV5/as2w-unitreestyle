cmake_minimum_required(VERSION 3.16)
project(as2w_unitree58v4_deploy LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# ── AS2-W unitree-unified 58 obs / 12 action candidate ─────────────────────
# 完全独立的第三套滚动契约（obs 58 / action 12 / 轮由 vx/R 独立映射 /
# 腿 10 Hz + 轮 5 Hz 滤波在控制器内 / 腿 55-2、轮 0-2）。
# 本目录与 r1199/r4000/t15/armd 平级，**不修改任何兄弟目录的构建文件**：
# armd 的 CMakeLists、控制器、模型目录都保持原样，armd 的既有构建树
# （build-armd-*）不受本目录增删影响。
#
# 它复用共享发布端 ../common/as2w_publish.cpp 的 FSM，但走自己的
# AS2W_POLICY_UNITREE58 分支（不是 AS2W_POLICY_ARMD —— 那个分支会
# include ../armd/armd_controller.hpp，即 65/16 的另一套契约）。
# 不定义 AS2W_ENABLE_POLICY_LOWPASS：滤波已在控制器内，发布端再滤是双重滤波。
set(ONNXRUNTIME_ROOT "" CACHE PATH "Extracted ONNX Runtime package")
if(NOT ONNXRUNTIME_ROOT)
  message(FATAL_ERROR "Set ONNXRUNTIME_ROOT for unitree58")
endif()

find_package(yaml-cpp REQUIRED)
find_library(ort_library NAMES onnxruntime libonnxruntime.so.1
  PATHS "${ONNXRUNTIME_ROOT}/lib" NO_DEFAULT_PATH REQUIRED)

# Offline core (no DDS): controller library + DDS-free replay.
add_library(as2w_unitree58v4 unitree58v4_controller.cpp)
target_compile_definitions(as2w_unitree58v4 PRIVATE AS2W_UNITREE58_LP5=1)
target_include_directories(as2w_unitree58v4 PUBLIC . "${ONNXRUNTIME_ROOT}/include" ../../../include)
target_link_libraries(as2w_unitree58v4 PUBLIC "${ort_library}" yaml-cpp)

add_executable(as2w_unitree58v4_replay unitree58v4_replay.cpp)
target_link_libraries(as2w_unitree58v4_replay PRIVATE as2w_unitree58v4)

# Gated publisher. B only exists with BOTH the publish option and the zero-B
# trial option, exactly like the armd/R1199 candidates: a plain
# AS2W_UNITREE58_PUBLISH build has no B path at all, and even the zero-B build
# additionally requires --i-confirm-lowcmd-publish + a NIC + exactly one
# --zero-b-trial cycle at runtime.
option(AS2W_UNITREE58_PUBLISH "Build the gated unitree58 FSM publisher" OFF)
option(AS2W_UNITREE58_ZERO_B_TRIAL "Allow one bounded unitree58 zero-B cycle" OFF)
if(AS2W_UNITREE58_ZERO_B_TRIAL AND NOT AS2W_UNITREE58_PUBLISH)
  message(FATAL_ERROR "AS2W_UNITREE58_ZERO_B_TRIAL requires AS2W_UNITREE58_PUBLISH")
endif()
if(AS2W_UNITREE58_PUBLISH)
  find_package(unitree_sdk2 CONFIG REQUIRED)
  find_package(Threads REQUIRED)
  add_executable(as2w_unitree58v4_publish ../common/as2w_publish.cpp)
  target_compile_definitions(as2w_unitree58v4_publish PRIVATE
  AS2W_POLICY_UNITREE58=1 AS2W_UNITREE58_LP5=1)
  if(AS2W_UNITREE58_ZERO_B_TRIAL)
    target_compile_definitions(as2w_unitree58v4_publish PRIVATE
      AS2W_ENABLE_POLICY_ZERO_B_TRIAL=1)
  endif()
  target_link_libraries(as2w_unitree58v4_publish PRIVATE
    as2w_unitree58v4 unitree_sdk2 Threads::Threads)
  if(BUILD_TESTING)
    # Needs models/unitree58/policy.onnx in place: the controller validates the
    # ONNX tensor contract (obs[1,58] -> action[1,12] float32) at construction,
    # which happens before the audit body runs.
    #
    # config/unitree58_measured.map = config/r152_measured.map RE-ORDERED to
    # leg-major (no new calibration: same slot/sign/zero per joint name). Two
    # hard constraints on that file, both enforced by read_mapping():
    #   1. it must be positionally aligned with models/unitree58-v4x/deploy.yaml's
    #      joint_names (leg-major) -- r152_measured.map is part-major;
    #   2. it must contain EXACTLY 16 lines of "name slot sign zero": the parser
    #      uses `file >> name`, so there is no comment syntax in .map files.
    add_test(NAME unitree58-startup-audit COMMAND as2w_unitree58v4_publish
      "${CMAKE_SOURCE_DIR}/models/unitree58-v4x/deploy.yaml"
      "${CMAKE_SOURCE_DIR}/config/unitree58_measured.map" --offline-audit)
  endif()
endif()

# ── unitree58 LP5: deployment-side 5 Hz leg filter (NEW execution contract) ──
# The trained contract filters leg targets at 10 Hz. The 2026-11-19 field trial
# measured the actor saturating, so the leg target dithers over its full
# +-0.25 rad range (sign reversals on 30% of frames, 4.5 Hz dominant) and the
# robot was "very shaky". MuJoCo shows that lowering the cutoff to 5 Hz keeps it
# stable (0 non-wheel contacts, flatter body) while halving the single-frame
# bound (0.358 -> 0.233 rad). This is an ISOLATED candidate with its own library,
# because load_config hard-checks the cutoff against the build's macro; the
# trained 10 Hz build above is not rebuilt by this option.
# It reuses models/unitree58/policy.onnx via a relative policy_file, so no second
# copy of the weights exists.
option(AS2W_UNITREE58_LP5 "unitree58v4 REQUIRES the 5 Hz leg-filter contract" ON)
if(NOT AS2W_UNITREE58_LP5)
  message(FATAL_ERROR "unitree58v4 requires AS2W_UNITREE58_LP5=ON (v4.x training uses 5 Hz)")
endif()
if(AS2W_UNITREE58_LP5)
  if(NOT AS2W_UNITREE58_PUBLISH)
    message(FATAL_ERROR "AS2W_UNITREE58_LP5 requires AS2W_UNITREE58_PUBLISH")
  endif()
  find_package(unitree_sdk2 CONFIG REQUIRED)
  find_package(Threads REQUIRED)
  add_library(as2w_unitree58v4_lp5 unitree58v4_controller.cpp)
  target_compile_definitions(as2w_unitree58v4_lp5 PRIVATE AS2W_UNITREE58_LP5=1)
  target_include_directories(as2w_unitree58v4_lp5 PUBLIC
    . "${ONNXRUNTIME_ROOT}/include" ../../../include)
  target_link_libraries(as2w_unitree58v4_lp5 PUBLIC "${ort_library}" yaml-cpp)
  add_executable(as2w_unitree58v4_lp5_publish ../common/as2w_publish.cpp)
  target_compile_definitions(as2w_unitree58v4_lp5_publish PRIVATE
    AS2W_POLICY_UNITREE58=1 AS2W_ENABLE_POLICY_ZERO_B_TRIAL=1
    AS2W_UNITREE58_LP5=1)
  target_link_libraries(as2w_unitree58v4_lp5_publish PRIVATE
    as2w_unitree58v4_lp5 unitree_sdk2 Threads::Threads)
  add_executable(as2w_unitree58v4_lp5_replay unitree58v4_replay.cpp)
  target_compile_definitions(as2w_unitree58v4_lp5_replay PRIVATE AS2W_UNITREE58_LP5=1)
  target_link_libraries(as2w_unitree58v4_lp5_replay PRIVATE as2w_unitree58v4_lp5)
  if(BUILD_TESTING)
    add_test(NAME unitree58-v4x-startup-audit COMMAND as2w_unitree58v4_lp5_publish
      "${CMAKE_SOURCE_DIR}/models/unitree58-v4x/deploy.yaml"
      "${CMAKE_SOURCE_DIR}/config/unitree58_measured.map" --offline-audit)
  endif()
endif()

