#pragma once

// AS2-W "unitree-wheeldiff" (v4.x) rolling policy (58 observation / 12 action).
// The frozen v2step contract stays in ../unitree58; this directory is the v4.x
// wheel-differential contract (official stance / HEIGHT .45 / wz differential
// wheels / 5 Hz leg filter / B=.44 eta=.415).
//
// Contract source of truth (2026-11-19 static review): the training repo holds
// the exact same environment the weights came from —
//   /root/as2w/unified_unitree_20261119-010208/  ==  as2w-unitreestyle/
//     retrain-wheeldiff-v41-20261121/src/environment.py (FRAME=58, STANCE, wheel_targets)
//     retrain-wheeldiff-v41-20261121/src/control.toml  (leg 5 Hz / wheel 5 Hz)
//   obs (58) = command(3) + body ang-vel(3) + projected_gravity_b(3)
//              + (joint_pos - default)(16, wheel 4 zeroed)
//              + joint_vel*0.05(16, ALL 16 incl. wheels — environment.py:173)
//              + prev_target(16: leg/0.25, wheel/12) + HEIGHT(1)
//   action (12) = legs only: target_leg <- lerp(target_leg, clamp(a,+-1)*0.25,
//                 alpha_leg), alpha_leg = -expm1(-2*pi*10*dt)
//   wheels      = v4.x differential: base=vx/R; yaw=wz*(B/2)/(R*eta);
//                 FL=RL=base-yaw, FR=RR=base+yaw; clamp +-12; then
//                 target_wheel <- lerp(target_wheel, wheel_cmd, alpha_wheel),
//                 alpha_wheel=-expm1(-2*pi*5*dt), zeroed only when vx==0 AND
//                 wz==0 AND |target_wheel|<0.02 (AS2W_WHEEL_LEGACY restores vx/R)
//   gains       = legs kp55/kd2 (position), wheels kp0/kd2 (velocity)
//   RADIUS=0.086, B=0.44, eta=0.415, HEIGHT=0.45, RESET_HEIGHT=0.450, dt=0.02
//
// interface mirrors as2w_armd_deploy's publisher-facing API exactly, because the
// shared publisher (../common/as2w_publish.cpp) is selected by
// `namespace active_policy = ...` and reads Controller/Config/SensorState/
// Targets/Vector3 plus controller.step()/arm()/stop()/last_observation()/
// last_raw_action() — nothing else. It is NOT armd: there is no getup path here
// (no Legs/height_estimate/last_up/blend), so as2w_publish.cpp needs its own
// AS2W_POLICY_UNITREE58 branch.

#include <array>
#include <cstddef>
#include <filesystem>
#include <string>

#include "isaaclab/algorithms/algorithms.h"

namespace as2w_unitree58v4 {

inline constexpr std::size_t MotorCount = 16;
inline constexpr std::size_t ObsSize = 58;
inline constexpr std::size_t ActionSize = 12;
// NB: do NOT export a LegCount here. as2w_publish.cpp declares its own global
// `constexpr std::size_t LegCount = 12;` and later does `using namespace
// active_policy;` inside main — a namespace-level duplicate would make every
// unqualified `LegCount` in that scope ambiguous. The leg axis count is
// ActionSize (12) internally; armd_controller.cpp carries the same warning.

using Vector3 = std::array<float, 3>;
using Motors = std::array<float, MotorCount>;
using Features = std::array<float, ObsSize>;

struct SensorState {
    Vector3 gyro{};                       // body-frame angular velocity (IMU)
    std::array<float, 4> body_to_world_wxyz{};
    Motors position{};                    // policy joint order, zero/sign applied
    Motors velocity{};
};

struct MotorTarget { float q = 0, dq = 0, kp = 0, kd = 0; };

struct Targets {
    std::array<MotorTarget, MotorCount> motors{};
    Motors action{};                      // clamped leg action (12 used), for logging
    bool active = false;
};

struct Config {
    std::filesystem::path onnx;
    std::string model_version;
    std::array<std::string, MotorCount> joint_names;
    Motors defaults{}, stiffness{}, damping{};
    float dt = .02f;
    float vx_limit = .15f;                // deployment envelope (training: +-0.8)
    float wz_limit = 0.f;                 // first flights: yaw disabled
    // Contract constants — hard-validated by load_config against the training
    // contract. Changing any of them without re-training is a new policy.
    float leg_target_cutoff_hz = 10.f;
    float wheel_target_cutoff_hz = 5.f;
    float wheel_radius = .086f;
    float leg_action_scale = .25f;
    float wheel_rate_clamp = 12.f;
    float height = .45f;                  // official stance: wheel contact ~= -0.448
    float wheel_idle_eps = .02f;
    // v4.x wheel-differential contract (load_config hard-checks these).
    float track_width = .44f;             // wheel track width B
    float yaw_efficiency = .415f;         // wheel differential -> yaw efficiency eta
    // NOTE: the armd getup-only Config fields (angle_lower/upper, entry_*,
    // success_*, getup_cap_s, clock_period, leg_target_lowpass_hz) are
    // deliberately absent. The publisher only reads them inside
    // `#if defined(AS2W_POLICY_GETUP1199)` / `AS2W_ARMD_LP5*` blocks, which this
    // candidate never defines; carrying invented defaults would only invite the
    // reader to believe they mean something.
};

Config load_config(const std::filesystem::path& yaml);

class Controller {
public:
    explicit Controller(Config config);
    void arm();
    void stop();
    bool armed() const { return armed_; }
    Targets step(const SensorState& sensors, const Vector3& command, float age_seconds);

    // Diagnostics (--debug CSV path; the publisher requires these two names).
    const Features& last_observation() const { return obs_; }
    const Motors& last_raw_action() const { return last_raw_; }   // unclipped, 12 used
    const Config& config() const { return config_; }
    // Contract-filter coefficients, derived from the YAML cut-offs so the
    // offline audit can assert them against the training values.
    float leg_alpha() const { return leg_alpha_; }
    float wheel_alpha() const { return wheel_alpha_; }
    // v4.x diagnostics: last clamped wheel command before the 5 Hz filter (golden check).
    const std::array<float, 4>& last_wheel_cmd() const { return last_wheel_cmd_; }

private:
    Config config_;
    isaaclab::OrtRunner runner_;
    bool armed_ = false;
    Motors target_leg_{};                 // rad offset from defaults (12 used)
    std::array<float, 4> target_wheel_{};
    Features obs_{};
    Motors last_raw_{};
    std::array<float, 4> last_wheel_cmd_{};
    float leg_alpha_ = 0.f;
    float wheel_alpha_ = 0.f;
};

}  // namespace as2w_unitree58v4
