# Logs

- `referenced_A_ctest.log` / `referenced_A_offline_audit.stdout`：A 基线部署的参考日志，**不是 A_400 目标机审计**。
- A_400 的 `--offline-audit` 必须在目标 CPRO 上由 `install_a400_cpro.sh` 生成：
  `deployment/logs/offline_audit_a400_installed.stdout`
- 打包时 HDC/CPRO 掉线，A_400 目标机 audit 状态为 **PENDING**；只有看到 `AUDIT PASS` 才继续。
- 若 audit 失败，保留 stdout/stderr 和 `sha256sum` 输出，不要启动 publisher。
