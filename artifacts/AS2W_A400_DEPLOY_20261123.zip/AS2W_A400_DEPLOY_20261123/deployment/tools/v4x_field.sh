#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
cd "$ROOT"
case "${1:-status}" in
  status)
    echo "candidate=A; onnx=$(sha256sum models/unitree58-v4x/policy.onnx | cut -d' ' -f1)"
    echo "LOWCMD_PUBLISHED=false; publisher_started=false"
    ;;
  audit)
    exec ./build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish \
      models/unitree58-v4x/deploy.yaml config/unitree58_measured.map --offline-audit
    ;;
  replay)
    exec ./build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_replay \
      models/unitree58-v4x/deploy.yaml "${2:?fixture.txt}"
    ;;
  sha)
    sha256sum models/unitree58-v4x/policy.onnx models/unitree58-v4x/deploy.yaml \
      config/unitree58_measured.map \
      build-v4x/deploy/robots/as2w/unitree58v4/as2w_unitree58v4_lp5_publish
    ;;
  *) echo "usage: $0 status|audit|replay <fixture>|sha"; exit 2 ;;
esac
