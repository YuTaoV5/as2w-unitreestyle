#!/bin/bash
set -euo pipefail
cd /root/as2w_deploy
echo "=== before ==="
timeout 8 ./build-sdk2/as2w_sdk2 motion-mode eth0 2>&1 | head -10 || true
echo "=== select ai ==="
timeout 15 ./build-sdk2/as2w_sdk2 motion-select eth0 ai 2>&1 | head -30 || echo "motion-select rc=$?"
echo "=== after ==="
timeout 8 ./build-sdk2/as2w_sdk2 motion-mode eth0 2>&1 | head -10 || true
timeout 6 ./build-sdk2/as2w_sdk2 sport-state eth0 2 2>&1 | head -6 || true
