#!/bin/bash
# Roll back to the A baseline policy shipped in deployment/rollback_A/.
# Only swaps the model; run offline audit afterwards. Never publishes.
set -euo pipefail
ROOT=${ROOT:-/root/as2w_deploy_a400_s42_400}
cd "$ROOT"
cp models/unitree58-v4x/policy.onnx models/unitree58-v4x/policy.a400_s42_400.onnx
cp rollback_A/policy.onnx models/unitree58-v4x/policy.onnx
cp rollback_A/deploy.yaml models/unitree58-v4x/deploy.yaml
./bin/as2w_unitree58v4_lp5_publish \
  models/unitree58-v4x/deploy.yaml config/unitree58_measured.map --offline-audit
echo "ROLLBACK_A_OK; restore A400 with: cp models/unitree58-v4x/policy.a400_s42_400.onnx models/unitree58-v4x/policy.onnx"
