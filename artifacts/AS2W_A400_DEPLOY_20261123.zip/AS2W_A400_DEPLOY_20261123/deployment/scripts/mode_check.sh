#!/bin/bash
set -euo pipefail
cd /root/as2w_deploy
echo "=== motion-mode ==="
timeout 10 ./build-sdk2/as2w_sdk2 motion-mode eth0 2>&1 | head -20 || echo "motion-mode rc=$?"
echo "=== sport-state ==="
timeout 10 ./build-sdk2/as2w_sdk2 sport-state eth0 2 2>&1 | head -20 || echo "sport-state rc=$?"
echo "=== low-state brief ==="
timeout 8 ./build-sdk2/as2w_sdk2 low-state eth0 rt/lowstate 2 2>&1 | head -12 || echo "low-state rc=$?"
echo "=== service-list ==="
timeout 10 ./build-sdk2/as2w_sdk2 service-list eth0 2>&1 | head -40 || true
