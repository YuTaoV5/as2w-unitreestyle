#!/bin/bash
set -euo pipefail
cd /root/as2w_deploy
echo "=== motion-mode ==="
timeout 10 ./build-sdk2/as2w_sdk2 motion-mode eth0 2>&1 | head -20 || true
echo "=== low-state brief ==="
timeout 6 ./build-sdk2/as2w_sdk2 low-state eth0 rt/lowstate 2 2>&1 | head -12 || true
echo "=== field files ==="
ls -l /root/as2w_deploy_v4x/field_zero_b_20261123
echo "=== publisher tail ==="
tail -30 /root/as2w_deploy_v4x/field_zero_b_20261123/publisher.log
echo "=== lowcmd header/tail ==="
head -2 /root/as2w_deploy_v4x/field_zero_b_20261123/debug_lowcmd.csv
tail -2 /root/as2w_deploy_v4x/field_zero_b_20261123/debug_lowcmd.csv
echo "=== sha ==="
sha256sum /root/as2w_deploy_v4x/field_zero_b_20261123/*
