#!/bin/bash
# Install the A400_s42_400 AS2-W ARM64 deployment into a new CPRO rootfs directory.
# Read-only install + offline audit only. This script NEVER starts the publisher.
set -euo pipefail
PKG=$(cd "$(dirname "$0")/../.." && pwd)
DEST=${1:-/root/as2w_deploy_a400_s42_400}
echo "PKG=$PKG"
echo "DEST=$DEST"
cd "$PKG"
# 1) verify archive integrity before touching the target
sha256sum -c SHA256SUMS
# 2) stage deployment
rm -rf "$DEST"
mkdir -p "$DEST"
cp -a deployment/bin "$DEST/"
cp -a deployment/models "$DEST/"
cp -a deployment/config "$DEST/"
cp -a deployment/source "$DEST/"
cp -a deployment/scripts "$DEST/"
cp -a deployment/tools "$DEST/"
cp -a deployment/manifest "$DEST/"
cp -a deployment/rollback_A "$DEST/"
cp -a deployment/logs "$DEST/" 2>/dev/null || true
chmod +x "$DEST/bin/"* "$DEST/tools/"* "$DEST/scripts/"*.sh 2>/dev/null || true
# 3) verify identity, never publish
cd "$DEST"
echo "=== identity ==="
sha256sum bin/as2w_unitree58v4_lp5_publish bin/as2w_unitree58v4_lp5_replay \
  models/unitree58-v4x/policy.onnx models/unitree58-v4x/deploy.yaml config/unitree58_measured.map
echo "=== offline audit (must PASS; no LowCmd) ==="
./bin/as2w_unitree58v4_lp5_publish \
  models/unitree58-v4x/deploy.yaml config/unitree58_measured.map --offline-audit \
  | tee logs/offline_audit_a400_installed.stdout
echo "INSTALL_OK dest=$DEST"
echo "Next (operator only): ReleaseMode then run scripts/run_zero_b_guarded_a400.sh"
