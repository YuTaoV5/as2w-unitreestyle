# CPRO 部署步骤（C1_s42_200）

## 0. 前置
- CPRO：HarmonyOS host + Ubuntu 22.04 rootfs；USB HDC `0123456789ABCDEF`。
- 机器人 eth0 在 `192.168.123.0/24`；DDS `rt/lowstate` / `rt/lowcmd`。
- 现有 SDK2 工具：`/root/as2w_deploy/build-sdk2/as2w_sdk2`（motion-mode / motion-release / motion-select / low-state）。
- 现场急停/吊装/看护到位；**不要在 ai 模式下起 publisher**。

## 1. 传包/解压/校验
```bash
hdc file send AS2W_C1_s42_200_DEPLOY_20261123.zip /data/local/tmp/
cd /data/local/tmp
unzip -o AS2W_C1_s42_200_DEPLOY_20261123.zip
cd AS2W_C1_s42_200_DEPLOY_20261123
sha256sum -c SHA256SUMS
```
必须全 OK；任一 FAIL 停止。

## 2. 安装到独立目录（不覆盖 A）
```bash
cd /data/local/tmp
bash AS2W_C1_s42_200_DEPLOY_20261123/deployment/scripts/install_c1_cpro.sh /root/as2w_deploy_c1_s42_200
```
脚本会：
1. 校验 SHA；
2. 复制到 `/root/as2w_deploy_c1_s42_200`；
3. 跑 `as2w_unitree58v4_lp5_publish --offline-audit`；
4. **不启动 publisher、不发 LowCmd**。

只有看到最终 `AUDIT PASS` 才能继续；否则停止并保留日志。

## 3. 只读预检
```bash
cd /root/as2w_deploy_c1_s42_200
sha256sum bin/as2w_unitree58v4_lp5_publish models/unitree58-v4x/policy.onnx
ip -br addr | grep eth0          # 必须 UP
timeout 8 /root/as2w_deploy/build-sdk2/as2w_sdk2 low-state eth0 rt/lowstate 2 | head -2
timeout 8 /root/as2w_deploy/build-sdk2/as2w_sdk2 motion-mode eth0
```
- 必须 `name=ai`、LowState 有包、eth0 UP；没有 active publisher。

## 4. zero-B（现场授权后）
```bash
# 由现场操作员执行一次 ReleaseMode；随后 motion-mode name= 空
cd /root/as2w_deploy_c1_s42_200
bash scripts/run_zero_b_guarded_c1.sh
```
流程：guarded preflight → publisher 等 A（30s hold 内 B）→ zero-B → Brake/ReturnStand/Y squat。
- B 被拒/Emergency：立即 X；publisher 停止后 `motion-select ai`。
- 退出脚本会自动尝试 `motion-select ai`；仍要人工确认。

## 5. 回滚 A
```bash
cd /root/as2w_deploy_c1_s42_200
bash scripts/rollback_A.sh
```
回滚后同样只读 audit，不自动发布。

## 6. 常见失败
| 现象 | 原因/处理 |
|---|---|
| `sha256sum -c` FAIL | 包损坏/传输不完整；重传，不继续 |
| `AUDIT PASS` 未出现 | 模型/配置/map 不匹配；停止，保留 `deployment/logs` |
| `ABORT: eth0 DOWN` | 检查 PC1/网线/机器人上电 |
| `ABORT: no LowState` | DDS 未就绪；不要发 LowCmd |
| `ABORT: motion mode 'ai'` | 还在 ai；先 ReleaseMode，不能跳过 |
| FOC acknowledgement timeout | publisher fail-closed 停止；恢复 ai，查链路/上电 |
