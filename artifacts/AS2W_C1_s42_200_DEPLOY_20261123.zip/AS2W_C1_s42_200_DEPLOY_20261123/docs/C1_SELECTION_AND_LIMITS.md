# C1_s42_200 选择依据与限制

## 选择
- 来源：DR3C 修正 C1 sampler，seed42，resume A（DR2b seed42 model_799），200 步；checkpoint `model_199.pt`。
- 在 20 s 同场景筛选中，C1_s42_200 相比 A/B/DR3a/T3/T4/cshort50：
  - 前轮距最小保持、轮间最小距、hip 误差、tilt 综合最佳；
  - 优于 A：前轮距最小 +87%，轮间最小距 +37%，hipErr −23%，tilt95 −3.6°；
  - DR3a support4 最高但 tilt 23.7°/z 0.330（低趴换支撑），姿态更差，不选；
- 60 s 全范围仿真：
  - 0 fall / 0 非轮身触地 / 0 命令越界 / 0 帧 τ>0.8×effort；
  - fwd/rev/vy/wz 均响应；
  - **但最激进段轮距/轴距仍收缩**（wb 74.8%、trackF 38.7%、trackR 54.8%、minPair 39.0%）；
  - support4 67.9%，不是四轮稳定姿态；
  - exact mixed (0.4,0.25,−0.3) 仍会倒，仿真使用 mixed_safe (0.4,0.10,−0.3)。

## 不构成放行
- 仅 MuJoCo；C1 没有实机数据；
- 未完成 CPRO C1 C++ audit（打包时 HDC 掉线）；安装脚本会自动跑；
- 未完成 zero-B / B gate / policy handoff 实机验证；
- 未 owner 最终放行。

## 已修正/已包含
- hip map `sign=+1`（官方 raw FR/RR +0.15、FL/RL −0.15）；
- FixedStand 目标 200/4，策略段 55/2；
- 起身序列：先抬膝避碰 → 收髋 → 伸腿 3 s → hold 200/4 → 切 55/2；
- 训练资产含 C1 checkpoint、export 脚本、run/resolved config、C1 sampler patch、eval 日志、选择 evidence。

## 禁止
- 用 C1 包直接跳过 ReleaseMode/guard；
- 在 ai 模式下并发 publisher；
- 把 `--b-gate-pose` 放宽、或把 200/4 带进策略阶段；
- 把仿真 report 写成实机通过。
