# 训练来源与资产说明

## 来源链
- 父权重：A / DR2b seed42 final `model_799.pt`
- C1 run：`/root/gpufree-data/as2w-runs/retrain-dr3c-20261122/c1_s42`
- 训练轮数：200；导出 checkpoint：`model_199.pt`
- C1 修正：C1 sampler（恒速低速保持 vx、仅 decel 减速、直行只写 vx；详见 `training/source/patch_dr3c_sampler.py`）
- Seed 42；policy_dt 0.02；58 obs / 12 act；腿 55/2；轮 vx/wz 差速合同。

## 训练资产
| 文件 | 用途 |
|---|---|
| `training/checkpoints/c1_s42_model_199.pt` | C1 原始 checkpoint（4.7 MB） |
| `training/configs/c1_s42_run.json` | 训练启动配置/父权重/资产 SHA |
| `training/configs/c1_s42_resolved_config.json` | 完整 resolved 配置 |
| `training/configs/c1_s42_best.json` / `c1_domain_config.json` | best/域配置 |
| `training/source/task.py` / `environment.py` / `control.toml` | 训练合同（obs/action/wheel） |
| `training/source/patch_dr3c_sampler.py` | C1 sampler 修正 |
| `training/source/smoke_c1_commands.py` | C1 命令 smoke |
| `training/source/eval_special_dr3c.py` | DR3C 评估 |
| `training/export/export_onnx.py` | ONNX 导出（内嵌 tanh；obs58/act12） |
| `training/export/parity_v4x.py` | Python 合同/ONNX 参考 |
| `training/export/c1_s42_200.export.json` | 导出 SHA/parity |
| `training/evidence/*` | C1 eval 日志、选择/姿态对比 |

## 导出复现
```bash
python export_onnx.py c1_s42_model_199.pt policy.onnx
```
预期：
- ckpt_sha256 `572898f0…`
- onnx_sha256 `e5e81fe0…`
- tanh_baked true
- torch↔ORT max abs err 4.77e-6

## 说明
- 仓库 `training/source` 是 checkpoint 的 source snapshot 子集，不是完整训练仓库；完整复现需原训练环境。
- C1 的选择依据是 MuJoCo 姿态对比，不是训练 reward 单指标；不要用它声称“最佳策略”。
