# Logs

- `referenced_A_ctest.log` / `referenced_A_offline_audit.stdout`：A 基线部署的参考日志，不是 C1 目标机审计。
- C1 的 `--offline-audit` 必须在目标 CPRO 上由 `install_c1_cpro.sh` 生成：
  `deployment/logs/offline_audit_c1_installed.stdout`
- 打包时 HDC/CPRO 掉线，C1 目标机 audit 状态为 **PENDING**；只有看到 `AUDIT PASS` 才继续。
- 若 audit 失败，保留 stdout/stderr 和 `sha256sum` 输出，不要启动 publisher。
