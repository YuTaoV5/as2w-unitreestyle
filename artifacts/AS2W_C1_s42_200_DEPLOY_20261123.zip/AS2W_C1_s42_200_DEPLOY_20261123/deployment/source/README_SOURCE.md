# 源码说明

- 本目录是 A/v4x publisher 源码快照，已包含：
  - FixedStand/ReturnStand `stand_kp/stand_kd` 显式传参；
  - FixStand 起末段统一 200/4；
  - wheel stand kd 0.5；
  - 策略阶段 55/2 的部署合同。
- 二进制 `deployment/bin/as2w_unitree58v4_lp5_publish` 是交付权威；源码用于审阅/重建。
- 构建需要 CPRO 原生 ARM64 工具链 + ONNX Runtime + unitree SDK；不要把 x86 binary 放进 CPRO。
- 本包未包含 SDK2 工具；目标机已有 `/root/as2w_deploy/build-sdk2/as2w_sdk2`。
- `map` 的 hip `sign=+1` 与官方 raw q（FR/RR +0.15、FL/RL −0.15）一致；不要改回 `-1`。
- 修改源码后必须重跑 CTest + offline audit，再更新 manifest/SHA；不要把未 audit 的 binary 发出。
