#!/bin/bash
# Guarded zero-B launcher for the C1_s42_200 package.
# Preconditions: operator has already run ONE MotionSwitcher ReleaseMode.
# It refuses to publish under ai, or if another publisher/lock exists.
# After publisher exits it calls SelectMode("ai").
set -euo pipefail
ROOT=${ROOT:-/root/as2w_deploy_c1_s42_200}
D=${1:-$ROOT/field_zero_b_c1}
mkdir -p "$D"
LOCK=$ROOT/field_lowcmd.lock
if ! mkdir "$LOCK" 2>/dev/null; then
  if [ -f "$LOCK/pid" ] && kill -0 "$(cat "$LOCK/pid")" 2>/dev/null; then
    echo "ABORT: existing publisher lock pid=$(cat "$LOCK/pid")" | tee -a "$D/preflight.log"; exit 10
  fi
  rm -rf "$LOCK"; mkdir "$LOCK"
fi
echo $$ > "$LOCK/pid"
cleanup(){ rm -rf "$LOCK"; }
trap cleanup EXIT
if pgrep -f '^/root/as2w_deploy_c1_s42_200/bin/as2w_unitree58v4_lp5_publish' >/dev/null 2>&1; then
  echo "ABORT: existing C1 publisher" | tee -a "$D/preflight.log"; exit 11
fi
ip link show eth0 2>/dev/null | grep -q 'state UP' || { echo "ABORT: eth0 DOWN" | tee -a "$D/preflight.log"; exit 12; }
if ! timeout 8 /root/as2w_deploy/build-sdk2/as2w_sdk2 low-state eth0 rt/lowstate 2 2>&1 | grep -q 'low packets=[1-9]'; then
  echo "ABORT: no LowState" | tee -a "$D/preflight.log"; exit 13
fi
name=$(timeout 8 /root/as2w_deploy/build-sdk2/as2w_sdk2 motion-mode eth0 2>&1 | sed -n 's/.*name=//p' | head -1)
if [ -n "$name" ]; then
  echo "ABORT: motion mode '$name' is not released; run ReleaseMode first" | tee -a "$D/preflight.log"; exit 14
fi
echo "PREFLIGHT_OK eth0=UP lowstate=OK mode=released" | tee -a "$D/preflight.log"
cd "$D"
printf 'GO\n' | "$ROOT/bin/as2w_unitree58v4_lp5_publish" \
  "$ROOT/models/unitree58-v4x/deploy.yaml" "$ROOT/config/unitree58_measured.map" eth0 \
  --i-confirm-lowcmd-publish --zero-b-trial --stand t2 \
  --interp-sec 3 --squat-sec 4 --stand-hold-seconds 30 --startup-wait-sec 180 \
  --vx-limit 0.10 --vy-limit 0.0 --wz-limit 0.10 \
  --stand-kp 200 --stand-kd 4 --debug > publisher.log 2>&1 || true
echo "PUBLISHER_RC=$?" >> publisher.log
rm -rf "$LOCK"
cd /root/as2w_deploy
/root/as2w_deploy/build-sdk2/as2w_sdk2 motion-select eth0 ai > "$D/restore_ai.log" 2>&1 || true
echo DONE >> "$D/publisher.log"
