#!/usr/bin/env python3
"""DR3c special 200-update evaluation protocol (zero-command 30 s + low-speed six bins).

Read-only evaluation of a checkpoint; does not touch training/deploy package.
Uses the same Isaac Lab env/build path as evaluate.py (flat terrain, DR0, obs0,
exec0) and the same controller contract.

Outputs <outdir>/special_<scene>.json + trials.csv + summary.csv with
continue_training/promotable fields (fail-closed semantics: ABORT on invalid
inputs/trials). Zero-command gates and low-speed gates are reported per trial,
median/worst/collapse; tilt max reported but tilt p95 is the gate.
"""
import argparse
import csv
import json
import math
import pathlib
import sys
import traceback

from isaaclab.app import AppLauncher

WHEELS = ("FL", "FR", "RL", "RR")
TRIALS = 6
ZERO_WARMUP_S = 2.0
ZERO_MEASURE_S = 30.0
LOW_BINS = (0.05, -0.05, 0.10, -0.10, 0.15, -0.15)
LOW_BIN_S = 8.0


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--ckpt", type=pathlib.Path, required=True)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--outdir", type=pathlib.Path, required=True)
    p.add_argument("--engine", choices=("isaac",), default="isaac")
    p.add_argument("--quick", action="store_true", help="1 trial/bin smoke mode")
    p.add_argument("--trials", type=int, default=TRIALS)
    p.add_argument("--terrain", default="flat")
    p.add_argument("--dr-level", type=int, default=0)
    p.add_argument("--ground-friction", type=float, default=0.35)
    p.add_argument("--asset", type=pathlib.Path,
                   default=pathlib.Path("/root/as2w/assets/generated/as2w/as2w.usda"))
    p.add_argument("--reward-config", type=pathlib.Path,
                   default=None)
    p.add_argument("--max-attempts", type=int, default=40)
    return p.parse_args()


def build_raw(args, num_envs):
    import task as task_mod

    class A:
        pass
    a = A()
    a.out = args.outdir
    a.asset = args.asset
    a.terrain = args.terrain
    a.num_envs = num_envs
    a.dr_level = args.dr_level
    a.seed = args.seed
    a.wheel_diff = True
    a.ground_friction = args.ground_friction
    a.reward_config = args.reward_config or pathlib.Path(task_mod.__file__).with_name(
        "reward_config_wheeldiff_v41.json")
    a.obs_delay = 0
    a.command_hold_s = 2.5
    a.gait_phase = False
    a.gait_period_s = 1.0
    a.step_only = False
    a.right_only = False
    a.delay_ticks = None
    a.eval_delay_ticks = None
    a.eval_obs_delay_ticks = None
    a.cmd_scale = 1.0
    raw = task_mod.build_task(a)
    raw.cfg.episode_length_s = 60.0
    try:
        raw.max_episode_length = int(round(60.0 / raw.step_dt))
    except Exception:
        pass
    return raw


def make_policy(raw, ckpt):
    from tensordict import TensorDict
    from isaaclab_rl.rsl_rl import (RslRlVecEnvWrapper, create_rsl_rl_runner,
                                    check_rsl_rl_version, handle_deprecated_rsl_rl_cfg)
    from isaaclab_tasks.core.velocity.config.go2.agents.rsl_rl_ppo_cfg import UnitreeGo2RoughPPORunnerCfg
    config = UnitreeGo2RoughPPORunnerCfg()
    config.device = raw.device
    config.num_steps_per_env = 1
    config.obs_groups = {"actor": ["policy"], "critic": ["critic"]}
    config = handle_deprecated_rsl_rl_cfg(config, check_rsl_rl_version())
    runner = create_rsl_rl_runner(RslRlVecEnvWrapper(raw), config, log_dir=None)
    runner.load(str(ckpt), load_cfg={"actor": True, "critic": True})
    model = runner.get_inference_policy()

    def policy(obs):
        return model(TensorDict(obs, batch_size=[raw.num_envs], device=raw.device))
    return policy


class Snapshot:
    """Per-step recorder of the quantities needed by the special protocol."""

    def __init__(self, raw, n):
        self.raw = raw
        self.n = n
        d = raw.robot.data
        from environment import tensor
        self._t = tensor
        contact = raw.scene["contacts"]
        self.feet = [contact.body_names.index(name) for name in ("FL_foot", "FR_foot", "RL_foot", "RR_foot")]
        self.wheel_ids = raw.wheel_ids
        self.steps = []

    def record(self):
        t = self._t
        d = self.raw.robot.data
        pos = t(d.root_pos_w)[:, :3].detach().cpu().numpy().copy()
        quat = t(d.root_quat_w).detach().cpu().numpy().copy()  # xyzw
        q = t(d.joint_pos)[:, self.wheel_ids].detach().cpu().numpy().copy()
        dq = t(d.joint_vel)[:, self.wheel_ids].detach().cpu().numpy().copy()
        g = t(d.projected_gravity_b)
        tilt = torch.rad2deg(torch.acos((-g[:, 2]).clamp(-1, 1))).detach().cpu().numpy().copy()
        vx = t(d.root_lin_vel_b)[:, 0].detach().cpu().numpy().copy()
        contact = self.raw.scene["contacts"]
        force = contact.data.net_normal_forces_w.norm(dim=-1)
        loads = force[:, self.feet].detach().cpu().numpy().copy()
        self.steps.append({"pos": pos, "quat": quat, "q": q, "dq": dq,
                           "tilt": tilt, "vx": vx, "loads": loads})


def arrays_from_steps(steps):
    out = {}
    for k in ("pos", "quat", "q", "dq", "tilt", "vx", "loads"):
        out[k] = np.stack([s[k] for s in steps], axis=0)  # (T, N, ...)
    return out


def yaw_from_quat_xyzw(q):
    x, y, z, w = q[..., 0], q[..., 1], q[..., 2], q[..., 3]
    return np.arctan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))


def summarize_zero(trials):
    rows = []
    for tr in trials:
        a = tr["arrays"]
        m = a["pos"][100:1600]
        p0 = np.median(a["pos"][100:150], axis=0)
        mid = np.median(a["pos"][300:350], axis=0)
        end = np.median(a["pos"][1550:1600], axis=0)
        xy = m[:, :2]
        xy_end = float(np.linalg.norm(end[:2] - p0[:2]))
        xy_max = float(np.max(np.linalg.norm(xy - p0[:2], axis=-1)))
        yaw = np.unwrap(yaw_from_quat_xyzw(a["quat"][:, :]))
        yaw0 = np.median(yaw[100:150], axis=0)
        yaw_end = np.median(yaw[1550:1600], axis=0)
        dyaw = float(np.max(np.abs(yaw_end - yaw0)))
        q0 = np.median(a["q"][100:150], axis=0)
        qe = np.median(a["q"][1550:1600], axis=0)
        dq_wheel = qe - q0
        wheel_max = float(np.max(np.abs(dq_wheel)))
        wheel_abs_sum = float(np.sum(np.abs(dq_wheel)))
        support = float(np.mean((a["loads"][100:1600] >= 3.0).all(axis=-1)))
        h0 = float(np.median(a["pos"][100:150, 2]))
        hmid = float(np.median(a["pos"][300:350, 2]))
        hend = float(np.median(a["pos"][1550:1600, 2]))
        tilt = a["tilt"][100:1600]
        rows.append({"xy_end_m": xy_end, "xy_max_m": xy_max, "dyaw_deg": dyaw,
                     "wheel_max_rad": wheel_max, "wheel_abs_sum_rad": wheel_abs_sum,
                     "support_frac": support,
                     "dz_0_5_cm": (h0 - hmid) * 100.0,
                     "dz_5_30_cm": (hmid - hend) * 100.0,
                     "dz_0_30_cm": (h0 - hend) * 100.0,
                     "tilt_p95_deg": float(np.quantile(tilt, .95)),
                     "tilt_max_deg": float(np.max(tilt)),
                     "falls": int(tr["falls"]), "valid": True})
    return rows


def summarize_low(rows, cmd, bin_name):
    out = []
    for tr in rows:
        a = tr["arrays"]
        T = a["vx"].shape[0]
        steady = slice(50, T)
        v = float(np.mean(a["vx"][steady]))
        ratio = v / cmd if cmd else float("nan")
        err = abs(v - cmd)
        z0 = float(np.median(a["pos"][0:50, 2]))
        ze = float(np.median(a["pos"][T - 50:T, 2]))
        out.append({"bin": bin_name, "cmd_m_s": cmd, "v_meas_m_s": v,
                    "tracking_ratio": ratio, "abs_v_err_m_s": err,
                    "tolerance_m_s": max(0.02, 0.2 * abs(cmd)),
                    "dz_cm": (z0 - ze) * 100.0,
                    "support_frac": float(np.mean((a["loads"][steady] >= 3.0).all(axis=-1))),
                    "tilt_p95_deg": float(np.quantile(a["tilt"][steady], .95)),
                    "tilt_max_deg": float(np.max(a["tilt"][steady])),
                    "falls": int(tr["falls"])})
    return out


def run_group(raw, policy, command, steps, trials_needed, max_attempts, quick=False):
    """Run attempts until every env slot has `trials_needed` valid trials.

    A trial is INVALID (not merged) if terminated/truncated inside the window;
    invalid_count is tracked separately. Returns (trials, invalid_count, attempts).
    """
    n = command.shape[0]
    valid = [[] for _ in range(n)]
    invalid = 0
    attempts = 0
    torch_cmd = command
    while any(len(v) < trials_needed for v in valid) and attempts < max_attempts:
        attempts += 1
        raw.reset()
        raw.exercise = torch_cmd
        raw.command.copy_(torch_cmd)
        obs = raw._get_observations()
        snap = Snapshot(raw, n)
        fell = np.zeros(n, dtype=bool)
        with torch.inference_mode():
            for i in range(steps):
                act = policy(obs)
                obs, _, term, trunc, _ = raw.step(act)
                snap.record()
                bad = (term | trunc).detach().cpu().numpy().astype(bool)
                fell |= bad
                if quick and i >= 159:
                    # quick smoke only: keep it short but still exercise code paths
                    pass
        arrays = arrays_from_steps(snap.steps)
        for j in range(n):
            if len(valid[j]) >= trials_needed:
                continue
            if fell[j]:
                invalid += 1
                continue
            if quick:
                pass
            valid[j].append({"arrays": {k: v[:, j] for k, v in arrays.items()}, "falls": 0})
    return valid, invalid, attempts


def main():
    args = parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    log = []
    app = None
    raw = None
    try:
        global np, torch
        import numpy as np
        import torch
        from isaaclab.app import AppLauncher
        app = AppLauncher(headless=True).app
        raw = build_raw(args, args.trials if not args.quick else 1)
        policy = make_policy(raw, args.ckpt)
        result = {"ckpt": str(args.ckpt), "seed": args.seed, "engine": "isaac",
                  "dr_level": args.dr_level, "protocol": "DR3c-special-v1",
                  "continue_training": False, "promotable": False, "status": "OK",
                  "zero": None, "low": None}
        # ---------------- A. zero-command 30 s ----------------
        zero_cmd = torch.zeros(raw.num_envs, 3, device=raw.device)
        steps = int((ZERO_WARMUP_S + ZERO_MEASURE_S) / raw.step_dt)
        trials, invalid, attempts = run_group(raw, policy, zero_cmd, steps,
                                             args.trials, args.max_attempts, args.quick)
        zero_rows = []
        for slot in trials:
            for tr in slot:
                zero_rows += summarize_zero([{"arrays": tr["arrays"], "falls": tr["falls"]}])
        zg = args.cfg_zero = {"falls_max": 0, "dz_5_30_max_cm": 0.20, "xy_max_cm": 5.0,
                              "dyaw_max_deg": 3.0, "wheel_max_rad": 0.20,
                              "support_min": 0.95, "tilt_p95_max_deg": 4.0}
        def med(vals):
            return float(np.median(vals)) if vals else None
        def worst(vals):
            return float(np.min(vals)) if vals else None
        zero_pass = bool(zero_rows) and all(
            r["falls"] == 0 and r["dz_5_30_cm"] <= zg["dz_5_30_max_cm"]
            and r["xy_max_m"] * 100 <= zg["xy_max_cm"] and r["dyaw_deg"] <= zg["dyaw_max_deg"]
            and r["wheel_max_rad"] <= zg["wheel_max_rad"] and r["support_frac"] >= zg["support_min"]
            and r["tilt_p95_deg"] <= zg["tilt_p95_max_deg"] for r in zero_rows)
        result["zero"] = {"rows": zero_rows, "invalid_trials": invalid,
                          "attempts": attempts, "gates": zg, "pass": zero_pass,
                          "median": {k: med([r[k] for r in zero_rows]) for k in
                                     ("xy_max_m", "dyaw_deg", "wheel_max_rad", "support_frac",
                                      "dz_5_30_cm", "tilt_p95_deg")},
                          "worst": {k: max([r[k] for r in zero_rows]) for k in
                                    ("xy_max_m", "dyaw_deg", "wheel_max_rad", "dz_5_30_cm",
                                     "tilt_p95_deg")}}
        # ---------------- B. low-speed six bins ----------------
        n = raw.num_envs
        low_rows = []
        if args.quick:
            bins = (0.05,)
        else:
            bins = LOW_BINS
        # rebuild env if quick used 1 env but full protocol needs 6 envs: handled by caller using --trials
        for cmd in bins:
            m = args.trials
            if n < m:
                log.append(f"skip bin {cmd}: env count {n} < trials {m}")
                continue
            cmd_t = torch.zeros(n, 3, device=raw.device)
            cmd_t[:, 0] = float(cmd)
            steps_low = int(LOW_BIN_S / raw.step_dt)
            if args.quick:
                steps_low = 200
            trials_l, invalid_l, attempts_l = run_group(raw, policy, cmd_t, steps_low, m,
                                                        args.max_attempts, args.quick)
            for slot in trials_l[:m]:
                for tr in slot:
                    arr = tr["arrays"]
                    a = {k: arr[k] for k in arr}
                    low_rows += summarize_low([{"arrays": a, "falls": tr["falls"]}], float(cmd),
                                              f"{cmd:+.2f}")
        low_gates = {"ratio_min": 0.80, "ratio_max": 1.20, "support_min": 0.90,
                     "falls_max": 0}
        low_pass = bool(low_rows) and all(
            r["falls"] == 0 and low_gates["ratio_min"] <= r["tracking_ratio"] <= low_gates["ratio_max"]
            and r["abs_v_err_m_s"] <= r["tolerance_m_s"] + 1e-9
            and r["support_frac"] >= low_gates["support_min"] for r in low_rows)
        result["low"] = {"rows": low_rows, "gates": low_gates, "pass": low_pass}
        result["continue_training"] = bool(zero_pass and low_pass)
        result["promotable"] = bool(zero_pass and low_pass)
        result["status"] = "OK"
        (args.outdir / "special.json").write_text(json.dumps(result, indent=1) + "\n")
        with (args.outdir / "trials.csv").open("w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["scene", "bin", "metric", "value"])
            for r in zero_rows:
                for k, v in r.items():
                    w.writerow(["zero", "", k, v])
            for r in low_rows:
                for k, v in r.items():
                    w.writerow(["low", r["bin"], k, v])
        print("DR3C_SPECIAL_OK", args.outdir, "zero_pass", zero_pass, "low_pass", low_pass,
              "zero_rows", len(zero_rows), "low_rows", len(low_rows), flush=True)
    except Exception:
        traceback.print_exc()
        try:
            (args.outdir / "special.json").write_text(json.dumps(
                {"status": "ABORT", "reason": "EXCEPTION",
                 "continue_training": False, "promotable": False}, indent=1) + "\n")
        except Exception:
            pass
        raise
    finally:
        if raw is not None:
            try:
                raw.close()
            except Exception:
                pass
        if app is not None:
            try:
                app.close()
            except Exception:
                pass


if __name__ == "__main__":
    main()
