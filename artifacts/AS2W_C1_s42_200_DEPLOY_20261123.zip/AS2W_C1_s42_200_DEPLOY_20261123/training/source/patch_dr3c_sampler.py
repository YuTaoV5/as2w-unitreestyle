"""Patch the DR3c workspace copy: C0/C1 command samplers + fail-closed tilt schema.

Applied on the server inside /root/as2w/retrain-wheeldiff-dr3c-20261122/src.
No change to DR3b workspace, deploy package, or old Gate v2.
"""
import json
import pathlib

SRC = pathlib.Path("/root/as2w/retrain-wheeldiff-dr3c-20261122/src")


def patch(rel, old, new, tag):
    p = SRC / rel
    t = p.read_text(encoding="utf-8")
    if new in t and old not in t:
        print(f"[{tag}] already patched")
        return
    assert old in t, f"[{tag}] anchor missing in {rel}"
    p.write_text(t.replace(old, new, 1), encoding="utf-8")
    print(f"[{tag}] patched {rel}")


# ---------------- environment.py: C1 tick / reset branch ----------------
patch("environment.py",
      '''        interval = round(getattr(self, "command_hold_s", 2.5) / self.step_dt)
        env_ids = (self.episode_length_buf.remainder(interval) == 0).nonzero(as_tuple=True)[0]
        self._sample_commands(env_ids)''',
      '''        interval = round(getattr(self, "command_hold_s", 2.5) / self.step_dt)
        if getattr(self, "cmd_sampler", "c0") == "c1":
            self._c1_tick()
        else:
            env_ids = (self.episode_length_buf.remainder(interval) == 0).nonzero(as_tuple=True)[0]
            self._sample_commands(env_ids)''',
      "env-prepysics-c1")
patch("environment.py",
      "        self.previous_delta[env_ids] = 0.\n        self._sample_commands(env_ids)",
      "        self.previous_delta[env_ids] = 0.\n        if getattr(self, \"cmd_sampler\", \"c0\") == \"c1\":\n            self._c1_assign(env_ids)\n        else:\n            self._sample_commands(env_ids)",
      "env-reset-c1")

# ---------------- task.py: C1 sampler implementation ----------------
c1_methods = '''
        # ===== DR3c C1 command sampler (episode-level S/Z/L/F/Y modes) =====
        # S 15% long stand (12 s zero), Z 15% motion->zero (0.5 s decel),
        # L 20% six low-speed bins (each 3.33%), F 35% v4.1 main distribution,
        # Y 15% yaw/arc library. exec delay 0 for C0/C1; no reward change.
        def _c1_init(self):
            if hasattr(self, "c1_mode"):
                return
            dev = self.device
            n = self.num_envs
            self.c1_mode = torch.full((n,), -1, dtype=torch.long, device=dev)
            self.c1_vx = torch.zeros(n, device=dev)
            self.c1_t_decel_end = torch.full((n,), -1.0, device=dev)
            self.c1_episode_len = float(getattr(self.cfg, "episode_length_s", 12.0))
            self.c1_counts = torch.zeros(5, dtype=torch.long, device=dev)
            self.c1_bin_counts = torch.zeros(6, dtype=torch.long, device=dev)
            self.c1_total = 0
            self.c1_last_log = 0

        def _c1_log(self):
            tot = int(self.c1_counts.sum())
            if tot == 0:
                return
            shares = {k: round(float(self.c1_counts[i]) / tot * 100, 2)
                      for i, k in enumerate(("S", "Z", "L", "F", "Y"))}
            bins = {}
            if float(self.c1_bin_counts.sum()) > 0:
                bc = self.c1_bin_counts.float() / self.c1_bin_counts.sum()
                bins = {k: round(float(bc[i]) * 100, 2) for i, k in enumerate(("p05", "m05", "p10", "m10", "p15", "m15"))}
            dec = self.c1_t_decel_end[self.c1_t_decel_end >= 0]
            print("AS2W_CMD_SHARE", {"total": tot, "share_pct": shares,
                                     "L_bin_share_of_L_pct": bins,
                                     "t_decel_end_envs": int(dec.numel()),
                                     "t_decel_end_sample": [round(float(x), 2) for x in dec[:8]]},
                  flush=True)

        def _c1_assign(self, ids):
            self._c1_init()
            n = ids.numel()
            dev = self.device
            r = torch.rand(n, device=dev)
            mode = torch.where(r < .15, torch.zeros_like(r, dtype=torch.long),
                    torch.where(r < .30, torch.ones_like(r, dtype=torch.long),
                    torch.where(r < .50, torch.full_like(r, 2, dtype=torch.long),
                    torch.where(r < .85, torch.full_like(r, 3, dtype=torch.long),
                                torch.full_like(r, 4, dtype=torch.long)))))
            self.c1_mode[ids] = mode
            self.c1_counts += torch.bincount(mode, minlength=5)
            self.c1_vx[ids] = 0.
            self.c1_t_decel_end[ids] = -1.
            cmd = torch.zeros(n, 3, device=dev)
            # Z: vx in +-{.05,.10,.15}, T1 in [3,5) s, 0.5 s linear decel to 0
            z = (mode == 1).nonzero(as_tuple=True)[0]
            if z.numel():
                mag = torch.tensor([.05, .10, .15], device=dev)[torch.randint(0, 3, (z.numel(),), device=dev)]
                sign = torch.where(torch.rand(z.numel(), device=dev) < .5, -1., 1.)
                self.c1_vx[ids[z]] = sign * mag
                self.c1_t_decel_end[ids[z]] = 3.0 + torch.rand(z.numel(), device=dev) * 2.0 + .5
            # L: six equal bins; 10% also decelerate over the final 0.5 s
            l = (mode == 2).nonzero(as_tuple=True)[0]
            if l.numel():
                bins = torch.tensor([.05, -.05, .10, -.10, .15, -.15], device=dev)
                bi = torch.randint(0, 6, (l.numel(),), device=dev)
                self.c1_vx[ids[l]] = bins[bi]
                self.c1_bin_counts += torch.bincount(bi, minlength=6)
                dec = torch.rand(l.numel(), device=dev) < .10
                self.c1_t_decel_end[ids[l]] = torch.where(dec, torch.full_like(self.c1_vx[ids[l]], self.c1_episode_len),
                                                          torch.full_like(self.c1_vx[ids[l]], -1.))
            # S: zero; t_decel_end = 0 (already zero command)
            s = (mode == 0).nonzero(as_tuple=True)[0]
            if s.numel():
                self.c1_t_decel_end[ids[s]] = 0.
            # F/Y resample from their libraries now (then every 2.5 s)
            fy = (mode >= 3).nonzero(as_tuple=True)[0]
            if fy.numel():
                cmd[fy] = self._c1_sample_fy(len(fy), mode[fy])
            cmd[mode == 0] = 0.
            cmd[mode == 1] = self.c1_vx[ids][mode == 1].unsqueeze(1)
            cmd[mode == 2] = self.c1_vx[ids][mode == 2].unsqueeze(1)
            self.command[ids] = cmd
            self.c1_total += n
            if self.c1_total - self.c1_last_log >= 4096:
                self.c1_last_log = self.c1_total
                self._c1_log()

        def _c1_sample_fy(self, n, modes):
            dev = self.device
            cmd = torch.zeros(n, 3, device=dev)
            f = (modes == 3).nonzero(as_tuple=True)[0]
            if f.numel():
                m = f.numel()
                r = torch.rand(m, device=dev)
                u = torch.rand(m, 3, device=dev) * 2 - 1
                pure_vx = (r >= .15) & (r < .30)
                pure_vy = (r >= .30) & (r < .45)
                pure_wz = (r >= .45) & (r < .75)
                mixed = r >= .75
                sub = cmd[f]
                sub[pure_vx, 0] = u[pure_vx, 0] * .6
                vy_sign = torch.where(torch.rand(m, device=dev) < .6, -1., 1.)
                vy_mag = .10 + torch.rand(m, device=dev) * .15
                vy_mag = torch.where(torch.rand(m, device=dev) < .2, torch.full_like(vy_mag, .30), vy_mag)
                sub[pure_vy, 1] = (vy_sign * vy_mag)[pure_vy]
                magnitude = .3 + torch.rand(m, device=dev) * .7
                sign = torch.where(torch.rand(m, device=dev) < .5, -1., 1.)
                sub[pure_wz, 2] = (magnitude * sign)[pure_wz]
                sub[mixed, 0] = u[mixed, 0] * .3
                sub[mixed, 1] = u[mixed, 1] * .05
                sub[mixed, 2] = u[mixed, 2] * .6
                cmd[f] = sub
            y = (modes == 4).nonzero(as_tuple=True)[0]
            if y.numel():
                m = y.numel()
                kind = torch.rand(m, device=dev)
                yaw_mag = torch.tensor([.10, .30, .60], device=dev)[torch.randint(0, 3, (m,), device=dev)]
                yaw_sign = torch.where(torch.rand(m, device=dev) < .5, -1., 1.)
                slow_mag = torch.tensor([.10, .26], device=dev)[torch.randint(0, 2, (m,), device=dev)]
                arc_pair = torch.tensor([[.10, .10], [.30, .30], [.40, .40]], device=dev)[torch.randint(0, 3, (m,), device=dev)]
                arc_sign = torch.where(torch.rand(m, device=dev) < .5, -1., 1.)
                cmd[y, 2] = torch.where(kind < .70, yaw_sign * yaw_mag,
                             torch.where(kind < .85, yaw_sign * slow_mag, arc_sign * arc_pair[:, 1]))
                cmd[y, 0] = torch.where(kind >= .85, arc_pair[:, 0], torch.zeros(m, device=dev))
            return cmd

        def _c1_tick(self):
            self._c1_init()
            t = self.episode_length_buf.float() * self.step_dt
            m = self.c1_mode
            n = self.num_envs
            sd = torch.zeros(n, device=self.device)
            zl = (m == 1) | (m == 2)
            if zl.any():
                te = self.c1_t_decel_end
                vx = self.c1_vx
                cur = torch.where(t < te - .5, vx,
                      torch.where(t < te, vx * ((te - t) / .5).clamp(0, 1), torch.zeros_like(vx)))
                sd = torch.where(zl, cur, sd)
            s = m == 0
            sd = torch.where(s, torch.zeros_like(sd), sd)
            # F/Y keep their current commands and resample on the v4.1 2.5 s cadence
            interval = round(float(getattr(self, "command_hold_s", 2.5)) / self.step_dt)
            fy_ids = ((m >= 3) & (self.episode_length_buf.remainder(interval) == 0)).nonzero(as_tuple=True)[0]
            if fy_ids.numel():
                self.command[fy_ids] = self._c1_sample_fy(len(fy_ids), m[fy_ids])
            keep = m >= 3
            self.command[:, 0] = torch.where(keep, self.command[:, 0], sd)
            self.command[:, 1] = torch.where(keep, self.command[:, 1], torch.zeros_like(sd))
            self.command[:, 2] = torch.where(keep, self.command[:, 2], torch.zeros_like(sd))

'''
anchor = "        def _reset_idx(self,ids):\n"
patch("task.py", anchor, c1_methods + anchor, "task-c1-sampler")

# ---------------- run.py: --cmd-sampler + class attr ----------------
patch("run.py",
      'parser.add_argument("--train-from-scratch", action="store_true",',
      'parser.add_argument("--cmd-sampler", choices=("c0", "c1"), default="c0",\n'
      '                    help="C0 = v4.1 legacy sampler; C1 = DR3c S/Z/L/F/Y sampler")\n'
      'parser.add_argument("--train-from-scratch", action="store_true",',
      "run-cmd-sampler-arg")
patch("task.py",
      "    Task.obs_delay_max=int(getattr(args,\"obs_delay\",0) or 0)\n    env=Task(cfg)",
      "    Task.obs_delay_max=int(getattr(args,\"obs_delay\",0) or 0)\n"
      "    Task.cmd_sampler=str(getattr(args,\"cmd_sampler\",\"c0\"))\n    env=Task(cfg)",
      "task-cmd-sampler-attr")

# ---------------- training.py: record cmd_sampler in run.json ----------------
patch("training.py",
      '        "command_hold_s": getattr(args, "command_hold_s", 2.5),',
      '        "command_hold_s": getattr(args, "command_hold_s", 2.5),\n'
      '        "cmd_sampler": getattr(args, "cmd_sampler", "c0"),',
      "training-record-sampler")

# ---------------- task.py: C0 sampling-share logging (verification) ----------------
patch("task.py",
      "            cmd[mixed,2]=u[mixed,2]*.6\n            self.command[ids]=cmd",
      "            cmd[mixed,2]=u[mixed,2]*.6\n"
      "            self.command[ids]=cmd\n"
      "            if not hasattr(self, \"c0_total\"):\n"
      "                self.c0_total = self.c0_zeros = self.c0_vx = self.c0_vy = self.c0_wz = self.c0_mixed = 0\n"
      "                self.c0_last = 0\n"
      "            n0 = len(ids)\n"
      "            self.c0_zeros += int((cmd.abs().sum(1) < 1e-9).sum())\n"
      "            self.c0_vx += int((cmd[:, 0].abs() > 1e-6).sum())\n"
      "            self.c0_vy += int((cmd[:, 1].abs() > 1e-6).sum())\n"
      "            self.c0_wz += int((cmd[:, 2].abs() > 1e-6).sum())\n"
      "            self.c0_mixed += int(((cmd[:, 0].abs() > 1e-6) & (cmd[:, 2].abs() > 1e-6)).sum())\n"
      "            self.c0_total += n0\n"
      "            if self.c0_total - self.c0_last >= 4096:\n"
      "                self.c0_last = self.c0_total\n"
      "                tot = max(1, self.c0_total)\n"
      "                print(\"AS2W_CMD_SHARE_C0\", {\"total\": self.c0_total,\n"
      "                    \"zero_pct\": round(self.c0_zeros / tot * 100, 2),\n"
      "                    \"pure_vx_pct\": round(self.c0_vx / tot * 100, 2),\n"
      "                    \"pure_vy_pct\": round(self.c0_vy / tot * 100, 2),\n"
      "                    \"pure_wz_pct\": round(self.c0_wz / tot * 100, 2),\n"
      "                    \"mixed_pct\": round(self.c0_mixed / tot * 100, 2)}, flush=True)",
      "task-c0-share-log")

# ---------------- stage configs for C0/C1: obs0 + exec0 ----------------
base = json.loads((SRC / "domain_config.json").read_text(encoding="utf-8"))
for name in ("c0", "c1"):
    cfg = json.loads(json.dumps(base))
    cfg["sensors"]["delay_ticks_max"] = 0
    cfg["sensors"]["delay_tick_probabilities"] = {"0": 1.0}
    cfg["sensors"]["obs_delay_ticks_max"] = 0
    cfg["sensors"]["obs_delay_tick_probabilities"] = {"0": 1.0}
    cfg["optimization"]["learning_rate"] = 5e-4
    cfg["optimization"]["desired_kl"] = 0.01
    cfg["_dr3c_arm"] = name
    p = pathlib.Path("/root/as2w/retrain-wheeldiff-dr3c-20261122/configs") / f"domain_config_{name}.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(cfg, indent=2) + "\n", encoding="utf-8")
    print("wrote", p)

print("DR3C_SAMPLER_PATCH_OK")
