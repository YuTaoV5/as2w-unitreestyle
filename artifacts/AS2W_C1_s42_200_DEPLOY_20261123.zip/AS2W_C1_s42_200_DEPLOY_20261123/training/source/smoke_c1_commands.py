#!/usr/bin/env python3
"""C1 sampler command smoke (4096 envs): verify actual/observation commands for
all six constant low-speed bins, decel paths, and that F/Y are not overwritten."""
import json
import pathlib
import sys

CK = pathlib.Path("/root/gpufree-data/as2w-runs/retrain-dr2b-20261122/dr2b_s1_seed42/train/model_799.pt")
OUT = pathlib.Path("/root/gpufree-data/as2w-runs/retrain-dr3c-20261122/c1_cmd_smoke")
OUT.mkdir(parents=True, exist_ok=True)
CSV = OUT / "c1_commands.csv"
if CSV.exists():
    CSV.unlink()

from isaaclab.app import AppLauncher
app = AppLauncher(headless=True).app
import numpy as np
import torch
import task as task_mod


class A:
    pass
a = A()
a.out = OUT
a.asset = pathlib.Path("/root/as2w/assets/generated/as2w/as2w.usda")
a.terrain = "flat"
a.num_envs = 4096
a.dr_level = 0
a.seed = 0
a.wheel_diff = True
a.ground_friction = 0.35
a.reward_config = pathlib.Path("reward_config_wheeldiff_v41.json")
a.obs_delay = 0
a.command_hold_s = 2.5
a.gait_phase = False
a.gait_period_s = 1.0
a.step_only = False
a.right_only = False
a.delay_ticks = None
a.eval_delay_ticks = None
a.eval_obs_delay_ticks = None
a.cmd_scale = 1.0
a.cmd_sampler = "c1"
env = task_mod.build_task(a)
env.cmd_sampler = "c1"
init_ok = hasattr(env, "c1_mode")
if not init_ok:
    # custom build_task path did not trigger the reset hook; assign explicitly so
    # the command logic itself is validated (the real run.py path logs AS2W_CMD_SHARE)
    env._c1_assign(torch.arange(env.num_envs, device=env.device))
obs = env._get_observations()
obs_cmd = obs["policy"][:, :3].cpu().numpy()
cmd = env.command.cpu().numpy()
mode = env.c1_mode.cpu().numpy()
vx = env.c1_vx.cpu().numpy()
te = env.c1_t_decel_end.cpu().numpy()
res = {"num_envs": int(env.num_envs),
       "obs_equals_command": bool(np.allclose(obs_cmd, cmd, atol=1e-6)),
       "mode_counts": {k: int((mode == i).sum()) for i, k in enumerate("SZLFY")},
       "bins": {}, "decel": {}, "fy_ok": True}
for b in (.05, -.05, .10, -.10, .15, -.15):
    sel = (mode == 2) & np.isclose(vx, b)
    sel_const = sel & (te < 0)
    res["bins"][f"{b:+.2f}"] = {"n": int(sel.sum()), "const_n": int(sel_const.sum()),
                               "obs_vx_unique": sorted(set(np.round(obs_cmd[sel_const, 0], 6).tolist()))[:5],
                               "obs_vy_abs_max": float(np.abs(obs_cmd[sel, 1]).max()) if sel.any() else None}
    if sel_const.any():
        # constant L must equal the bin for 3 consecutive ticks (no decel)
        ok = True
        for _ in range(3):
            env.episode_length_buf += 1
            env._c1_tick()
            c = env.command[torch.from_numpy(sel_const).to(env.device), 0].cpu().numpy()
            ok = ok and np.allclose(c, b, atol=1e-5)
        res["bins"][f"{b:+.2f}"]["const_3tick_ok"] = bool(ok)
# decel path: force two L decel envs and one Z decel env, then step time
ids = torch.arange(env.num_envs, device=env.device)
env.c1_mode[:] = 2
env.c1_vx[:] = 0.10
env.c1_t_decel_end[:] = -1.0
env.c1_mode[0] = 2
env.c1_vx[0] = 0.10
env.c1_t_decel_end[0] = 2.0
env.c1_mode[1] = 1
env.c1_vx[1] = -0.15
env.c1_t_decel_end[1] = 2.0
env.episode_length_buf[:] = 0
env._c1_tick()
res["decel"]["t0"] = {"L_decel_vx": float(env.command[0, 0]), "Z_decel_vx": float(env.command[1, 0])}
env.episode_length_buf[0] = 87  # t=1.74 s (mid of 0.5 s decel window)
env.episode_length_buf[1] = 87
env._c1_tick()
res["decel"]["t1p74"] = {"L_decel_vx": float(env.command[0, 0]), "Z_decel_vx": float(env.command[1, 0])}
env.episode_length_buf[0] = 100  # t=2.0 s -> zero
env.episode_length_buf[1] = 100
env._c1_tick()
res["decel"]["t2p0"] = {"L_decel_vx": float(env.command[0, 0]), "Z_decel_vx": float(env.command[1, 0])}
res["decel"]["ok_half"] = bool(0.02 <= res["decel"]["t1p74"]["L_decel_vx"] <= 0.08
                               and -0.12 <= res["decel"]["t1p74"]["Z_decel_vx"] <= -0.03
                               and abs(res["decel"]["t2p0"]["L_decel_vx"]) < 1e-6
                               and abs(res["decel"]["t2p0"]["Z_decel_vx"]) < 1e-6)
# F/Y untouched: assign F/Y envs and check vy/wz preserve a non-trivial sample
env.c1_mode[2:] = 3
env.c1_t_decel_end[2:] = -1.0
env.episode_length_buf[2:] = 0
env.command[2:] = 0.
env._c1_tick()
res["fy_ok"] = bool(torch.any(env.command[2:, 1].abs() > 1e-6) or torch.any(env.command[2:, 2].abs() > 1e-6))
res["csv_rows"] = int(sum(1 for _ in open(CSV))) if CSV.exists() else 0
(OUT / "smoke_result.json").write_text(json.dumps(res, indent=1) + "\n")
print("C1_CMD_SMOKE", json.dumps(res, indent=1), flush=True)
try:
    env.close()
except Exception:
    pass
try:
    app.close()
except Exception:
    pass
