"""Shared AS2W simulation with distinct policy and wheel-command contracts.

2026-11-21 wheel-differential retrain: the wheel target is generated from
(vx, wz) with the official-derived differential-drive contract instead of the
legacy vx/R mapping. See control.toml [common] and README_RETRAIN.md.
"""
from pathlib import Path
import math
import os
import tomllib
import xml.etree.ElementTree as ET

import torch
import isaaclab.sim as sim
from isaaclab.actuators import ImplicitActuatorCfg
from isaaclab.assets import ArticulationCfg
from isaaclab.envs import DirectRLEnv, DirectRLEnvCfg, mdp
from isaaclab.managers import EventTermCfg, SceneEntityCfg
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.terrains import TerrainImporterCfg, TerrainGeneratorCfg
from isaaclab.terrains import MeshPlaneTerrainCfg, MeshPyramidStairsTerrainCfg
from isaaclab.terrains import HfRandomUniformTerrainCfg, HfPyramidSlopedTerrainCfg
from isaaclab.utils import configclass
from isaaclab_physx.physics import PhysxCfg

ROOT = Path(__file__).resolve().parents[1]
CONTROL = tomllib.loads((Path(__file__).with_name("control.toml")).read_text())["common"]
LEGS = [f"{leg}_{part}" for leg in ("FL", "FR", "RL", "RR") for part in ("hip", "thigh", "calf")]
WHEELS = [f"{leg}_foot" for leg in ("FL", "FR", "RL", "RR")]
FRAME = 58
HISTORY = 6
RADIUS = 0.086
# Official stand: thigh 0.60 / calf -1.20 / hip +/-0.15 puts the wheel contact
# at z ~= -0.448 below the base link (URDF FK, incl. the hip-roll offset), so the
# spawn height is 0.45 m and the nominal height feature is 0.45 as well.
HEIGHT = 0.45
RESET_HEIGHT = 0.450

# ── wheel-differential contract (2026-11-21) ─────────────────────────────────
# WHEELS order is FL, FR, RL, RR. For wz > 0 (CCW / left turn) the left wheel
# pair must be slower and the right pair faster, i.e. FL = base - yaw,
# FR = base + yaw, RL = base - yaw, RR = base + yaw. This matches the official
# LowCmd capture (left turn: left dq ~ -2.5 rad/s, right dq ~ +5..+6 rad/s).
WHEEL_SIDE = (-1.0, 1.0, -1.0, 1.0)
TRACK_WIDTH = float(CONTROL.get("track_width_m", 0.44))
YAW_EFF = float(CONTROL.get("yaw_efficiency", 0.415))
WHEEL_LIMIT = float(CONTROL.get("wheel_target_limit_rad_s", 12.0))
WHEEL_DIFF_DEFAULT = CONTROL.get("wheel_target_mode", "vx_wz_differential") == "vx_wz_differential"

# Official six modes stand pose (16 axes; feet are the wheel joints).
STANCE = {
    "FL_hip": -0.15, "FR_hip": 0.15, "RL_hip": -0.15, "RR_hip": 0.15,
    "FL_thigh": 0.60, "FR_thigh": 0.60, "RL_thigh": 0.60, "RR_thigh": 0.60,
    "FL_calf": -1.20, "FR_calf": -1.20, "RL_calf": -1.20, "RR_calf": -1.20,
    "FL_foot": 0.0, "FR_foot": 0.0, "RL_foot": 0.0, "RR_foot": 0.0,
}


def tensor(value):
    return value.torch if hasattr(value, "torch") else value


def wheel_targets(command, wheel_diff=True):
    """Map a (num_envs, 3) velocity command to four wheel velocity targets.

    Legacy contract (``wheel_diff=False``): all four wheels get vx / R.
    Wheel-differential contract (``wheel_diff=True``):
        base = vx / R
        yaw  = wz * (B / 2) / (R * eta)
        FL/RL = base - yaw, FR/RR = base + yaw, clamped to +/- WHEEL_LIMIT.
    """
    base = command[:, 0] / RADIUS
    if not wheel_diff:
        return base.unsqueeze(1).expand(-1, 4).clamp(-WHEEL_LIMIT, WHEEL_LIMIT)
    yaw = command[:, 2] * (TRACK_WIDTH * 0.5) / (RADIUS * YAW_EFF)
    side = command.new_tensor(WHEEL_SIDE)
    wheel = base.unsqueeze(1) + side.unsqueeze(0) * yaw.unsqueeze(1)
    return wheel.clamp(-WHEEL_LIMIT, WHEEL_LIMIT)


def zero_speed_snap_mask(command, wheel_target, deadband=.02, eps=1e-9):
    """Mask of wheel targets to force to zero.

    Zero-speed snap is only valid when BOTH vx and wz are zero; the legacy
    condition ``wheel == 0`` no longer holds when either axis is nonzero under
    the differential contract (e.g. FL = base - yaw can be exactly zero while
    the robot is turning).
    """
    still = (command[:, 0].abs() < eps) & (command[:, 2].abs() < eps)
    return still[:, None] & (wheel_target.abs() < deadband)


@configclass
class DomainEvents:
    material = EventTermCfg(
        func=mdp.randomize_rigid_body_material, mode="startup",
        params={"asset_cfg": SceneEntityCfg("robot"), "static_friction_range": (.25, .50),
                "dynamic_friction_range": (.18, .35), "restitution_range": (0., .02),
                "num_buckets": 48},
    )
    mass = EventTermCfg(
        func=mdp.randomize_rigid_body_mass, mode="startup",
        params={"asset_cfg": SceneEntityCfg("robot"), "mass_distribution_params": (.95, 1.05),
                "operation": "scale", "distribution": "uniform", "recompute_inertia": True},
    )
    com = EventTermCfg(
        func=mdp.randomize_rigid_body_com, mode="startup",
        params={"asset_cfg": SceneEntityCfg("robot", body_names="base_link"),
                "com_range": {axis: (-.005, .005) for axis in ("x", "y", "z")}},
    )
    drive_gains = EventTermCfg(
        func=mdp.randomize_actuator_gains, mode="reset",
        params={"asset_cfg": SceneEntityCfg("robot"), "stiffness_distribution_params": (.95, 1.05),
                "damping_distribution_params": (.95, 1.05), "operation": "scale"},
    )


@configclass
class AS2WSceneCfg(InteractiveSceneCfg):
    robot: ArticulationCfg | None = None
    terrain: TerrainImporterCfg | None = None


@configclass
class AS2WCfg(DirectRLEnvCfg):
    decimation = 4
    episode_length_s = 12.0
    action_space = 12
    observation_space = FRAME
    state_space = FRAME + 3
    him = False
    rough = True
    randomize = True
    gait_phase = False
    gait_period_s: float = 1.0
    step_only = False
    right_only = False
    # Wheel-diff contract default comes from control.toml; run.py --no-wheel-diff
    # (alias --legacy-wheel) overrides it for A/B and fallback.
    wheel_diff: bool = WHEEL_DIFF_DEFAULT
    sim = sim.SimulationCfg(
        dt=CONTROL["policy_dt_s"] / 4, render_interval=4,
        physics=PhysxCfg(gpu_found_lost_aggregate_pairs_capacity=2**27), use_newton_actuators=False,
    )
    scene = AS2WSceneCfg(num_envs=64, env_spacing=2.5, replicate_physics=True)

    def __post_init__(self):
        source = Path(__file__).parent / "assets/as2w-t2-v2.urdf"
        limits = {j.get("name"): j.find("limit").attrib for j in ET.parse(source).findall("joint")
                  if j.find("limit") is not None}
        self.scene.robot = ArticulationCfg(
            prim_path="{ENV_REGEX_NS}/Robot",
            spawn=sim.UrdfFileCfg(asset_path=str(source), fix_base=False, merge_fixed_joints=True,
                                 usd_dir=str(ROOT / "assets/generated"), usd_file_name="as2w.usd",
                                 joint_drive=None),
            init_state=ArticulationCfg.InitialStateCfg(
                pos=(0., 0., RESET_HEIGHT),
                joint_pos=dict(STANCE),
            ),
            actuators={
                name: ImplicitActuatorCfg(
                    joint_names_expr=group,
                    stiffness=(float(os.environ.get("AS2W_ACT_KP","0") or 0) if (name=="legs" and float(os.environ.get("AS2W_ACT_KP","0") or 0)>0) else kp),
                    damping=(float(os.environ.get("AS2W_ACT_KD","0") or 0) if (name=="legs" and float(os.environ.get("AS2W_ACT_KD","0") or 0)>0) else kd),
                    # Rotor inertia reflected at the joint (official data calls for
                    # armature; default 0.01 kg m^2, env override AS2W_ACT_ARMATURE).
                    armature=float(os.environ.get("AS2W_ACT_ARMATURE","0.01") or 0),
                    # Joint friction: legs 0.5 (official static residual <=1 Nm at
                    # kp 200; kept modest at our kp 55), wheels 0.15.
                    friction=(float(os.environ.get(f"AS2W_ACT_FRICTION_{name.upper()}",
                                                   "0.5" if name == "legs" else "0.15"))),
                    effort_limit_sim={j: float(limits[j]["effort"]) for j in group},
                    velocity_limit_sim={j: float(limits[j]["velocity"]) for j in group},
                )
                for name, group, kp, kd in (("legs", LEGS, 55., 2.), ("wheels", WHEELS, 0., 2.))
            },
        )
        self.events = DomainEvents() if self.randomize else None
        if self.gait_phase:
            # Two extra observation dims carry the gait clock (sin, cos).
            self.observation_space = FRAME + 2
            self.state_space = FRAME + 5
        if self.him:
            self.action_space = 16
            self.observation_space = FRAME * HISTORY

    def configure_terrain(self):
        terrain = TerrainImporterCfg(prim_path="/World/ground", terrain_type="plane",
                                     num_envs=self.scene.num_envs,
                                     env_spacing=self.scene.env_spacing)
        if self.rough:
            terrain.terrain_type = "generator"
            terrain.max_init_terrain_level = 0
            terrain.terrain_generator = TerrainGeneratorCfg(
                seed=self.seed, curriculum=True, size=(8., 8.), num_rows=5, num_cols=max(8, math.ceil(self.scene.num_envs / 128)),
                sub_terrains={
                    "plane": MeshPlaneTerrainCfg(proportion=.60),
                    # Conservative slope band for the retrain: 10.8 deg max.
                    "slope": HfPyramidSlopedTerrainCfg(proportion=.40, slope_range=(0., .12), platform_width=2.5),
                },
            )
        self.scene.terrain = terrain


class AS2WEnv(DirectRLEnv):
    def __init__(self, cfg, **kwargs):
        super().__init__(cfg, **kwargs)
        names = self.robot.joint_names
        self.leg_ids = [names.index(name) for name in LEGS]
        self.wheel_ids = [names.index(name) for name in WHEELS]
        self.ids = self.leg_ids + self.wheel_ids
        self.command = torch.zeros(self.num_envs, 3, device=self.device)
        self.target = torch.zeros(self.num_envs, 16, device=self.device)
        self.previous = torch.zeros_like(self.target)
        self.previous_delta = torch.zeros_like(self.target)
        self.exercise = None
        self.history = torch.zeros(self.num_envs, HISTORY, FRAME, device=self.device)
        self.terminal_critic = torch.zeros(self.num_envs, FRAME + 3, device=self.device)
        self.alpha_leg, self.alpha_wheel = (
            -math.expm1(-2 * math.pi * CONTROL[key] * self.step_dt)
            for key in ("leg_target_cutoff_hz", "wheel_target_cutoff_hz")
        )

    def _setup_scene(self):
        self.robot = self.scene["robot"]
        self.terrain = self.scene.terrain

    def _pre_physics_step(self, actions):
        interval = round(getattr(self, "command_hold_s", 2.5) / self.step_dt)
        if getattr(self, "cmd_sampler", "c0") == "c1":
            self._c1_tick()
        else:
            env_ids = (self.episode_length_buf.remainder(interval) == 0).nonzero(as_tuple=True)[0]
            self._sample_commands(env_ids)
        if self.exercise is not None:
            self.command[:] = self.exercise
        # Squash instead of clamp: clamping put ~99% of action dims on the
        # boundary and zeroed their gradient, which fixed the stance pattern.
        actions = torch.tanh(actions)
        # Keep the executed (post-squash) action so the reward step can report
        # saturation / dither / sign-flip metrics for field-jitter prediction.
        if not hasattr(self, "executed") or self.executed.shape != actions.shape:
            self.executed = torch.zeros_like(actions)
            self.executed_prev = torch.zeros_like(actions)
        self.executed_prev.copy_(self.executed)
        self.executed.copy_(actions)
        if self.cfg.him:
            wheel = actions[:, 12:] * 12.
        else:
            wheel = wheel_targets(self.command, bool(getattr(self.cfg, "wheel_diff", WHEEL_DIFF_DEFAULT)))
        self.target[:, :12].lerp_(actions[:, :12] * .25, self.alpha_leg)
        self.target[:, 12:].lerp_(wheel.clamp(-WHEEL_LIMIT, WHEEL_LIMIT), self.alpha_wheel)
        if not self.cfg.him:
            # Zero-speed snap: with a differential contract the raw wheel vector
            # is only zero when both vx and wz are zero, so test the command.
            snap = zero_speed_snap_mask(self.command, self.target[:, 12:])
            self.target[:, 12:].masked_fill_(snap, 0.)

    def _apply_action(self):
        pos = tensor(self.robot.data.default_joint_pos)[:, self.leg_ids] + self.target[:, :12]
        self.robot.set_joint_position_target(pos, joint_ids=self.leg_ids)
        self.robot.set_joint_velocity_target(self.target[:, 12:], joint_ids=self.wheel_ids)

    def _frame(self):
        d = self.robot.data
        q = (tensor(d.joint_pos) - tensor(d.default_joint_pos))[:, self.ids]
        q[:, 12:] = 0.
        # Kept /12 in the wheel-diff contract: the new targets are ~+/-0.5 of the
        # +12 rad/s limit, so they stay inside the observation range without rescaling.
        previous = torch.cat((self.target[:, :12] / .25, self.target[:, 12:] / 12.), -1)
        frame = torch.cat((self.command, tensor(d.root_ang_vel_b), tensor(d.projected_gravity_b),
                           q, tensor(d.joint_vel)[:, self.ids] * .05, previous,
                           torch.full_like(q[:, :1], HEIGHT)), -1)
        if getattr(self.cfg, "gait_phase", False):
            period = max(float(getattr(self.cfg, "gait_period_s", 1.0)), 1e-3)
            phase = (self.episode_length_buf.float() * self.step_dt / period).remainder(1.0)
            angle = 2 * math.pi * phase
            frame = torch.cat((frame, torch.sin(angle)[:, None], torch.cos(angle)[:, None]), -1)
        return frame

    def _get_observations(self):
        frame = self._frame()
        critic = torch.cat((frame, tensor(self.robot.data.root_lin_vel_b)), -1)
        if self.cfg.him:
            old = self.history[:, :-1].clone()
            self.history[:, 1:] = torch.where((self.episode_length_buf == 0)[:, None, None],
                                               frame[:, None], old)
            self.history[:, 0] = frame
            frame = self.history.flatten(1).clone()
        return {"policy": frame, "critic": critic}

    def _get_dones(self):
        d = self.robot.data
        failed = (tensor(d.projected_gravity_b)[:, 2] > -.52)
        timeout = self.episode_length_buf >= self.max_episode_length - 1
        if self.cfg.him:
            self.terminal_critic[:] = torch.cat((self._frame(), tensor(d.root_lin_vel_b)), -1)
        return failed, timeout

    def _get_rewards(self):
        d = self.robot.data
        v, w, g = map(tensor, (d.root_lin_vel_b, d.root_ang_vel_b, d.projected_gravity_b))
        xy_error = (v[:, :2] - self.command[:, :2]).square().sum(1)
        yaw_error = (w[:, 2] - self.command[:, 2]).square()
        q = (tensor(d.joint_pos) - tensor(d.default_joint_pos))[:, self.leg_ids]
        delta = self.target - self.previous
        jerk = delta - self.previous_delta
        self.previous.copy_(self.target)
        self.previous_delta.copy_(delta)
        still = self.command.abs().sum(1) < .03
        # Wheel-diff retrain: yaw tracking weight 2 -> 3, denominator .25 -> .15;
        # linear tracking stays weight 3 / denominator .25.
        reward = (3 * (-xy_error / .25).exp() + 3 * (-yaw_error / .15).exp()) * self._tracking_gate()
        reward -= .5 * v[:, 2].square() + .1 * w[:, :2].square().sum(1) + .5 * g[:, :2].square().sum(1)
        reward -= (.2 + still) * q.square().sum(1)
        reward -= .06 * (delta[:, :12].square() + jerk[:, :12].square()).sum(1)
        reward -= .0005 * delta[:, 12:].square().sum(1)
        reward -= still * .02 * tensor(d.joint_vel)[:, self.wheel_ids].square().sum(1)
        return self.step_dt * reward - .5 * self.reset_terminated

    def _tracking_gate(self):
        """Multiplier on the velocity-tracking reward; 1 unless a task overrides."""
        return 1.

    def _sample_commands(self, ids):
        n = len(ids)
        cmd = (torch.rand(n, 3, device=self.device) * 2 - 1) * self.command.new_tensor([.8, .45, .8])
        mode = torch.randint(0, 5, (n,), device=self.device)
        cmd[mode == 0] = 0
        for axis in range(3):
            cmd[(mode >= 1) & (mode <= 3) & (mode != axis + 1), axis] = 0
        self.command[ids] = cmd

    def _reset_idx(self, env_ids):
        if env_ids is None:
            env_ids = torch.arange(self.num_envs, device=self.device)
        d = self.robot.data
        if self.cfg.rough:
            displacement = (tensor(d.root_pos_w)[env_ids, :2] - self.terrain.env_origins[env_ids, :2]).norm(dim=1)
            eligible = self.episode_length_buf[env_ids] > 50
            self.terrain.update_env_origins(env_ids, eligible & (displacement > 3.),
                                            eligible & (displacement < .5) & (self.command[env_ids].norm(dim=1) > .2))
        super()._reset_idx(env_ids)
        state = tensor(d.default_root_state)[env_ids].clone()
        state[:, :3] += self.terrain.env_origins[env_ids]
        q = tensor(d.default_joint_pos)[env_ids].clone()
        dq = tensor(d.default_joint_vel)[env_ids].clone()
        if self.cfg.randomize:
            q[:, self.leg_ids] += (torch.rand_like(q[:, self.leg_ids]) * 2 - 1) * .03
        self._custom_reset_pose(env_ids, state, q)
        self.robot.write_root_pose_to_sim(state[:, :7], env_ids)
        self.robot.write_root_velocity_to_sim(state[:, 7:], env_ids)
        self.robot.write_joint_state_to_sim(q, dq, env_ids=env_ids)
        self.target[env_ids] = 0.
        self.target[env_ids[:, None], torch.arange(12, device=self.device)] = (
            q[:, self.leg_ids] - tensor(d.default_joint_pos)[env_ids][:, self.leg_ids]
        )
        self.previous[env_ids] = self.target[env_ids]
        self.previous_delta[env_ids] = 0.
        if getattr(self, "cmd_sampler", "c0") == "c1":
            self._c1_assign(env_ids)
        else:
            self._sample_commands(env_ids)

    def _custom_reset_pose(self, env_ids, state, q):
        """Optional task-specific reset pose."""
