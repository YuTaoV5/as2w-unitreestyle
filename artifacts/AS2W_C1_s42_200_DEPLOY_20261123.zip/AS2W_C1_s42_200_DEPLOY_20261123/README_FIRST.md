# AS2-W C1_s42_200 — 完整部署包（ARM64 / CPRO）

> 本包是 **C1_s42_200 专属部署包**：C1 ONNX + A/v4x ARM64 部署骨架 + 必要训练资产。
> **不是已放行版本**：C1 只在 MuJoCo 姿态对比中最佳；未完成 CPRO C++ audit（本机 HDC 掉线）、未实机验证、未 owner 放行。

## 先读
- 目标机：CPRO（HarmonyOS host + Ubuntu 22.04 rootfs），ARM64。
- 部署端：`as2w_unitree58v4_lp5_publish` / `as2w_unitree58v4_lp5_replay`。
- 模型：C1 ONNX `e5e81fe0…`，58 obs / 12 act，内嵌 tanh，腿 55/2；轮 vx/wz 差速合同。
- 训练 checkpoint：`c1_s42_model_199.pt` `572898f0…`。
- 固定站/起身：200/4；策略阶段 55/2（Training contract）。
- **禁止**把 200/4 带进策略阶段；**禁止**在 ai 模式下启动 publisher。

## 3 步安装（CPRO rootfs）
```bash
# 1) 传包并解压
hdc file send AS2W_C1_s42_200_DEPLOY_20261123.zip /data/local/tmp/
cd /data/local/tmp && unzip AS2W_C1_s42_200_DEPLOY_20261123.zip

# 2) 校验 + 安装 + 离线 audit（不发 LowCmd）
cd AS2W_C1_s42_200_DEPLOY_20261123
sha256sum -c SHA256SUMS
cd ..
bash AS2W_C1_s42_200_DEPLOY_20261123/deployment/scripts/install_c1_cpro.sh /root/as2w_deploy_c1_s42_200

# 3) 只有现场安全确认后，才做 ReleaseMode + zero-B
#    先确认 eth0 UP、LowState 有包、motion-mode name=ai
#    然后由现场操作员执行一次 ReleaseMode
cd /root/as2w_deploy_c1_s42_200
bash scripts/run_zero_b_guarded_c1.sh
```
> `install_c1_cpro.sh` 会做 SHA 校验、安装到独立目录、跑 `--offline-audit`，**不会**启动 publisher、不会发 LowCmd。

## 目录
```text
AS2W_C1_s42_200_DEPLOY_20261123/
├── README_FIRST.md
├── VERSION
├── SHA256SUMS
├── deployment/
│   ├── bin/                 ARM64 publish/replay
│   ├── models/unitree58-v4x/ C1 policy.onnx + deploy.yaml + export.json
│   ├── config/              measured map（hip sign=+1）
│   ├── scripts/             install / guarded zero-B / safe exit / rollback A
│   ├── tools/               v4x_field.sh
│   ├── source/              C++ 源码快照（二进制为权威）
│   ├── manifest/            C1 manifest
│   ├── logs/                参考 audit/CTest（A 基线）
│   └── rollback_A/          A 基线 policy（回滚用）
├── training/
│   ├── checkpoints/         C1 model_199.pt（4.7 MB）
│   ├── configs/             run/resolved/domain/recipe
│   ├── source/              task/env/control/C1 sampler patch/smoke
│   ├── export/              export_onnx.py/parity_v4x.py/export.json
│   └── evidence/            C1 选择/姿态对比/eval 日志
└── docs/
    ├── DEPLOY_CPRO.md
    ├── C1_SELECTION_AND_LIMITS.md
    └── TRAINING_PROVENANCE.md
```

## 关键 SHA
| 对象 | SHA256 |
|---|---|
| publish | `7418070199700fa7ffc503301c41db7c79c4abf992edde4b601fa632dcf175fc` |
| replay | `6da02f9fc82018a775d2447bd9cf5e7e0166f792c77f19781159b770892745ea` |
| C1 policy.onnx | `e5e81fe0ad34a69f688d3107c4a3787944063546736e77e4e227b2c4d39a2074` |
| C1 checkpoint | `572898f0e9897f5d03d32febb1bed60952a727662a074269bcc36f370550b3fb` |
| deploy.yaml | `531f07d0dbbf9ccc36d932db90e866c4db101d63e6e221b94dae0d4f358db123` |
| measured map | `f33fcae4d72e353efdb3d9b727b131fa72965890b9c5f97be14b1d58c3de598c` |
| fallback A policy | `63f1c5b6a6bf5c7fd9fdcaa09cce93deb5aa5c81dc97c96e6c0dd72bf7ab64ee` |

## 验证状态（必须如实）
- C1 ONNX export parity：**PASS**，torch↔ORT max abs err **4.77e-6**（limit 2e-5）。
- C++ offline audit on C1：**PENDING**。打包时 HDC/CPRO 掉线，未在目标上跑；安装脚本会自动跑 `--offline-audit`，只有看到 `AUDIT PASS` 才能继续。
- 参考 CTest 9/9 来自 A 基线；C1 二进制未重编译，仅替换模型。
- 实机：**未测试**；zero-B / B gate / policy handoff 都未在 C1 上验证。
- 发布：`release_authorized=false`。

## 安全注意
- `run_zero_b_guarded_c1.sh` 需要现场先 ReleaseMode；若 `motion-mode name=ai` 会拒绝启动。
- 任何 X/EmergencyDamping 后：等 publisher 停止，再 `motion-select ai`。
- 不要在 ai 模式下运行 publisher；不要同时运行两个 publisher。
- C1 在 MuJoCo 高速横移/转向仍会轮距收缩、support4 下降；仿真不是实机安全证明。
- exact mixed `(0.4,0.25,-0.3)` 在 MuJoCo 会倒；包内不提供绕过。
